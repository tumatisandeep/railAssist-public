var app = angular.module("myApp", [ 'angular-loading-bar', 'ngAnimate' ]);

app.controller("Ctrl", Ctrl);

function Ctrl(Detailserv, $http, $window) {

	var self = this;
	this.showItemInfo = false;
	this.itemsDataToBeSupplied = [];
	this.itemNotPresent = false
	this.formData = [];
	this.itemNotPresent = false
	this.itemStockAvailable = false;
	this.disableButton = false;
	self.maxDate = new Date()
	self.maxQuantityReached = false
	this.count = 1;
	this.poData = []
	this.selectedPOData = []
	self.disableInputField = true
	self.showPoButton=true
	this.getItemData = function(itemId) {

		
		Detailserv
				.getItemData(itemId)
				.then(
						function(data) {
							
							self.count = 1;

							
							self.showPoButton=true

							self.poData = [];
							self.selectedPOData=[]

							self.itemData = data;

							if (!self.itemData.itemPresent) {
								self.itemNotPresent = true;
								self.showItemInfo = false;
							}

							else {

								// alert("hi")


									self.poData.push({
										"poData" : self.itemData,
										"count" : self.count,
										"disabled" : false
									})

									self.itemNotPresent = false;
									self.showItemInfo = true;

									//self.poID = false

							}

						})

	}

	this.addItem = function(itemId) {

		//var poNumber = angular.element(document.getElementById("poNumber"))
			//	.val()
		self.contains = null;
		if (self.itemsDataToBeSupplied.length == 0) {

			for (var i = 0; i < self.selectedPOData.length; i++) {

				self.itemsDataToBeSupplied.push({
					"itemId" : itemId,
					"quantity" : self.selectedPOData[i].qty,
					"poNumber" : self.selectedPOData[i].poID
				});

			}
			self.quantity = null;
			self.showItemInfo = false;
			self.selectedPOData = []

		} else {
			for (var i = 0; i < self.itemsDataToBeSupplied.length; i++) {
				//console.log(self.itemsDataToBeSupplied[i].poNumber)
				if (self.itemsDataToBeSupplied[i].itemId == itemId  ) {
					alert("Item ID alreay added");
					self.indentTextField = null;
					self.contains = "true;"
					self.showItemInfo = false;

					return;
				}

			}
			if (self.contains != "true") {

				for (var i = 0; i < self.selectedPOData.length; i++) {

					self.itemsDataToBeSupplied.push({
						"itemId" : itemId,
						"quantity" : self.selectedPOData[i].qty,
						"poNumber" : self.selectedPOData[i].poID
					});

				}

				self.quantity = null;
				self.selectedPOData = []

			}

		}

		self.count = 1
		self.showItemInfo = false;
		self.quantity = null;
		self.itemStockAvailable = false
		self.poID = false
		self.itemId = null

	}

	this.dropDownChanged = function(id) {
		self.disableInputField = false

		angular.element(document.getElementById("id")).val(0)

	}

	this.checkIfDisabledOrNot = function(poNumber) {
		// alert(poNumber)
		// console.log("inside disable funciotn"+poNumber)

		// self.disableInputField=false

		for (var i = 0; i < self.selectedPOData.length; i++) {
			if (self.selectedPOData[i].poID == poNumber) {

				return true

			}
		}

	}

	this.showAddPoButton = function() {
		if (self.poData.length > 0) {
			if (self.count <= Object.keys(self.poData[0].poData.poDataOfItem).length)
				return false
			else
				return true
		}
	}

	this.showPoButton = function() {

		if (self.count == self.poData[0].poData.poDataOfItem.length)
			return true
		else
			return false

	}

	this.addAnotherPO = function() {

		if(self.count<(Object.keys(self.poData[0].poData.poDataOfItem).length+1))
		
		{
			if(angular.element(
					document.getElementById("quantity_" + self.count)).val()==null){
				alert("Please enter quantity for selected Purchase order")
				return false
			}
			
		self.selectedPOData.push({
			"poID" : angular.element(
					document.getElementById("poId_" + self.count)).val(),
			"qty" : angular.element(
					document.getElementById("quantity_" + self.count)).val()
		})

		
		console.log(self.poData)

					self.count++

		
		for (var i = 0; i < self.poData.length; i++) {

			//console.log(self.poData[i].poData.poDataOfItem)

			self.poData[i].disabled = true
	//		console.log(self.selectedPOData)

		}

		// alert(self.count +" "+
		// Object.keys(self.poData[0].poData.poDataOfItem).length)

		if (self.count <= Object.keys(self.poData[0].poData.poDataOfItem).length){
			
		
			self.poData.push({
				"poData" : self.itemData,
				"count" : self.count,
				"disabled" : false
			})

		}
			
		//console.log(self.selectedPOData)

		// self.disableInputField=true
		}
	}

	this.getLength = function(obj) {
		return Object.keys(obj).length;
	}

	this.restrictToQtyReq = function() {
		// alert(parseInt(angular.element(document.getElementById("quantity_"+self.count)).val())+"
		// "+parseInt(angular.element(document.getElementById("poId_"+self.count)).val()))

		//console.log(self.itemData.poDataOfItem[angular.element(
			//	document.getElementById("poId_" + self.count)).val()])

		if (parseInt(angular.element(
				document.getElementById("quantity_" + self.count)).val()) > self.itemData.poDataOfItem[angular
				.element(document.getElementById("poId_" + self.count)).val()]) {
			//console.log(self.itemData.poDataOfItem[angular.element(
				//	document.getElementById("poId_" + self.count)).val()])
			angular.element(document.getElementById("quantity_" + self.count))
					.val(
							self.itemData.poDataOfItem[angular.element(
									document.getElementById("poId_"
											+ self.count)).val()])
		}

		if (parseInt(angular.element(
				document.getElementById("quantity_" + self.count)).val()) < 0) {
			//console.log(self.itemData.poDataOfItem[angular.element(
				//	document.getElementById("poId_" + self.count)).val()])
			angular.element(document.getElementById("quantity_" + self.count))
					.val(0)
		}

		/*
		 * if(parseInt(angular.element(document.getElementById("quantity_"+self.count)).val())<0)
		 * angular.element(document.getElementById("quantity_"+self.count)).val()=0
		 * 
		 * 
		 * if(parseInt(angular.element(document.getElementById("quantity_"+self.count)).val())==self.itemData.stockAvailable)
		 * self.maxQuantityReached=true
		 * 
		 * else
		 * if(parseInt(angular.element(document.getElementById("quantity_"+self.count)).val())<self.itemData.stockAvailable)
		 * self.maxQuantityReached=false
		 * 
		 * if(parseInt(angular.element(document.getElementById("quantity_"+self.count)).val())>0)
		 * self.itemStockAvailable=true else if(self.quantity==0)
		 * self.itemStockAvailable=false
		 */

	}

	this.removeFromItemsId = function(itemId,poNumber) {

		//alert("remove")

		for (var i = 0; i < self.itemsDataToBeSupplied.length; i++) {

			if (self.itemsDataToBeSupplied[i].itemId == itemId && self.itemsDataToBeSupplied[i].poNumber==poNumber) {

				self.itemsDataToBeSupplied.splice(i, 1);
				return;

			}
		}
	}

	this.submitIssuingForm = function() {
		//alert("hihi")

		self.formData.push(self.challanNumber);
		self.formData.push(self.sendingFrom);

		self.formData.push(self.date);

		self.formData.push(self.itemsIssuedTo);

		self.formData.push(self.itemsDataToBeSupplied)
		
		self.formData.push(self.itemsIssuedToPerson)

		$http({
			'url' : '/RailAssist/submitItemIssuingData',
			'method' : 'POST',
			'headers' : {
				'Content-Type' : 'application/json'
			},
			'data' : self.formData
		}).then(function(data,status, headers, config) {
			
			var jsonString=angular.toJson(data.data)
				$window.location.href = '/RailAssist/returnToHomeFromChallanForm?response='+encodeURI(jsonString);



		})


	}

}

app.service("Detailserv", function($http) {

	var self = this;
	self.getItemData = function(itemId) {

		var promise1 = $http.get('/RailAssist/getItemsDataWithId/' + itemId);
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}

	self.checkIfPoExists = function(poNumber) {

		var promise1 = $http.get('/RailAssist/checkIfPoPreasent/' + poNumber);
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}

	self.checkIfPoExists = function(itemId) {

		var promise1 = $http.get('/RailAssist/getQuantityLeft/' + itemId);
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}

});
