var app = angular.module("myApp", []);

app.controller("Ctrl", Ctrl);

function Ctrl(Detailserv) {

	var self = this

	self.editForm = true

	this.editForm = function() {
		self.editForm = false
	}
	
	self.maxDate=new Date()


	this.editField = function(fieldName) {

		
		if (fieldName == 1)
			self.idn = true

		if (fieldName == 2)
			self.indentNumber = true

		if (fieldName == 3)
			self.date = true

		if (fieldName == 4)
			self.serialNumber = true

		if (fieldName == 5)
			self.qtyDemanded = true

		if (fieldName == 6)
			self.units = true

		if (fieldName == 7)
			self.allocation = true

		if (fieldName == 8)
			self.desc = true

		if (fieldName == 9)
			self.purpose = true

		if (fieldName == 10)
			self.lastPurchaseData = true

		if (fieldName == 11)
			self.rate = true

		if (fieldName == 12)
			self.value = true

		if (fieldName == 13)
			self.qtyAvailable = true

		if (fieldName == 14)
			self.oSIndents = true

		if (fieldName == 15)
			self.oSAgnstPo = true

		if (fieldName == 16)
			self.year1 = true

		if (fieldName == 17)
			self.year2 = true

		if (fieldName == 18)
			self.year3 = true

		if (fieldName == 19)
			self.indent1Data = true

		if (fieldName == 20)
			self.indent2Data = true

		if (fieldName == 21)
			self.indent3Data = true

		if (fieldName == 22)
			self.indent4Data = true

		if (fieldName == 23)
			self.po1Data = true

		if (fieldName == 24)
			self.po2Data = true

		if (fieldName == 25)
			self.po3Data = true

		if (fieldName == 26)
			self.po4Data = true

		if (fieldName == 27)
			self.likelySupplier = true

		if (fieldName == 28)
			self.article = true

		if (fieldName == 29)
			self.financialYear = true

		if (fieldName == 30)
			self.controllingOfficer = true

	}
}

app.service("Detailserv", function($http) {

});
