
var app = angular.module("myApp",[ ]);

app.controller("Ctrl",Ctrl);

function Ctrl(Detailserv){
	var self = this;
	this.getPoData=function(poNo){
		
		Detailserv.getIndentsData(poNo)
		.then(function(data){

			self.indentsInfo = data;
			self.indentsInfoLoaded = true;

		})
		
	}
	
}



app.service("Detailserv",function($http){

	var self = this;


	self.getIndentsData=function(poNo)
	{
		    		var promise1 = $http.get('/RailAssist/getIndentsData/' + poNo);
		    		var promise2 = promise1.then(function(response){
		    			return response.data;
		    		});
		    		return promise2;

		    	
		
	}
	
});



