var app = angular.module("myApp", [ 'angular-loading-bar', 'ngAnimate' ]);

app.controller("Ctrl", Ctrl);

function Ctrl(Detailserv, $http, $window) {
	
	var self = this;
	this.showItemInfo = false;
	this.poDataLoaded=false;
	this.itemNotPresent=false
	self.maxDate=new Date()

	
	this.getItemData = function(itemId) {
		
		

		Detailserv.getItemData(itemId).then(function(data) {

			self.itemData = data;

			if (!self.itemData.itemPresent) {
				self.itemNotPresent = true;
				self.showItemInfo = false;
			}

			else {
				self.itemNotPresent = false;
				self.showItemInfo = true;
				self.poID=null
				self.poDataLoaded=false
				self.qtyReceived=null
				self.dateReceived=null
				
			}

		})

	}
	
	
	this.restrictUserToMaxOrMin=function(){
		
		if(self.qtyReceived<0)
			{
			self.qtyReceived=0;
			}
			
			if(self.qtyReceived>parseInt(angular.element(document.getElementById("poQuantity")).val()))
				self.qtyReceived=parseInt(angular.element(document.getElementById("poQuantity")).val())
		
	}
	
	
	
	this.getPoDetails=function(poNumber){
		//alert(self.qtyReceived)
		self.qtyReceived=null
		poNumber=poNumber.replace("/","$")
		Detailserv.getPoDetails(poNumber)
		.then(function(data) {
			
			self.poData=data;
			self.poDataLoaded=true;
			
		})
		
	}
	
	
	
}

app.service("Detailserv", function($http) {

	var self = this;
	self.getItemData = function(itemId) {

		var promise1 = $http.get('/RailAssist/getItemsDataWithIdPoNumber/' + itemId);
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}

	self.getPoDetails = function(poNumber) {

		var promise1 = $http.get('/RailAssist/getPoDetails/' + poNumber);
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}
	
	

});

