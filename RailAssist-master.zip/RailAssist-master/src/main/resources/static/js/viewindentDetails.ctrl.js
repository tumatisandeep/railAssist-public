
var app = angular.module("myApp",[ ]);

app.controller("Ctrl",Ctrl);

function Ctrl(Detailserv){
	var self = this;
	this.getPoDataOfIndent=function(indentNo){
		
		Detailserv.getPoDataOfIndent(indentNo)
		.then(function(data){

			self.poDataOfIndents = data;
			self.poDataLoaded = true;

		})
		
	}
	
}



app.service("Detailserv",function($http){

	var self = this;


	self.getPoDataOfIndent=function(indentNo)
	{
		    		var promise1 = $http.get('/RailAssist/getPoDataOfIndent/' + indentNo);
		    		var promise2 = promise1.then(function(response){
		    			return response.data;
		    		});
		    		return promise2;

		    	
		
	}
	
});



