var app = angular.module("myApp", [ 'angular-loading-bar', 'ngAnimate' ]);

app.controller("Ctrl", Ctrl);

function Ctrl(Detailserv, $http, $window) {

	this.indentDataToBeSupplied = [];
	this.showIndentInfo=false;
	this.addNewIndent = false;
	var self = this;
	this.formData = [];
	this.poAlreadyPresent = false;
	this.isIndentDataFound=false;
	this.showIndentNotFoundError=false;
	this.indentDataPONotReceived=false;
	this.getIndentData = function(indentId) {

		Detailserv.getIndentData(indentId).then(function(data) {
		
			
			self.indentData = data;
			console.log(self.indentData)
			if(self.indentData.indentId==0)
				{
				self.indentDataPONotReceived=false;
				self.isIndentDataFound=false;
				self.showIndentInfo=false;
				self.showIndentNotFoundError=true
				

				}
			else{
				
		self.showIndentNotFoundError=false;
			if (self.indentData.poReceived)
				{

				self.indentDataPONotReceived = false;
				self.isIndentDataFound=true;
				self.showIndentInfo=true;

				}
			else {

				self.indentDataPONotReceived = true;
				self.showIndentInfo=true;
				self.isIndentDataFound=true;

		}
			
			}
		})

		
	}

	this.addIndent = function(indentId) {
		
		

		self.contains = null;
		if (self.indentDataToBeSupplied.length == 0) {
			self.indentDataToBeSupplied.push({
				"indentData" : indentId,
			});
			

			self.indentId = null;


		} else {
			for (var i = 0; i < self.indentDataToBeSupplied.length; i++) {
				if (self.indentDataToBeSupplied[i].indentData == indentId) {
					alert("Indent ID alreay added");
					self.indentId = null;
					self.contains = "true;"
					self.showIndentInfo = false;

					return;
				}

			}
			if (self.contains != "true") {
				self.itemsDataToBeSupplied.push({
					"indentData" : indentId,
				});
				self.indentId = null;

			}

		}
		
		
		self.showIndentInfo = false;
		self.indentId=null;

	
	}

	
	
	
	
	this.removeFromIndentId = function(itemId) {

		for (var i = 0; i < self.indentDataToBeSupplied.length; i++) {

			if (self.indentDataToBeSupplied[i].itemId == itemId) {

				self.indentDataToBeSupplied.splice(i, 1);
				return;

			}
		}
	}
	
	
	
	this.submitForm=function()
	{
		
		alert("hi")

		

		self.formData.push(self.indentDataToBeSupplied)

		$http({
			'url' : '/RailAssist/submitIndentReceivedData',
			'method' : 'POST',
			'headers' : {
				'Content-Type' : 'application/json'
			},
			'data' : self.formData
		}).then(function(data,status, headers, config) {
			//alert(data)
			if (data == "success") {

				alert("success");

			}

			$window.location.href = '/';

		})

		
		
	}
	

}

app.service("Detailserv", function($http) {var self = this;
self.getIndentData = function(indentId) {

	var promise1 = $http.get('/RailAssist/getIndentInfo/' + indentId);
	var promise2 = promise1.then(function(response) {
		return response.data;
	});
	return promise2;

}});
