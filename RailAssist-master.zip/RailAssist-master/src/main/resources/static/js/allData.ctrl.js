

var app = angular.module("myApp",['angular-loading-bar', 'ngAnimate']);



app.controller("Ctrl",Ctrl);

function Ctrl(allDataserv, $window) {

	var self = this
	this.minDate = this.fromDate;

	this.maxDate = new Date();

	this.xyz = "from controller";

	this.totalLoadedArray = [];

	this.pageCnt = 1;

	this.dropDownChanged = false

	this.buttonTxt = "Load More";

	this.filterDataLoaded = false;

	this.selectedCategory = 1 // 1 for indent 2 for po 3 for received 4 for
								// challans

	 this.logged=false

	 this.dataReturned=false
	this.checkDateField = function() {

		if (this.dropDownChanged) {
			if ((this.fromDate == null && this.toDate == null)) {
				if (this.dropDownChanged && this.logged) {
					return true;
				}
			} else if (this.fromDate != null && this.toDate != null) {

				return true;
			} else {

				return false;
			}
		} else {
			return false
		}

	}

	this.applyFilter = function() {

		var self = this;
self.dataReturned=false
		self.searchNotDone=false
		
		if (this.categorySelected == undefined && !this.logged
				&& this.fromDate == undefined && this.toDate == undefined) {
			alert("No filter selected!");

		} else {
			allDataserv.applyFilterAndLoad(this.categorySelected, this.logged,
					this.fromDate, this.toDate).then(function(data) {

				self.loadMoreBtnVisible = false;

				self.filterDataLoaded = true;
				self.result.length = 0;
				self.result = data;
				 self.category=self.categorySelected
self.dataReturned=true
				// $window.scrollTo(0, 0);
				$("html,body").animate({
					scrollTop : '0px'
				}, "slow");

			})
		}

	}

	this.categoryChanged = function(category) {
		var self = this
		
		self.searchNotDone=false

		self.dataReturned=false
		self.selectedCategory = category
		self.pageCnt = 0
		self.dropDownChanged = true
		self.result = []
		allDataserv.getMoreData(self.pageCnt, self.selectedCategory).then(
				function(data) {

					if (data.length < 10) {
						self.loadMoreBtnVisible = false;
					} else {
						self.loadMoreBtnVisible = true;

					}
					self.result = data
					 self.category=self.selectedCategory
self.dataReturned=true
					self.pageCnt = self.pageCnt + 1;
					self.totalCount = data[0].totalCount
				})

	}

	
	this.loadMore = function() {
		var self = this;
		self.buttonTxt = "Loading....";

		allDataserv.getMoreData(this.pageCnt, this.selectedCategory).then(
				function(data) {
					// console.log(data);
					if (data.length < 10) {
						self.loadMoreBtnVisible = false;
					} else {
						self.loadMoreBtnVisible = true;

					}
					self.result = self.result.concat(data);

					self.pageCnt = self.pageCnt + 1;

				})
		self.buttonTxt = "Load More";

	}

}


app.service("allDataserv", function($http) {

	var self = this;

	self.getMoreData = function(pageCnt, selectedCategory) {

		var promise1 = $http.get('/RailAssist/allDataRestCall?pageCnt='
				+ pageCnt + '&selectedCategory=' + selectedCategory);
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}

	self.applyFilterAndLoad = function(categorySelected, logged, fromDate,
			toDate) {

		if (categorySelected == undefined) {
			categorySelected = 0;
		}

		if (fromDate == undefined || toDate == undefined) {
			fromDate = 0;
			toDate = 0;
		}

		var promise1 = $http
				.get('/RailAssist/getDataAfterFilter/filter?categorySelected='
						+ categorySelected + '&logged=' + logged + "&fromDate="
						+ fromDate + "&toDate=" + toDate);
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}

});



