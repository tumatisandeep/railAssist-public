var app = angular.module("myApp",[]);

app.controller("Ctrl",Ctrl);

function Ctrl(Detailserv){
var self=this;
this.xyz="from controller";
this.allItemsDataLoaded=false;

this.allItemsData=[]
this.getAllItemsData=function(uniqueNumber)
{
	
	Detailserv.getAllItemsData(uniqueNumber)
	.then(function(data){

		self.allItemsData = data;
		self.allItemsDataLoaded = true;

	})
	

}

}


app.service("Detailserv",function($http){

	var self = this;


	self.getAllItemsData=function(uniqueNumber)
	{
		    		var promise1 = $http.get('/RailAssist/getAllItemsData/' + uniqueNumber);
		    		var promise2 = promise1.then(function(response){
		    			return response.data;
		    		});
		    		return promise2;

		    	
		
	}
	
});

