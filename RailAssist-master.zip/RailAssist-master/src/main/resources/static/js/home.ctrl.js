var app = angular.module('myApp', [ 'ngMaterial', 'ngMessages',
		'material.svgAssetsCache' ]);



/*app.run(function($rootScope,DataService) {
	poData
	
	
	var self=this

	$rootScope.scope="abcdef"	
	//alert($rootScope.scope+" root scope")
	rootScopeFunction()	

	$rootScope.chart1=[]
	$rootScope.chart2=[]
	$rootScope.chart3=[]
	$rootScope.chart4=[]
	
	$rootScope.data1=[]
	$rootScope.data2=[]
	$rootScope.data3=[]
	$rootScope.data4=[]
	

		function rootScopeFunction() {

		//alert("hihihhih")

		DataService.getChartsData().then(function(data) {

			console.log(data)
			$rootScope.chart1months = []
			$rootScope.categoryInfo = []
			angular.forEach(data, function(value, key) {

				$rootScope.chart1months.push(value)
				$rootScope.categoryInfo.push(key)

			})
			console.log($rootScope.chart1months)
			console.log($rootScope.categoryInfo)
			$rootScope.chart1 = $rootScope.chart1months[0]

			console.log($rootScope.chart1)
			$rootScope.chart2 = $rootScope.chart1months[1]

			$rootScope.chart3 = $rootScope.chart1months[2]

			$rootScope.chart4 = $rootScope.chart1months[3]

			$rootScope.data1 = $rootScope.categoryInfo
			console.log($rootScope.data1)

			$rootScope.data2 = $rootScope.categoryInfo

			$rootScope.data3 = $rootScope.categoryInfo

			$rootScope.data4 = $rootScope.categoryInfo

		})

	}
	
	
		
});*/



app.controller("Ctrl", Ctrl);



function Ctrl(DataService, $scope, $mdDialog, $q, $timeout, $http, $window) {
	var self = this;
	this.titleOfPage = " Home | RAIL Assist";
	this.divName = "Indent Details"
	this.showIndentDataDiv = true;
	this.showPoDataDiv = false;
	this.showItemsIssuingDataDiv = false;
	this.showItemsReceivedDataDiv = false;
		
	this.getChartsData=function(){

		
		DataService.getChartsData().then(function(data) {
			
			self.chart1months=[]
			self.categoryInfo=[]
			angular.forEach(data, function(value, key){
				
				self.chart1months.push(value)
				self.categoryInfo.push(key)

				
			})

			
			self.chart1=self.chart1months[0]
			self.chart2=self.chart1months[1]
			
			self.chart3=self.chart1months[2]
			
			self.chart4=self.chart1months[3]
			
			self.data1 = self.categoryInfo
			
			self.data2 = self.categoryInfo

			self.data3 = self.categoryInfo
			
			self.data4 = self.categoryInfo

			
			/*			console.log("chart :: "+self.chart1+" data :: "+self.data1)			
			console.log("chart :: "+self.chart2+" data :: "+self.data2)
			console.log("chart :: "+self.chart3+" data :: "+self.data3)
			console.log("chart :: "+self.chart4+" data :: "+self.data4)

			

			self.chart1 = [ 'January', 'February', 'March', 'April', 'May', 'June',
			'July', 'May' ]
	self.chart2 = [ 'January', 'February', 'March', 'April', 'May', 'June' ]

	self.chart3 = [ 'January', 'February', 'March', 'April', 'May', 'June' ]

	self.chart4 = [ 'Bom', 'February', 'March', 'April', 'May', 'June', 'July',
			'August', 'September', 'October', 'November', 'December' ]

	self.data1 = [ 78, 81, 80, 45, 34, 12, 40 ]
	self.data2 = [ 1, 18, 9, 17, 34, 22 ]
	self.data3 = [ 65, 59, 84, 84, 51, 55 ]
	self.data4 = [ 78, 81, 80, 65, 58, 75, 60, 75, 65, 60, 60, 75 ]
			
			console.log(":::::::::::::::::::::::::::::After:::::::::::::::::::::::::::::::")
			
			console.log("chart :: "+self.chart1+" data :: "+self.data1)			
			console.log("chart :: "+self.chart2+" data :: "+self.data2)
			console.log("chart :: "+self.chart3+" data :: "+self.data3)
			console.log("chart :: "+self.chart4+" data :: "+self.data4) */
			
			createChart1(self.chart1,self.data1)
	
			createChart2(self.chart2,self.data2)

			createChart3(self.chart3,self.data3)

			createChart4(self.chart4,self.data4)
		
			function createChart1(chart,data){
				// widgetChart1
				var ctx = angular.element(document.getElementById("widgetChart1"));
				if (ctx) {
					ctx.height = 130;
					var myChart = new Chart(ctx, {
						type : 'line',
						data : {
							labels :data,
							type : 'line',
							datasets : [ {
								data : chart,
								label : 'Indnets',
								backgroundColor : 'rgba(255,255,255,.1)',
								borderColor : 'rgba(255,255,255,.55)',
							}, ]
						},
						options : {
							maintainAspectRatio : true,
							legend : {
								display : false
							},
							layout : {
								padding : {
									left : 0,
									right : 0,
									top : 0,
									bottom : 0
								}
							},
							responsive : true,
							scales : {
								xAxes : [ {
									gridLines : {
										color : 'transparent',
										zeroLineColor : 'transparent'
									},
									ticks : {
										fontSize : 2,
										fontColor : 'transparent'
									}
								} ],
								yAxes : [ {
									display : false,
									ticks : {
										display : false,
									}
								} ]
							},
							title : {
								display : false,
							},
							elements : {
								line : {
									borderWidth : 0
								},
								point : {
									radius : 0,
									hitRadius : 10,
									hoverRadius : 4
								}
							}
						}
					});
				}
			}
			
		function createChart2(chart,data){
			//WidgetChart 2
			var ctx = angular.element(document.getElementById("widgetChart2"));
			if (ctx) {
				ctx.height = 130;
				var myChart = new Chart(ctx, {
					type : 'line',
					data : {
						labels : data,
						type : 'line',
						datasets : [ {
							data : chart,
							label : 'Purchase orders',
							backgroundColor : 'transparent',
							borderColor : 'rgba(255,255,255,.55)',
						}, ]
					},
					options : {

						maintainAspectRatio : false,
						legend : {
							display : false
						},
						responsive : true,
						tooltips : {
							mode : 'index',
							titleFontSize : 12,
							titleFontColor : '#000',
							bodyFontColor : '#000',
							backgroundColor : '#fff',
							titleFontFamily : 'Montserrat',
							bodyFontFamily : 'Montserrat',
							cornerRadius : 3,
							intersect : false,
						},
						scales : {
							xAxes : [ {
								gridLines : {
									color : 'transparent',
									zeroLineColor : 'transparent'
								},
								ticks : {
									fontSize : 2,
									fontColor : 'transparent'
								}
							} ],
							yAxes : [ {
								display : false,
								ticks : {
									display : false,
								}
							} ]
						},
						title : {
							display : false,
						},
						elements : {
							line : {
								tension : 0.00001,
								borderWidth : 1
							},
							point : {
								radius : 4,
								hitRadius : 10,
								hoverRadius : 4
							}
						}
					}
				});
			}
				
			}


		function createChart3(chart,data){
			

			//WidgetChart 3
			var ctx = angular.element(document.getElementById("widgetChart3"));
			if (ctx) {
				ctx.height = 130;
				var myChart = new Chart(ctx, {
					type : 'line',
					data : {
						labels : data,
						type : 'line',
						datasets : [ {
							data : chart,
							label : 'Items received',
							backgroundColor : 'transparent',
							borderColor : 'rgba(255,255,255,.55)',
						}, ]
					},
					options : {

						maintainAspectRatio : false,
						legend : {
							display : false
						},
						responsive : true,
						tooltips : {
							mode : 'index',
							titleFontSize : 12,
							titleFontColor : '#000',
							bodyFontColor : '#000',
							backgroundColor : '#fff',
							titleFontFamily : 'Montserrat',
							bodyFontFamily : 'Montserrat',
							cornerRadius : 3,
							intersect : false,
						},
						scales : {
							xAxes : [ {
								gridLines : {
									color : 'transparent',
									zeroLineColor : 'transparent'
								},
								ticks : {
									fontSize : 2,
									fontColor : 'transparent'
								}
							} ],
							yAxes : [ {
								display : false,
								ticks : {
									display : false,
								}
							} ]
						},
						title : {
							display : false,
						},
						elements : {
							line : {
								borderWidth : 1
							},
							point : {
								radius : 4,
								hitRadius : 10,
								hoverRadius : 4
							}
						}
					}
				});
			}
			
			
		}
			
		
		

		function createChart4(chart,data){
			
			//WidgetChart 4
			var ctx = angular.element(document.getElementById("widgetChart4"));
			if (ctx) {
				ctx.height = 115;
				var myChart = new Chart(ctx, {
					type : 'bar',
					data : {
						labels : data,
						datasets : [ {
							label : "Challans",
							data : chart,
							borderColor : "transparent",
							borderWidth : "0",
							backgroundColor : "rgba(255,255,255,.3)"
						} ]
					},
					options : {
						maintainAspectRatio : true,
						legend : {
							display : false
						},
						scales : {
							xAxes : [ {
								display : false,
								categoryPercentage : 1,
								barPercentage : 0.65
							} ],
							yAxes : [ {
								display : false
							} ]
						}
					}
				});
			}
		}
			
		})

		
		
	}
	

	self.tabs = [ {
		title : 'Indent details',
		id : 1
	}, {
		title : 'Purchase order details',
		id : 2
	}, {
		title : 'Items received details',
		id : 3
	}, {
		title : 'Challan details',
		id : 4
	} ]

	this.tabClicked = function(tabId) {
		if (tabId == 1) {
			self.divName = "Indent Details"
			self.showIndentDataDiv = true;
			self.showPoDataDiv = false;
			self.showItemsIssuingDataDiv = false;
			self.showItemsReceivedDataDiv = false;

		}

		else if (tabId == 2) {

			DataService.getPoData().then(function(data) {
				self.poData = data;
				self.divName = "Po Details"
				self.showIndentDataDiv = false;
				self.showPoDataDiv = true;
				self.showItemsIssuingDataDiv = false;
				self.showItemsReceivedDataDiv = false;
			})

		}

		else if (tabId == 3) {

			DataService.getItemsReceivedData().then(function(data) {
				self.itemsReceivedData = data;
				self.divName = "Items received Details"
				self.showIndentDataDiv = false;
				self.showPoDataDiv = false;
				self.showItemsIssuingDataDiv = false;
				self.showItemsReceivedDataDiv = true;
			})

		}

		else if (tabId == 4) {

			DataService.getItemsIssuedData().then(function(data) {
				self.itemsIssuedData = data;
				self.divName = "Items issued Details"
				self.showIndentDataDiv = false;
				self.showPoDataDiv = false;
				self.showItemsIssuingDataDiv = true;
				self.showItemsReceivedDataDiv = false;
			})

		}

	}
	
	//alert($scope.chart1+"111")
	


	


	

}




(function ($) {
 // USE STRICT
 "use strict";
 
 // Dropdown
 try {
 var menu = $('.js-item-menu');
 var sub_menu_is_showed = -1;
 for (var i = 0; i < menu.length; i++) {

 $(menu[i]).on('click', function (e) {
               e.preventDefault();
               $('.js-right-sidebar').removeClass("show-sidebar");
               if (jQuery.inArray(this, menu) == sub_menu_is_showed) {
               $(this).toggleClass('show-dropdown');
               sub_menu_is_showed = -1;
               }
               else {
               for (var i = 0; i < menu.length; i++) {
               $(menu[i]).removeClass("show-dropdown");
               }
               $(this).toggleClass('show-dropdown');
               sub_menu_is_showed = jQuery.inArray(this, menu);
               }
               });
 }
 $(".js-item-menu, .js-dropdown").click(function (event) {
                                        event.stopPropagation();
                                        });
 
 $("body,html").on("click", function () {
	 
                   for (var i = 0; i < menu.length; i++) {
                   menu[i].classList.remove("show-dropdown");
                   }
                   sub_menu_is_showed = -1;
                   });
 
 } catch (error) {
 console.log(error);
 }
 
 
 })(jQuery);


app.service("DataService", function($http) {

	var self = this;

	self.getPoData = function() {
		var promise1 = $http.get('/RailAssist/getPoData');
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}

	self.getItemsIssuedData = function() {
		var promise1 = $http.get('/RailAssist/itemsIssuedData');
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}

	self.getItemsReceivedData = function() {
		var promise1 = $http.get('/RailAssist/itemsReceivedData');
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}

	self.getChartsData=function() {
		var promise1 = $http.get('/RailAssist/getChartsData');
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}
	
});

