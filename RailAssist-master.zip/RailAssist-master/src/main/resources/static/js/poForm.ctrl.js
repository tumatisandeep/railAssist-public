var app = angular.module("myApp", [ 'angular-loading-bar', 'ngAnimate' ]);

app.controller("Ctrl", Ctrl);

function Ctrl(Detailserv, $http, $window) {
	this.indentIdDataList = [];
	this.showIndentData = false;
	this.showIndentInfo=false;
	this.addNewIndent = false;
	var self = this;
	this.airPrice = 0;
	self.amount = 0;
	this.formData = [];
	this.poAlreadyPresent = false;
	this.isIndentDataFound=false;
	this.showIndentNotFoundError=false;
	this.indentDataPOReceived = false;
	self.priceCalculated=false


	self.maxDate=new Date()

	
	this.submitPOData = function() {
		self.formData.push(self.poNumber);
		self.formData.push(self.tenderType);
		self.formData.push(self.openedDate);
	    self.formData.push(self.serialNo);
		self.formData.push(self.indentIdDataList);
		self.formData.push(angular.element(document.getElementById("vendor")).val());
		self.formData.push(self.impDate);
		self.formData.push(self.indDate);
		self.formData.push(self.omcDate);

		$http({
			'url' : '/RailAssist/submitPoForm',
			'method' : 'POST',
			'headers' : {
				'Content-Type' : 'application/json'
			},
			'data' : self.formData
		}).then(function(data,status, headers, config) {
			
			var jsonString=angular.toJson(data.data)
				$window.location.href = '/RailAssist/returnToHomeFromPo?response='+encodeURI(jsonString);



		})

		/*
		 * $.ajax({
		 * 
		 * url : "submitPoForm", async : false, type : 'POST', data : { info :
		 * self.formData }, success : function(response) { if (response ==
		 * "true") { $window.location.href = '/'; } }, error : function(xhr,
		 * status, error) { alert("Problem"); } });
		 */

	}

	this.addIndent = function(indentId, basicPrice, gst,qtyReceived,itemCategory) {
		self.contains = null;
		if (self.indentIdDataList.length == 0) {
			self.indentIdDataList.push({
				'indentId' : indentId,
				'price' : basicPrice,
				'gst' : gst,
				'qtyReceived':qtyReceived,
				'itemCategory':itemCategory
			});
			

			self.indentTextField = null;
			self.showIndentData = false;


		} else {
			for (var i = 0; i < self.indentIdDataList.length; i++) {
				if (self.indentIdDataList[i].indentId == indentId) {
					alert("Indent ID alreay added in this list");
					self.indentTextField = null;
					self.contains = "true;"
					self.showIndentData = false;

					return;
				}

			}
			if (self.contains != "true") {
				self.indentIdDataList.push({
					'indentId' : indentId,
					'price' : basicPrice,
					'gst' : gst,
					'qtyReceived':qtyReceived,
					'itemCategory':itemCategory
				});

				self.indentTextField = null;

			}

		}
		self.showIndentData = false;
		self.showIndentNotFoundError=false
		self.gst=null;
		self.basicPrice=null;
		self.airPrice=null;
		self.amount=null;
		self.qtyReceived=null
		self.priceCalculated=false

	}

	this.getIndentData = function(indentId) {

		Detailserv.getIndentData(indentId).then(function(data) {
		
			self.disableOnCalculate=false

			
			self.indentData = data;
			//console.log(self.indentData)
			if(self.indentData.null)
				{
				self.indentDataPOReceived=false
				self.isIndentDataFound=false;
				self.showIndentInfo=false;
				self.showIndentNotFoundError=true
				

				}
			else{
				
		
			if (self.indentData.poReceived)
				{
				self.showIndentNotFoundError=false
				self.indentDataPOReceived = true;
				self.showIndentInfo=false;
				self.isIndentDataFound=true;


				}
			else {
				self.disableOnCalculate=false
				self.showIndentNotFoundError=false
				self.indentDataPOReceived = false;
				self.showIndentInfo=true;
				self.isIndentDataFound=true;

		}
			
			}
		})

		self.showIndentData = true;
		self.addNewIndent = true;
	}
	
	this.restrictToQtyReq=function(){
		
		if(self.qtyReceived>(angular.element(document.getElementById("qty")).val()-angular.element(document.getElementById("qtyRcvd")).val()))
			self.qtyReceived=(angular.element(document.getElementById("qty")).val()-angular.element(document.getElementById("qtyRcvd")).val());
		
		if(self.qtyReceived<0)
			self.qtyReceived=0
		
	}

	this.calculatePrice = function(basicPrice, gst) {
		self.disableOnCalculate=true
		self.airPrice = parseFloat(basicPrice)
				+ parseFloat((basicPrice * gst) / 100)

		self.amount = (self.airPrice)
				* (angular.element(document.getElementById("qtyReceivedtForIndent")).val());
		
		self.priceCalculated=true
	}

	this.removeFromJson = function(indentId) {
		for (var i = 0; i < self.indentIdDataList.length; i++) {

			if (self.indentIdDataList[i] == indentId) {	
				self.indentIdDataList.splice(i, 1);

				return;
				
			}
		}
	}

	this.checkIfPoExists = function(poNumber) {
		
		if(poNumber !=undefined)
		poNumber=poNumber.replace("/","$")

		Detailserv.checkIfPoExists(poNumber).then(function(data) {
			if (data)
				self.poAlreadyPresent = true;
			else
				self.poAlreadyPresent = false;

		})
	}

}

app.service("Detailserv", function($http) {

	var self = this;
	self.getIndentData = function(indentId) {

		var promise1 = $http.get('/RailAssist/getIndentData/' + indentId);
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}

	self.checkIfPoExists = function(poNumber) {

		var promise1 = $http.get('/RailAssist/checkIfPoPreasent/' + poNumber);
		var promise2 = promise1.then(function(response) {
			return response.data;
		});
		return promise2;

	}

});
