
var app = angular.module('myApp', ['ngMaterial', 'ngMessages', 'material.svgAssetsCache']);
  var isDlgOpen;

app.controller("Ctrl",Ctrl);

app.controller("DialogController",DialogController)

function Ctrl(DataService,$scope,$mdDialog,$mdToast,$mdSidenav,$http){
	
  var self=this
      self.hidden = false;
	  self.dataLoaded=false
      self.isOpen = false;
      self.hover = false;
      self.hidden = false;
      self.isOpen = false;
      self.hover = false;
      self.pageNumber=1;
      self.filteredDataFound=false
      self.filterOnData=[];
      self.noFilterApplied=true
	  self.loadingStarted=false
	  self.allItemsForCat=[]
	  self.dataForThisTab=[]
	  self.tabClosed=true
	  
	  self.reset=false
   

		  this.searchOnSelected = function() {
		if (self.searchOn == 1)
			self.searchOnName = "Description"
		else if (self.searchOn == 2)
			self.searchOnName = "Part Number"
		else if (self.searchOn == 3)
			self.searchOnName = "IDN"

	}

    	  this.tabsData=function()
    	  {
    	  
    	  
    		DataService.tabsData()
          	.then(function(data){
          		
          		self.dataForThisTab=data
          		
      			self.allItemsForCat.push(self.dataForThisTab)
      			
          		//console.log(self.allItemsForCat)

          		self.dataLoaded=false
          		
          		
          	})
    	  
    	  
    	  }
    	  
      
    	  this.changeAllSerchCriteriaValues=function(){
    		  
    		  self.searchOnText=undefined;
    		  self.stockAvailable=undefined
    		  self.stockRange=undefined
    		 self.stockLessThan=undefined
    		 self.stockGreaterThan=undefined
    		  
    	  }
    	  
    	  
    	  this.addTab=function(category)
     	  {

		self.dataLoaded = true
		DataService
				.addTab(category)
				.then(
						function(data) {

							self.dataForThisTab = data;
							// console.log(self.dataForThisTab)

							self.present = false;

							for (var i = 0; i < self.allItemsForCat.length; i++) {

								if (self.dataForThisTab[0].groupId == self.allItemsForCat[i][0].groupId) {
									self.present = true;
									self.allItemsForCat.splice(i, 1);

									self.allItemsForCat.splice(i, 0,
											self.dataForThisTab)
									self.dataFound = true
									self.dataLoaded=false

									return		

								}

							}

							if (!self.present) {

								self.allItemsForCat.push(self.dataForThisTab)

							}
							//console.log(self.allItemsForCat)

							self.dataFound = true
							self.dataLoaded=false

						})

	}
    	  
      
      this.tabClicked=function(cat)
      {
    	  
    	  self.tabClosed=false
    	  self.dataLoaded=true
      	DataService.tabClicked(cat)
      	.then(function(data){
      		self.allItemsForCat = data;  
      		self.dataLoaded=false
      	})
      		
    	  
      }
      
      
      this.resetFilter=function()
      {
    	  
    	  self.loadingStarted=true
    	  
    	  
    	  
    	  self.reset=true
    	  
    	  self.cat=undefined
    	  
    	  self.searchOn=undefined
    	  
    	  self.stockAvailable=undefined
    	  
    	 self.stockGreaterThan-undefined
    	  
    	 self.stockLessThan=undefined
    	 
    	 self.stockRange=false
    	 
    	 self.filteredDataFound=false
    	 
    	 self.filteredDataResult=[]
    	  
    	  self.noFilterApplied=true
    	  
    	  self.loadingStarted=false


        	  for(var i=0;i<self.allItemsForCat.length;i++)
				{
				
				if(10==self.allItemsForCat[i][0].groupId)
				{
    	      		self.present=true;
    	      		//alert("search results found")
    	      		self.allItemsForCat.splice(i, 1);

				}
				
				}
        	  
        	  
    	  
      }
      
      this.getFilteredData=function()
      {
    	  
    	  self.filteredDataFound=false
    	  self.noFilterApplied=false
    	  self.loadingStarted=true
    	  self.filterOnData=[]
    	    	  
    	  
    	  self.filterOnData.push({
  				'selectedType' : "category",
  				'value' :parseInt(self.cat),
  				'value1' : 0,
  				'value2':0
  			});
    	  
    	  
    	  if(self.searchOn==undefined)
    		  {
    		      		  
    		  self.filterOnData.push({
  				'selectedType' : "searchOn",
  				'value' : 0,
  				'value1' : 0,
  				'value2':0
  			});
      	  
    		  
    		  }
    	  else
    		  {
    		  if(self.searchOn==1)
    		  self.showAdvancedSearch=true

    		  self.filterOnData.push({
    				'selectedType' : "searchOn",
    				'value' :parseInt(self.searchOn) ,
    				'value1' :self.searchOnText ,
    				'value2':0
    			});
    		  }
    	  
    	  if(self.stockAvailable==undefined)
    		  {
		  
		  self.filterOnData.push({
				'selectedType' : "stockAvailable",
				'value' : 0,
				'value1' : 0,
				'value2':0
			});    		  
    		  
    		  }
    	  
    	  else
    		  {
    		  self.filterOnData.push({
  				'selectedType' : "stockAvailable",
  				'value' : parseInt(self.stockAvailable),
  				'value1' : 0,
  				'value2':0
  			});  
    		  
    		  }
    	  
    	  
    	  
    	  if(self.stockRange)
    		  {
    		  
    		  self.filterOnData.push({
    				'selectedType' : "stockRange",
    				'value' : 1,
    				'value1' : self.stockGreaterThan,
    				'value2':self.stockLessThan
    			});  
    		  
    		  
    		  }
    	  
    	  else
    		  {
    		
    		  self.filterOnData.push({
  				'selectedType' : "stockRange",
  				'value' : 0,
  				'value1' : 0,
  				'value2':0
  			});  
    		  
    		  
    		  }
    	  
    	  
    	 /* DataService.getFilteredData(self.filterOnData)
        	.then(function(data){
        		
        		
        		
        		
        	})
    	  */
    	  
    	  $http({
  			'url' : '/RailAssist/applyFilterData',
  			'method' : 'POST',
  			'headers' : {
  				'Content-Type' : 'application/json'
  			},
  			'data' : self.filterOnData
  		}).then(function(data,status, headers, config) {
  			
  			//console.log(data.data)
  		//	alert(data.data[0].dataPresent=="dataPresent")
  			if(data.data[0].dataPresent=="dataPresent")
  			{
 				//alert("inside if")
  				self.dataForThisTab=data.data
  				
  				//self.filteredDataFound=true
  				
  				self.reset=true  				

  				self.present=false
  				
  				for(var i=0;i<self.allItemsForCat.length;i++)
  				{
  				
  				if(self.dataForThisTab[0].groupId==self.allItemsForCat[i][0].groupId)
  				{
  					//alert("found")

  					
      	      		self.present=true;
      	      	self.allItemsForCat.splice(i, 1);

      	      	self.allItemsForCat.splice(i,0,self.dataForThisTab)
      	      	      		self.dataLoaded=false
      	    				self.loadingStarted=false

      	      		return		  				
 				
  				}  				
  				}
  				
  			
  			
  		if(!self.present)
  			{
  			
  			self.allItemsForCat.push(self.dataForThisTab)
				self.loadingStarted=false

  			
  			}
  	      			//self.allItemsForCat.push(data.data)

  			self.dataFound=true		
  				
  				
  			
  			}
  			
  			else{
  				
  				//alert("inside else")
  				
  		  			self.dataFound=false
  		  			//alert(self.dataFound)

  				self.dataForThisTab=data.data
  				
  				
  				self.filteredDataFound=true
  				
  				self.reset=true  				

  				self.present=false
  				
  				for(var i=0;i<self.allItemsForCat.length;i++)
  				{
  					//alert(self.allItemsForCat[i][0].groupId)
  				
  				if(10==self.allItemsForCat[i][0].groupId)
  				{
      	      	//alert("match found with "+self.allItemsForCat[i][0].groupId)	
  					self.present=true;
      	      	self.allItemsForCat.splice(i, 1);

      	      	self.allItemsForCat.splice(i,0,self.dataForThisTab)
      	      	      		self.dataLoaded=false
      	    				self.loadingStarted=false

      	      		return		  				
 				
  				}  				
  				}
  				
  			
  			
  		if(!self.present)
  			{
  			//console.log(self.dataForThisTab)
  			self.allItemsForCat.push(self.dataForThisTab)
				self.loadingStarted=false

  			
  			}
  	      			//self.allItemsForCat.push(data.data)

			self.dataFound=false
			//console.log(self.allItemsForCat[0][0]+" searh")
			
							//self.allItemsForCat[0][0].groupId=10

				//self.allItemsForCat[0][0].categoryString="search results"

  			//alert(self.dataFound+" inside")	
  			
  			}
  			
  			//alert(self.dataFound+"ouside")
  		//	console.log(data.data+" "+self.dataFound)
  			
				self.noFilterApplied=true

  			
  			// have to reset all parameters
  			
  		})
    	  
    	  
      }
      
      
      this.loadMore=function(cat)
      {
    	  
    	  self.dataLoaded=true
        	DataService.loadMore(pageNumber)
          	.then(function(data){
          		self.allItemsForCat = data;  
          		self.dataLoaded=false
          	})
    	  
      }
      
      
      self.items = [
        { name: "Twitter", icon: "img/icons/twitter.svg", direction: "bottom",display:false },
        { name: "Facebook", icon: "img/icons/facebook.svg", direction: "top" ,display:false},
        { name: "Google Hangout", icon: "img/icons/hangout.svg", direction: "bottom" ,display:false}
      ];

	
	this.dataLoadedFunc=function(){
		
		if(self.dataLoaded)
		self.dataLoaded=false
	else
		self.dataLoaded=true;
	}
	
	this.showCustomToast = function() {
        $mdToast.show({
	  hideDelay: 0,
          position    : 'top right',
          controller  : 'ToastCtrl',
          templateUrl : 'toast-template.html'
        });
      };

	  this.closeToast = function() {
		//  alert(isDlgOpen)
        if (isDlgOpen) return;

        $mdToast
          .hide()
          .then(function() {
            isDlgOpen = false;
          });
      };
	
	
	$scope.showAdvanced = function(ev,id) {
    $mdDialog.show({
		locals:{dataToPass: id},
      controller: DialogController,
      templateUrl: 'dialog1.tmpl.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:false,
      fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
    })
    .then(function(answer) {
      $scope.status = 'You said the information was "' + answer + '".';
    }, function() {
      $scope.status = 'You cancelled the dialog.';
    });
  };

}

 function DialogController(DataService,$scope, $mdDialog,dataToPass) {
	 
	 
	 
	 $scope.dataToPass=dataToPass
	 
	 	$scope.tableDataLoading=false
	 	$scope.recentChallansDataLoaded=false
		$scope.recentIndentsLoaded = false  
		$scope.recentPoLoaded=false
		
		$scope.recentChallansDataNotPresent=false
		$scope.recentIndentsNotPresent = false  
		$scope.recentPoNotPresent=false

	 
	 if(dataToPass)
		 {
		 
		 $scope.getDataOfItem=function(cat)
	     {
	   	  
	   	  $scope.itemDataLoaded=true
	     	DataService.getDataOfItem(cat)
	     	.then(function(data){
	     		$scope.itemDataForDialog = data;  
	     	})
	     		
	   	  
	     }
		 
		 $scope.getDataOfItem(dataToPass)
		 
		 }
	 
	 
	
	 $scope.recentChallans=function(item)
	 {
		 $scope.tableDataLoading=true
	     	DataService.recentChallans(item)
	     	.then(function(data){
	     		$scope.recentChallansData = data;  
	    		if($scope.recentChallansData.length!=0)	
	     		$scope.recentChallansDataLoaded=true
	     		else	
	  	     		$scope.recentChallansDataNotPresent=true
	     			
	    		$scope.recentIndentsNotPresent = false  
	    		$scope.recentPoNotPresent=false
	    		$scope.recentIndentsLoaded = false  
	    		$scope.recentPoLoaded=false
	    		$scope.tableDataLoading=false
	     	})
		 
	 }
	 
	 
	 $scope.recentIndents=function(item)
	 {
		 $scope.tableDataLoading=true		
	     	DataService.recentIndents(item)
	     	.then(function(data){
	     	$scope.recentIndentsData = data;  
	     	$scope.recentChallansDataLoaded=false
    		if($scope.recentIndentsData.length!=0)
	    		$scope.recentIndentsLoaded = true  
	    		else	
		    $scope.recentIndentsNotPresent=true
		   
		    
		    $scope.recentChallansDataNotPresent = false  
    			$scope.recentPoNotPresent=false
	    		$scope.recentPoLoaded=false
	    		$scope.tableDataLoading=false
	     	})
	     	
		 
	 }
	 
	
	 $scope.recentPo=function(item)
	 {
		 $scope.tableDataLoading=true
		 
	     	DataService.recentPo(item)
     	.then(function(data){
	     		$scope.recentPoLoadedData = data;  
	     		$scope.recentChallansDataLoaded=false
	    		$scope.recentIndentsLoaded = false  
	    		
	    		if($scope.recentPoLoadedData.length!=0)
	    			$scope.recentPoLoaded=true
	    		else	
	    		    $scope.recentPoNotPresent=true

	    		    
	    		    $scope.recentChallansDataNotPresent = false  
	        		$scope.recentIndentsNotPresent=false
	    		$scope.tableDataLoading=false
	     	})
		 
	 }
	 
	 $scope.outStandingIndents=function(item)
	 {
		

		 $scope.outStandingIndents=true
	     	DataService.outStandingIndents(item)
	     	.then(function(data){
	     		$scope.itemDataOnClick = data;  
	     	})
		 
	 }
	 
	 
	 $scope.outStandingPo=function(item)
	 {

		 
		 $scope.outStandingPo=true
	     	DataService.outStandingPo(item)
	     	.then(function(data){
	     		$scope.itemDataOnClick = data;  
	     	})
		 
	 }
	 
	 
	 $scope.recentOperations=function(item)
	 {
		

		 
		 $scope.recentOperations=true
	     	DataService.recentOperations(item)
	     	.then(function(data){
	     		$scope.itemDataOnClick = data;  
	     	})
		 
	 }
	 
	 
	 
	 
	 
	 
	 
	 
    $scope.hide = function() {
      $mdDialog.hide();
    };

    $scope.cancel = function() {
      $mdDialog.cancel();
    };

    $scope.answer = function(answer) {
      $mdDialog.hide(answer);
    };
  }



  
  
  
  
  app.service("DataService",function($http){
		

		var self = this;
		
		self.tabClicked = function(catId){
			    		var promise1 = $http.get('/RailAssist/getAllElementsInCat/'+catId);
			    		var promise2 = promise1.then(function(response){
			    			return response.data;
			    		});
			    		return promise2;

			    	}
		
	
		
		self.loadMore = function(catId){
			    		var promise1 = $http.get('/RailAssist/getAllElementsInCat/'+catId);
			    		var promise2 = promise1.then(function(response){
			    			return response.data;
			    		});
			    		return promise2;

			    	}
		
		
		
		
		self.getDataOfItem=function(itemId){
    		var promise1 = $http.get('/RailAssist/getDataOfItemForDialog/'+itemId);
    		var promise2 = promise1.then(function(response){
    			return response.data;
    		});
    		return promise2;

    	}
		
		self.recentChallans=function(itemId){
    		var promise1 = $http.get('/RailAssist/recentChallans/'+itemId);
    		var promise2 = promise1.then(function(response){
    			return response.data;
    		});
    		return promise2;

    	}
		
		
		self.recentIndents=function(itemId){
    		var promise1 = $http.get('/RailAssist/recentIndents/'+itemId);
    		var promise2 = promise1.then(function(response){
    			return response.data;
    		});
    		return promise2;

    	}	
		
		
		
		self.recentPo=function(itemId){
    		var promise1 = $http.get('/RailAssist/recentPo/'+itemId);
    		var promise2 = promise1.then(function(response){
    			return response.data;
    		});
    		return promise2;

    	}
	
		
		self.outStandingIndents=function(itemId){
    		var promise1 = $http.get('/RailAssist/outStandingIndents/'+itemId);
    		var promise2 = promise1.then(function(response){
    			return response.data;
    		});
    		return promise2;

    	}
		
		
		self.recentOperations=function(itemId){
    		var promise1 = $http.get('/RailAssist/recentOperations/'+itemId);
    		var promise2 = promise1.then(function(response){
    			return response.data;
    		});
    		return promise2;

    	}
			
	
		self.outStandingPo=function(itemId){
    		var promise1 = $http.get('/RailAssist/outStandingPo/'+itemId);
    		var promise2 = promise1.then(function(response){
    			return response.data;
    		});
    		return promise2;

    	}
		
		
	 
		
		self.getFilteredData=function(filteredData)
		{
			
			var promise1 = $http.get('/RailAssist/applyFilterData/'+filteredData);
    		var promise2 = promise1.then(function(response){
    			return response.data;
    		});
    		return promise2;
			
		}
		
self.tabsData=function()
{

	
	var promise1 = $http.get('/RailAssist/tabsData');
	var promise2 = promise1.then(function(response){
		return response.data;
	});
	return promise2;
	


}
	

self.addTab=function(catId)
{


	
	var promise1 = $http.get('/RailAssist/addTab/'+catId);
	var promise2 = promise1.then(function(response){
		return response.data;
	});
	return promise2;
	


	
}
		
	});



