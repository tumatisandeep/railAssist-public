var app = angular.module("myApp", []);

app.controller("Ctrl", Ctrl);

function Ctrl(Detailserv, $http, $window) {
	
	var self = this;
	this.subCatLoaded=false
	this.subCategList=[]
	this.subCategorySelected=false;
	
	this.getSubCat = function(catId){
		Detailserv.getSubCateg(catId)
		.then(function(data){
			self.subCategList = data;
			self.subCatLoaded=true;
		})

		}
	
	this.getItemWithSubCat=function(subCatId)
	{
		
		Detailserv.getItemWithSubCat(subCatId)
		.then(function(data){
			self.itemWithSubCat = data;
			self.subCategorySelected=true;
			
		})
		
		
	}
	
}

app.service("Detailserv", function($http) {
	
	var self = this;

	self.getSubCateg = function(catId){

		var promise1 = $http.get('/RailAssist/getAllItemsSubCat/' + catId);

		var promise2 = promise1.then(function(response){
			return response.data;
		});
		return promise2;

	}
	
	
	
	
	self.getItemWithSubCat = function(subCatId){

		var promise1 = $http.get('/RailAssist/getItemWithSubCat/' + subCatId);

		var promise2 = promise1.then(function(response){
			return response.data;
		});
		return promise2;

	}
	
	
	
});
