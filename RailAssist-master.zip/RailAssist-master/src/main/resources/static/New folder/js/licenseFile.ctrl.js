var app=angular.module("myApp",['ngMaterial', 'ngMessages', 'material.svgAssetsCache']);
app.controller("Ctrl",Ctrl);



app.config(function($mdIconProvider) {
  $mdIconProvider
    .iconSet("call", 'img/icons/sets/communication-icons.svg', 24)
    .iconSet("social", 'img/icons/sets/social-icons.svg', 24);
})



function Ctrl($http,$window){
	
	this.openMenu = function($mdMenu, ev) {
	    originatorEv = ev;
	    $mdMenu.open(ev);
	  };
	  
	  
	var self=this;
	this.count=1;

	this.finalData1=[];
	this.ipMac=[{"count":0,"ip":"","mac":""}];
	
	this.buttonClicked=function()
	{
	self.ipMac.push({ "count":self.count,"ip":angular.element(document.getElementById("generateFile.ip_"+self.count)).val(),
		"mac":angular.element(document.getElementById("generateFile.mac_"+self.count)).val()});
		
	self.count=self.count+1;
	}
	
	
	this.dummyButton=function(){
		
		alert("11");
		self.finalData={"bankId":angular.element(document.getElementById("bankId")).val(),"json":angular.element(document.getElementById("bankId")).val()};

		//self.finalData={"bankId":angular.element(document.getElementById("bankId")).val(),"json":self.ipMac};
		self.finalData1.push({"bankId":angular.element(document.getElementById("bankId")).val(),"json":self.ipMac});
	}
	this.submitForm=function()
	{
	self.ipMac.push({ "count":self.count,"ip":angular.element(document.getElementById("generateFile.ip_"+self.count)).val(),
			"mac":angular.element(document.getElementById("generateFile.mac_"+self.count)).val()});
			self.count=self.count+1;
		alert(angular.element(document.getElementById("bankId")).val())
		
		//self.finalData.push({"bankId":angular.element(document.getElementById("bankId")).val(),"json":JSON.stringify(self.ipMac)})
		var bankId1=angular.element(document.getElementById("bankId")).val();
		self.finalData={"bankId":angular.element(document.getElementById("bankId")).val(),"json":self.ipMac};


		$http({
	        'url' : '/SFMSAssist/createLicenseFile',
	        'method' : 'POST',
	        'headers': {'Content-Type' : 'application/json'},
	        'data' : self.finalData
	    }).then(function(data,status, headers, config){
	       alert("License file generated succesfully");
           $window.location.href = '/SFMSAssist/generateLicenseFile';

	    })
		
		
	/*$http.post('/SFMSAssist/createLicenseFile', self.finalData)
	.then(function(data,status, headers, config)
			{
		
		alert("Group created succesfully");
	    
			});*/
	    	  
	}
}