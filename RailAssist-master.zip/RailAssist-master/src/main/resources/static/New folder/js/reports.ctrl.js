

var app = angular.module("myApp",['angular-loading-bar', 'ngAnimate']);


app.controller("Ctrl",Ctrl);

function Ctrl(){

this.xyz = "from controller";
this.minDate=this.fromDate;
/*this.fDate=new Date();
*/
this.maxDate=new Date();





}



