function getSocketCon(empId)
{
	$( ".sampleChats" ).remove();
	var sender = $("#sender").val();

	
	$.ajax({
		url : "/SFMSAssist/activeusers/" + sender + "/" + empId,

	});
	
    
	var socket = new SockJS('/SFMSAssist/hello');
	socket.onopen = function() {
	};
	stompClient = Stomp.over(socket);
	stompClient.connect({}, function(frame) {
		
		console.log('Connected: ' + frame);
		stompClient.subscribe('/SFMSAssist/topic/greetings/' + sender + '/' + empId,
				function(greeting) {
					showGreeting(JSON.parse(greeting.body).content,empId);
					//showGreeting(greeting);
				});
	});

	}



function scrollDown(empId)
{
	var divId=empId;

	var timerId=setInterval(function() {
		   if ($("#"+divId+"_div").length) {
		      $("#"+divId+"_div").scrollTop($("#"+divId+"_div")[0].scrollHeight);
		      clearInterval(timerId);
		   }
		}, 100);

}

/*function subStringData(data){
	console.log(data);
	var data1=data.toString().substr(1,data.length-2);
	
	
	return data1;

}*/

function showGreeting(message,receiver) {
	


	var sender = $("#sender").val();


	var arr = message.split('$@*');
	$("#"+receiver+"_div")
			.append(

					'<div class="w3-row sampleChats" ><div class="col-md-8"><div class="w3-container  w3-panel w3-card-4 w3-left " style="background-color: #CFD8DC; border-radius: 19px; margin-left: -4px;">'
							
							+ '<p id="ccontent" class="w3-medium" style="padding-top: 2px;">'
							+ arr[2] + '</p>'
							+ '<p id="cdate" class="w3-tiny text-muted" style="margin-bottom: 0.5px;">'
							+ arr[1]
							+ '</p></div></div><div class="col-md-4"></div></div>'
			);
	
	
	
	$("#"+receiver+"_div").scrollTop($("#"+receiver+"_div")[0].scrollHeight);

}



function sendNameChat(receiverName) {

if($.trim($("#"+receiverName).val())!='' && $.trim($("#"+receiverName).val())!='\n')
		{
	
	var sender = $("#sender").val();

	stompClient.send('/app/hello/' + sender + '/' + receiverName, {}, JSON.stringify({'message' : $("#"+receiverName).val()}));
	
	/*$.ajax({
		url : "store",

		data : $("#form5").serialize()
	});*/

	var now = moment().format("DD-MMM-YYYY hh:mm:ss A");
	var dt = now;


	$("#"+receiverName+"_div")
			.append(

					'<div class="w3-row sampleChats" ><div class="col-md-4"></div><div class="col-md-8"><div class="w3-container  w3-panel  w3-card-4 w3-right" style="background-color: white; border-radius: 19px; margin-right: -4px;">'
							
							+ '<p class="w3-medium" style="padding-top: 2px;">'
							+ $("<div/>").text($("#"+receiverName).val()).html()
							+ '</p>'
							+ '<p id="cdate" class="w3-tiny text-muted" style="margin-bottom: 0.5px;">'
							+ dt
							+ '</p></div></div></div>'
							

			);

	$("#"+receiverName).val('');
	$("#"+receiverName).focus();
	$("#"+receiverName+"_div").scrollTop($("#"+receiverName+"_div")[0].scrollHeight);

	//$('#chatButton').prop('disabled', true);
		}
}


/* ------------------Socket for Group Chat--------------------- */

function getGroupChatSocketCon() 
{
	
	 /*$.ajax({

			url : "/broadcast",

		});*/
	var sender = $("#sender").val();
	 console.log(sender);
	var socket = new SockJS('/SFMSAssist/gs-guide-websocket');
	socket.onopen = function() {
	};
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function (frame) {
        console.log('Connected: ' + frame);
        stompClient.subscribe('/SFMSAssist/test/greetings', function (greeting) {
        	showGroupGreeting(JSON.parse(greeting.body).content);
            
        });
       
    });
	
}


function sendGroupChat() {
	
	var sender = $("#sender").val();
    stompClient.send('/cast/broad/'+sender, {}, JSON.stringify({'message': $("#99999").val()}));
    $("#99999").val('');
    $("#99999").focus();

}

function showGroupGreeting(message)
{
	
	
	var arr = message.split('$@*');
	
	var user = $('#sender').val();
	var now = moment().format("DD-MMM-YYYY hh:mm:ss A");
	var dt = now;
	
if( arr[0].trim() == user){
	$("#99999_div").append(

			'<div class="w3-row " ><div class="col-md-4"></div><div class="col-md-8"><div class="w3-container  w3-panel  w3-card-4 w3-right" style="background-color: white; border-radius: 19px; margin-right: 10px;">'
					
					+ '<p class="w3-medium" style="padding-top: 2px;">'
					+ arr[2] + '</p>'
					+ '<p id="cdate" class="w3-tiny text-muted" style="margin-bottom: 0.5px;">'
					+ dt
					+ '</p></div></div></div>'
					

	);
}else{
	$("#99999_div").append(

			'<div class="w3-row " ><div class="col-md-8"><div class="w3-container  w3-panel w3-card-4 w3-left " style="background-color: #CFD8DC; border-radius: 19px;">'+
			'<p id="cname" class="w3-tiny">'+ arr[3]+'</p>'+
					'<p id="ccontent" class="w3-medium" >'+
					 arr[2] + '</p>'+
					'<p id="cdate" class="w3-tiny text-muted" style="margin-bottom: 0.5px;">'+
					 arr[1]+
				'</p></div></div><div class="col-md-4"></div></div>'
	);
	
}
	
$("#99999_div").scrollTop($("#99999_div")[0].scrollHeight);

}

/* -----------------------End of Socket for Group Chat-----------------------*/

var app = angular.module('myApp', ['ngMaterial','ngMessages', 'material.svgAssetsCache']);

app.controller("Ctrl",Ctrl);

app.controller('ContactChipDemoCtrl', ContactChipDemoCtrl);

function ContactChipDemoCtrl(DataService,$q, $timeout,$scope,$http,$mdDialog)
{
	
	$scope.contacts=[];
    var pendingSearch, cancelSearch = angular.noop;
    var lastSearch;
  
    $scope.contactsJson=[];
    $scope.contactsJson1=[];
    
	DataService.getAutoAssignUserData().then(function(data){
		$scope.allContacts =data.data;
		DataService.getPresentAutoAssignUserData().then(function(data){
			$scope.dbContacts =data.data;
			for(var index=0;index<$scope.dbContacts.length;index++)
			{
			for(var index1=0;index1<$scope.allContacts.length;index1++)
				{
				if($scope.dbContacts[index].empName==$scope.allContacts[index1].empName)
					{
					$scope.contacts.push($scope.allContacts[index1]);
					
					}
				
				}
				
			}
			
		});
		
		
		//$scope.contacts = [$scope.allContacts[0],$scope.allContacts[1],$scope.allContacts[2]];

		
	});
	
	/*DataService.getPresentAutoAssignUserData().then(function(data){
		$scope.contacts =data.data;
		
	});*/
	

    
$scope.addIntoJson=function(id)
{
  for(var index=0;index<$scope.allContacts.length;index++)
  {
if($scope.allContacts[index].empName==id)
{
  $scope.contacts.push($scope.allContacts[index]);
}

  }
}

    $scope.filterSelected = true;

    $scope.querySearch = querySearch;
    $scope.delayedQuerySearch = delayedQuerySearch;

    function querySearch (criteria) {
      return criteria ? $scope.allContacts.filter(createFilterFor(criteria)) : [];

    }

    function delayedQuerySearch(criteria) {
      if ( !pendingSearch || !debounceSearch() )  {
        cancelSearch();

        return pendingSearch = $q(function(resolve, reject) {
          cancelSearch = reject;
          $timeout(function() {

            resolve( $scope.querySearch(criteria) );

            refreshDebounce();
          }, Math.random() * 500, true)
        });
      }

      return pendingSearch;
    }

    function refreshDebounce() {
      lastSearch = 0;
      pendingSearch = null;
      cancelSearch = angular.noop;
    }

    function debounceSearch() {
      var now = new Date().getMilliseconds();
      lastSearch = lastSearch || now;

      return ((now - lastSearch) < 300);
    }

    function createFilterFor(query) {
      var lowercaseQuery = angular.lowercase(query);
      return function filterFn(contact) {
        return (contact.empName.toLowerCase().indexOf(lowercaseQuery) != -1);
      };

    }

    $scope.submitForm=function()
    {
	$http.post('/SFMSAssist/updateGroupDetailsOfAutoAssignedUsers', $scope.contacts)
.then(function(data,status, headers, config)
		{
	
	alert("Group created succesfully");
    $mdDialog.cancel();

	 closeDialog(ev);
	
	

		});
    	  
    
    
    }
    
    function closeDialog(ev){
    			
    	      $mdDialog.cancel();
    	  
    	
    	
    }
    $scope.DataService=DataService;
}




function Ctrl(DataService,$scope,$mdDialog,$q, $timeout,$http,$window){
    var self = this;
    this.titleOfPage=" Home | SFMS Assist";
    this.nextDayShiftData=true;
    this.compOff= true;
this.nextDayShifts=function()
{

	this.nextDayShiftData=false;
	
}
this.shiftComing=function()
{
this.shiftComing=	false
}

this.compOff=function()
{
	this.compOff= false	
}

this.skelDate = function(empId){
	DataService.getSkelDates(empId)
	.then(function(data){
	   self.skelDates=data; 
	})


	}

this.availCompoAndCheckOut = function(){
	
	DataService.availCompoAndCheckOutService(this.skelDate)
	.then(function(data){
		$window.location.href = '/SFMSAssist/';  
	})


	}


if(this.checkIn=="")
	{
	self.allowCheckIn="false";
	}	
	this.xyz="from controller";
	this.result1=[];
	this.totalMessageCount=null;
	this.showSol =false;
	var counter = 1;
	this.tabs = [];
	this.insideData=[];
	this.messageResult=[];
	this.noOfUpdates=0;
     this.highLightedTab=null;
     var selected = null,previous = null;
      
    self.selectedIndex = 0;
    $scope.$watch('selectedIndex', function(current, old){
      previous = selected;

      self.selected = self.messageResult[current];
     
    });

this.tabClicked=function(receiverEmpId)

{
	self.highLightedTab=receiverEmpId;
	//$("#"+receiver+"_div")[0].scrollTop($("#"+receiver+"_div")[0].scrollHeight);
	DataService.updateStatusOfUserAsTabAdded(receiverEmpId)
	.then(function(data){//var self = this;
	    
	})

}


this.removeTab1 = function (index,text) {
      self.messageResult.splice(index, 1,text);
    };



    
    

this.closeTab=function(dataToBeRemoved)
{
	
	
	
	var index =self.messageResult.indexOf(dataToBeRemoved);
	/*alert(index+"index");*/
	self.messageResult.splice(index, 1);
	if(self.highLightedTab==dataToBeRemoved[0].receiverEmpId && self.messageResult.length>0 )
		{
		if(index==self.messageResult.length)
		{			


			var previousEmpId=self.messageResult[index-1][0].receiverEmpId;
			DataService.updateStatusOfUserAsTabAdded(previousEmpId)
			.then(function(data)
			{
				self.highLightedTab=previousEmpId;
			})
			
		}
		
		else {

			var previousEmpId=self.messageResult[index][0].receiverEmpId;
			
			DataService.updateStatusOfUserAsTabAdded(previousEmpId)
			.then(function(data)
			{
				self.highLightedTab=previousEmpId;

			})
		
		}
	
	
}
	
	
	
/*	
	if(index==self.messageResult.length&&self.messageResult.length>0 )
{	
				if(self.highLightedTab==self.messageResult[index][0].receiverEmpId){
					alert("1")
		var previousEmpId=self.messageResult[index-1][0].receiverEmpId;
		DataService.updateStatusOfUserAsTabAdded(previousEmpId)
		.then(function(data)
		{
			
		})
		}
		
		}*/
	
	/*if(index==0 && self.messageResult.length>0 ) {
				if(self.highLightedTab==self.messageResult[index][0].receiverEmpId)
		{var previousEmpId=self.messageResult[index+1][0].receiverEmpId;
		
		alert("2")
		DataService.updateStatusOfUserAsTabAdded(previousEmpId)
		.then(function(data)
		{
			
		})
		}
		
	}
*/
	
	if(self.messageResult.length==0)
		{
	DataService.updateStatusOfUserWhenTabClosed(dataToBeRemoved[0].receiverEmpId)
	.then(function(data){//var self = this;
	  
	    
	})
	
	
		}
	
	
	
	};



this.addTab = function (title) {
	var self = this;
    self.showSol = true;
	self.highLightedTab=title;
if(this.showSol == true ){
	
	DataService.userChatData(title)
	.then(function(data){		
		var hasmatch=false;
		for(var index=0;index<self.messageResult.length;++index)
		{
		if(self.messageResult[index][0].receiverEmpId==title)
		{
		hasmatch=true;
		
		 self.removeTab1(index,data);
		    break;

		}
		}

		if(hasmatch==false)
		{
	    self.messageResult.push(data);

		}
		
		
		
	    self.pLink = data[0].pLink;
	    self.receiverName = data[0].receiverName;
	    self.receiverEmpId=data[0].receiverEmpId;
	    self.isOnline=data[0].isOnline;
	    self.lastLoginTime=data[0].lastLogin;
	    self.isOffline=data[0].isOffline;
	    scrollDown(title);

	   
	})

	getSocketCon(title);


}


  };

/*Code for Group Chat*/

  this.groupChat = function () {
		//var self = this;
		var sender = $("#sender").val();
	    self.showSol = true;
		self.highLightedTab=99999;// group id
	if(this.showSol == true ){
		DataService.getGroupChatData()
		.then(function(data){		
			var hasmatch=false;
			for(var index=0;index<self.messageResult.length;++index)
			{
			if(self.messageResult[index][0].receiverEmpId==99999)
			{
			hasmatch=true;
			
			 self.removeTab1(index,data);
			    break;

			}
			}

			if(hasmatch==false)
			{
		    self.messageResult.push(data);

			}
			
			//console.log( self.messageResult);
			
			
		    self.pLink = data[0].pLink;
		    self.receiverName = data[0].receiverName;
		    self.receiverEmpId=data[0].receiverEmpId;
		   /* self.isOnline=data[0].isOnline;
		    self.lastLoginTime=data[0].lastLogin;
		    self.isOffline=data[0].isOffline;
		   scrollDown(99999);
*/
			   scrollDown(99999);

		})

		getGroupChatSocketCon();


	}


	  };
	  
	  /*End of Group Chat*/

this.sendName=function(receiver)
{
	if(receiver==99999)
		{
		sendGroupChat();
		}
	else{
	
sendNameChat(receiver);
	}
		
	}


this.sendMessageOnEnter = function(receiverEmpId) {
	
	if(this.value==true)
	   {
		if(receiverEmpId==99999)
		{
		sendGroupChat();
		}
		else
			{
		
		sendNameChat(receiverEmpId);
		}
	   }
	   
	};






this.updateUserStatus=function()
{
	DataService.updateStatusOfUser();
	
	
}



setInterval(function(){
	
	 self.openTickets=[];
	
	 if(self.result!=undefined&&self.result.length > 0)
		 {
	for(var index=0;index<self.result.length;index++)
	{
		self.openTickets.push({"ticketId":self.result[index].ticketId });
	}

	$http({
        'url' : '/SFMSAssist/checkTicketUpdate',
        'method' : 'POST',
        'headers': {'Content-Type' : 'application/json'},
        'data' : self.openTickets
    }).then(function(response){
    	for(var index=0;index<self.result.length;index++)
		{
		for(var index1=0;index1<response.data.length;index1++)
			{
			if((self.result[index].ticketId==response.data[index1].ticketId)&&(self.result[index].issueUpdatedByUser!=response.data[index1].issueUpdatedByUser))
				{
				
				//console.log(self.result[index].ticketId+"  "+response.data[index1].ticketId)
				self.result[index].issueUpdatedByUser=response.data[index1].status;
				
				}
			}
		}
    	
    	self.noOfUpdates=response.data[0].noOfUpdates;
    	
    	 if(self.noOfUpdates>0)
	    	{
	    	
	    	self.flashTitle();
	    	
	    	}
    	
    	
    })
		 }
	
	 else
		 {
		 self.noOfUpdates=0;
		 }
	DataService.userListData()
	.then(function(data){
	    self.result1 = data;
	    self.totalMessageCount=data[0].totalMessageCount;
	    self.titleOfPage=" Home | SFMS Assist";
	    
	    if(self.totalMessageCount>0)
	    	{
	    	
	    	self.flashTitle();
	    	
	    	}

	})
	DataService.autoAssignedIssues()
	.then(function(data){
	self.assignedIssuesData=data;
	
	if(self.assignedIssuesData.length>0)
		{
		self.flashTitle();
		//alert(self.assignedIssuesData.length);
		}
	
	})
	
	}, 2000)




	this.flashTitle=function()
	{
	setInterval(function(){
		
		
		
	    self.titleOfPage=" Home | SFMS Assist";
	    
	    $timeout(function () {
	    	
	    	if((self.totalMessageCount>0 && self.assignedIssuesData.length>0)||
		    		(self.totalMessageCount>0 && self.noOfUpdates>0)||
		    		(self.assignedIssuesData.length>0 && self.noOfUpdates>0))
    		{
	    		 
	    		
	    	self.notificationsCount=self.totalMessageCount+self.assignedIssuesData.length+self.noOfUpdates;
    		self.titleOfPage="("+self.notificationsCount+") Notifications || Home | SFMS Assist";
			
    		}
	    	else
	    		{
	    		
	    	if(self.totalMessageCount>0)
	    		{
	    		
	    		self.titleOfPage="("+self.totalMessageCount+") Messages || Home | SFMS Assist";
				
	    		}
	      if(self.assignedIssuesData.length>0)
    		{
    		
    		self.titleOfPage="("+self.assignedIssuesData.length+") Tickets Assigned || Home | SFMS Assist";
			
    		}
	      if(self.noOfUpdates>0)
  		{
  		
  		self.titleOfPage="("+self.noOfUpdates+") Tickets Update || Home | SFMS Assist";
			
  		}
	      
	    		}
	    	
	    }, 1500);
	    
		
	}, 500)
	
	}
	
self.status = '  ';
self.customFullscreen = false;

self.contacts=[];
self.showAdvanced = function(ev) {
	

$mdDialog.show({
  controller: DialogController,
  templateUrl: 'dialog1.tmpl.html',
  parent: angular.element(document.body),
  targetEvent: ev,
  clickOutsideToClose:false,
  fullscreen: this.customFullscreen // Only for -xs, -sm breakpoints.
})
.then(function(answer) {
  self.status = 'You said the information was "' + answer + '".';
}, function() {
  self.status = 'You cancelled the dialog.';
});
};


self.showAdvanced1 = function(ev) {
	

	$mdDialog.show({
	  controller: DialogController,
	  templateUrl: 'dialog3.tmpl.html',
	  parent: angular.element(document.body),
	  targetEvent: ev,
	  clickOutsideToClose:false,
	  fullscreen: this.customFullscreen // Only for -xs, -sm breakpoints.
	})
	.then(function(answer) {
	  self.status = 'You said the information was "' + answer + '".';
	}, function() {
	  self.status = 'You cancelled the dialog.';
	});
	};








self.showChat = function(ev) {
	

	$mdDialog.show({
	  controller: DialogController,
	  templateUrl: 'dialog2.tmpl.html',
	  parent: angular.element(document.body),
	  targetEvent: ev,
	  clickOutsideToClose:false,
	  fullscreen: this.customFullscreen // Only for -xs, -sm breakpoints.
	})
	.then(function(answer) {
	  self.status = 'You said the information was "' + answer + '".';
	}, function() {
	  self.status = 'You cancelled the dialog.';
	});
	};








function DialogController($scope,$mdDialog) {

$scope.cancel = function() {
  $mdDialog.cancel();
};
}

 this.assignAllIssuesToPool=function()
{

	 
	 $http({
	        'url' : '/SFMSAssist/assignAllIssuesToPool',
	        'method' : 'POST',
	        'headers': {'Content-Type' : 'application/json'},
	        'data' : self.result
	    }).then(function(data,status, headers, config){
           $window.location.href = '/SFMSAssist/';
	       alert("All selected issues assigned to pool");


	    })
	
	
}
	
}


app.service("DataService",function($http){
	

	var self = this;
	
	self.updateStatusOfUser=function()
	{
		var promise1 = $http.get('/SFMSAssist/deactiveUser/');	
		
	}
	
	self.updateStatusOfUserWhenTabClosed=function(empId)
	{
		var promise1 = $http.get('/SFMSAssist/updateStatusOfUserWhenTabClosed/'+empId);	
		return promise1;
	}
	self.updateStatusOfUserAsTabAdded=function(empId)
	{
		var promise1 = $http.get('/SFMSAssist/updateStatusOfUserAsTabAdded/'+empId);	
		return promise1;
	}
	

	self.userChatData = function(x){

		var promise1 = $http.get('/SFMSAssist/getUserChatData/'+x);
		var promise2 = promise1.then(function(response){
			
			return response.data;
			
		});
		return promise2;

	}
	

	self.getGroupChatData = function(){

		var promise1 = $http.get('/SFMSAssist/getGroupChatData/');
		var promise2 = promise1.then(function(response){
			
			return response.data;
			
		});
		return promise2;

	}
	
	
	self.getPresentAutoAssignUserData = function(){
		var promise1 = $http.get('/SFMSAssist/getPresentUserDataforAssigning/').success(function(data){
			this.contactsJson1 = data;
			 return this.contactsJson1.map(function (c, index) {
	              var contact = {
	            	empName: c.empName,
	                email: c.email,
	                pLink: c.pLink,
	                empId:c.empId
	              };
	              contact._lowername = contact.empName.toLowerCase();
	              return contact;
	            });
		});
		return promise1;

	}
	
	
	
	
	self.getAutoAssignUserData = function(){
		var promise1 = $http.get('/SFMSAssist/getUserDataforAssigning/').success(function(data){
			this.contactsJson = data;
			 return this.contactsJson.map(function (c, index) {
	              var contact = {
	            	empName: c.empName,
	                email: c.email,
	                pLink: c.pLink,
	                empId:c.empId
	              };
	              contact._lowername = contact.empName.toLowerCase();
	              return contact;
	            });
			});
	
		
		return promise1;

	}
	
self.userListData = function(x){

		
		var promise1 = $http.get('/SFMSAssist/getUserListData/');
		var promise2 = promise1.then(function(response){
			
			return response.data;
		});
		return promise2;

	}


self.getStatusOfTickets=function(x){
	
	
	//alert("before ajax call")
	console.log("before ajax call")
	$http({
	        'url' : '/SFMSAssist/checkTicketUpdate',
	        'method' : 'POST',
	        'headers': {'Content-Type' : 'application/json'},
	        'data' : x
	    }).then(function(data,status, headers, config){
	    	console.log("i am back")
	    	return data;

	    })
	
	
}

self.autoAssignedIssues=function(x){

	
	var promise1 = $http.get('/SFMSAssist/getAutoAssignIssuesDataForUser/');
	var promise2 = promise1.then(function(response){
		
		return response.data;
		
	});
	return promise2;

}


self.getSkelDates = function(empId){
	
	    		var promise1 = $http.get('/SFMSAssist/getSkeltonDates/'+empId);
	    		var promise2 = promise1.then(function(response){
	    			return response.data;
	    		});
	    		return promise2;

	    	}


self.availCompoAndCheckOutService = function(id){
	
	var promise1 = $http.get('/SFMSAssist/availCompoAndCheckOut/'+id);
	var promise2 = promise1.then(function(response){
		return response.data;
	});
	return promise2;

}



});


