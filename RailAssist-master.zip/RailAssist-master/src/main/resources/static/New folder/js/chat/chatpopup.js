 

  
  	$(".chat_button").click(function(e) {
  		
  		alert("1111");
        $('#qnimate').addClass('popup-box-on');
        });
