function getSocketCon(empId)
{
	$( ".sampleChats" ).remove();
	var sender = $("#sender").val();

	
	$.ajax({
		url : "/SFMSAssist/activeusers/" + sender + "/" + empId,

	});

	var socket = new SockJS('/SFMSAssist/hello');
	socket.onopen = function() {
	};
	stompClient = Stomp.over(socket);
	stompClient.connect({}, function(frame) {
		console.log('Connected: ' + frame);
		stompClient.subscribe('/SFMSAssist/topic/greetings/' + sender + '/' + empId,
				function(greeting) {
					showGreeting(JSON.parse(greeting.body).content,empId);
					//showGreeting(greeting);
				});
	});

	}

function showGreeting(message,receiver) {
	


	var sender = $("#sender").val();


	var arr = message.split('$@*');
	$("#"+receiver)
			.append(

					'<div class="w3-row sampleChats" ><div class="col-md-8"><div class="w3-container  w3-panel  w3-card-4 w3-left " style="background-color: #CFD8DC; border-radius: 19px; margin-left: 10px;">'
							
							+ '<p id="ccontent" class="w3-medium" style="padding-top: 2px;">'
							+ arr[2] + '</p>'
							+ '<p id="cdate" class="w3-tiny text-muted" style="margin-bottom: 0.5px;">'
							+ arr[1]
							+ '</p></div></div><div class="col-md-4"></div></div>'
			);
	
	
	
	$("#"+receiver).scrollTop($("#"+receiver)[0].scrollHeight);

}

function sendNameChat(receiverName) {

	var sender = $("#sender").val();

	stompClient.send('/app/hello/' + sender + '/' + receiverName, {}, JSON.stringify({
		'message' : $("#message").val()

	}));
	
	/*$.ajax({
		url : "store",

		data : $("#form5").serialize()
	});*/

	var now = moment().format("DD-MMM-YYYY hh:mm:ss A");
	var dt = now;


	$("#"+receiverName)
			.append(

					'<div class="w3-row sampleChats" ><div class="w3-container w3-half"></div><div class="w3-container  w3-panel  w3-card-4 w3-right" style="background-color: white; border-radius: 19px; margin-right: 10px;">'
							
							+ '<p class="w3-medium" style="padding-top: 2px;">'
							+ $("<div/>").text($('#message').val()).html()
							+ '</p>'
							+ '<p id="cdate" class="w3-tiny text-muted" style="margin-bottom: 0.5px;">'
							+ dt
							+ '</p></div></div>'
							

			);

	$("#message").val('');
	$("#message").focus();
	$("#"+receiverName).scrollTop($("#"+receiverName)[0].scrollHeight);

	
}

var app = angular.module('myApp', ['ngMaterial']);

app.controller("Ctrl",Ctrl);



function Ctrl(DataService,$scope){
	
	var self=this;
	this.xyz="from controller";
	this.result1=[];
this.messageResult=[];
this.showSol =false;
var counter = 1;
this.tabs = [];
this.insideData=[];




console.log("1");



var tabs = [
            { title: 'Zero (AKA 0, Cero, One - One, -Nineteen + 19, and so forth and so on and continuing into what seems like infinity.)', content: 'Woah...that is a really long title!' },
            { title: 'One', content: "Tabs will become paginated if there isn't enough room for them."},
            { title: 'Two', content: "You can swipe left and right on a mobile device to change tabs."},
            { title: 'Three', content: "You can bind the selected tab via the selected attribute on the md-tabs element."},
            { title: 'Four', content: "If you set the selected tab binding to -1, it will leave no tab selected."},
            { title: 'Five', content: "If you remove a tab, it will try to select a new one."},
            { title: 'Six', content: "There's an ink bar that follows the selected tab, you can turn it off if you want."},
            { title: 'Seven', content: "If you set ng-disabled on a tab, it becomes unselectable. If the currently selected tab becomes disabled, it will try to select the next tab."},
            { title: 'Eight', content: "If you look at the source, you're using tabs to look at a demo for tabs. Recursion!"},
            { title: 'Nine', content: "If you set md-theme=\"green\" on the md-tabs element, you'll get green tabs."},
            { title: 'Ten', content: "If you're still reading this, you should just go check out the API docs for tabs!"},
            { title: 'Eleven', content: "If you're still reading this, you should just go check out the API docs for tabs!"},
            { title: 'Twelve', content: "If you're still reading this, you should just go check out the API docs for tabs!"},
            { title: 'Thirteen', content: "If you're still reading this, you should just go check out the API docs for tabs!"},
            { title: 'Fourteen', content: "If you're still reading this, you should just go check out the API docs for tabs!"},
            { title: 'Fifteen', content: "If you're still reading this, you should just go check out the API docs for tabs!"},
            { title: 'Sixteen', content: "If you're still reading this, you should just go check out the API docs for tabs!"},
            { title: 'Seventeen', content: "If you're still reading this, you should just go check out the API docs for tabs!"},
            { title: 'Eighteen', content: "If you're still reading this, you should just go check out the API docs for tabs!"},
            { title: 'Nineteen', content: "If you're still reading this, you should just go check out the API docs for tabs!"},
            { title: 'Twenty', content: "If you're still reading this, you should just go check out the API docs for tabs!"}
          ],
          selected = null,
          previous = null;
       this.tabs = tabs;
   	console.log("2s");

       this.selectedIndex = 0;
       $scope.$watch('selectedIndex', function(current, old){
          previous = selected;
      	console.log("13");

          selected = tabs[current];
        });


this.sendName=function(receiver)
{
	
	sendNameChat(receiver);
	
	}

this.updateUserStatus=function()
{
	
	DataService.updateStatusOfUser()
	.then(function(data){//var self = this;
	   console.log("inside the update status of user");
	  
	    
	})
	
}





setInterval(function(){
	
	DataService.userListData()
	.then(function(data){
	    console.log(data);
	    self.result1 = data;

	})
	DataService.autoAssignedIssues()
	.then(function(data){
		console.log("hi");
	self.assignedIssuesData=data;
	
	console.log(data);
	})
	
	}, 2000)




	       this.addTab = function () {
	    	   console.log("inside");
	        // view = view || title + " Content View";
	          self.tabs.push({ title: 'new tab1', content: 'new new', disabled: false});
	          console.log(tabs);
	        }
	       this.removeTab = function (tab) {
	          var index = tabs.indexOf(tab);
	          self.tabs.splice(index, 1);
	        }
	
	
   

this.checkBxClk = function(empId){

	console.log("inside div display");
	var self = this;
    self.showSol = true;

	

if(this.showSol == true ){

	
	
	DataService.userChatData(empId)
	.then(function(data){
	    console.log(data);
	    self.messageResult = data;
	    console.log(self.messageResult+"inside userchatdata");

	    self.pLink = data[0].pLink;
	    self.receiverName = data[0].receiverName;
	    self.receiverEmpId=data[0].receiverEmpId;
	    self.isOnline=data[0].isOnline;
	    self.lastLoginTime=data[0].lastLogin;
	    self.isOffline=data[0].isOffline;
	    
	})

	getSocketCon(empId);

}
}
}


app.service("DataService",function($http){
	

	var self = this;
	
	self.updateStatusOfUser=function()
	{
		var promise1 = $http.get('/SFMSAssist/deactiveUser/');	
		
	}

	self.userChatData = function(x){

		
		var promise1 = $http.get('/SFMSAssist/getUserChatData/'+x);
		var promise2 = promise1.then(function(response){
			
			return response.data;
		});
		return promise2;

	}
	
	
self.userListData = function(x){

		
		var promise1 = $http.get('/SFMSAssist/getUserListData/');
		var promise2 = promise1.then(function(response){
			
			return response.data;
		});
		return promise2;

	}
self.autoAssignedIssues=function(x){

	
	var promise1 = $http.get('/SFMSAssist/getAutoAssignIssuesDataForUser/');
	var promise2 = promise1.then(function(response){
		
		return response.data;
	});
	return promise2;

}



});


	
	
	
	

app.directive('tabHighlight', [function(){
    return {
        restrict: 'A',
        link: function(scope, element) {
          var x, y, initial_background = '#c3d5e6';

          element
            .removeAttr('style')
            .mousemove(function (e) {
              // Add highlight effect on inactive tabs
              if(!element.hasClass('active'))
              {
                x = e.pageX - this.offsetLeft;
                y = e.pageY - this.offsetTop;

                element
                  .css({ background: '-moz-radial-gradient(circle at ' + x + 'px ' + y + 'px, rgba(255,255,255,0.4) 0px, rgba(255,255,255,0.0) 45px), ' + initial_background })
                  .css({ background: '-webkit-radial-gradient(circle at ' + x + 'px ' + y + 'px, rgba(255,255,255,0.4) 0px, rgba(255,255,255,0.0) 45px), ' + initial_background })
                  .css({ background: 'radial-gradient(circle at ' + x + 'px ' + y + 'px, rgba(255,255,255,0.4) 0px, rgba(255,255,255,0.0) 45px), ' + initial_background });
              }
            })
            .mouseout(function () {
              element.removeAttr('style');
            });
        }
      };
    }]);




