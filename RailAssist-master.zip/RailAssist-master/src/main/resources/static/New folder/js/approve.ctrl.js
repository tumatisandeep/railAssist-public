/*var app=angular.module("myApp",['ngMaterial', 'ngMessages', 'material.svgAssetsCache']);
app.controller("Ctrl",Ctrl);*/

var app = angular.module("myApp",[]);


app.controller("Ctrl",Ctrl);

function Ctrl(Attendserv){

this.xyz="from controller";





this.xyz = "from controller";
this.minDate=this.fromDate;
/*this.fDate=new Date();
*/
this.maxDate=new Date();








this.update = function(){

var self = this;


Attendserv.getData(this.date)
.then(function(data){


self.data = data;

self.allSelectOrDeselect = false;

})


}

this.selectOrDeselectAll = function(){
var self = this;
//alert("selectOrDeselectAll :"+this.allSelectOrDeselect);

angular.forEach(this.data, function(data) {
    //alert(data.name);

    data.approve = self.allSelectOrDeselect;

});
	
self.zxc = JSON.stringify(this.data);

}

this.approveCheckboxClkd = function(){
	var self = this;
	self.zxc = JSON.stringify(this.data);	
}

}

app.service("Attendserv",function($http){

	var self = this;
	

	self.getData = function(date){

            		var promise1 = $http.get('/SFMSAssist/getCheckInCheckOutDtlsByDate/'+date);
            		var promise2 = promise1.then(function(response){
            			return response.data;
            		});
            		return promise2;

            	}

});



