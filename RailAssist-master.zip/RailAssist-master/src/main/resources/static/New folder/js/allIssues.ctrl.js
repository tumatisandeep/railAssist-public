

var app = angular.module("myApp",['angular-loading-bar', 'ngAnimate']);


app.controller("Ctrl",Ctrl);

function Ctrl(IssueDetailserv,$window){
	
	
	
	this.checkDateField=function()
	{
		if((this.fromDate==null &&this.toDate==null))
	  {
			if(this.uatOrProd!=undefined||this.pendOrClosed!=undefined||this.yrTkt!=undefined||this.resolvedTkt!=undefined)
			{
			return true;
			}
	        }
	        else if((this.fromDate!=null &&this.toDate!=null))
	        {

	        return true;
	        }
		else
			{
		

			return false;
			}
		
	}
	
	
	
	this.minDate=this.fromDate;

	this.maxDate=new Date();
	
	
	

this.xyz="from controller";

this.totalLoadedArray = [];

this.pageCnt=1;

//this.yrTkt = false;

this.loadMoreBtnVisible=true;

this.buttonTxt="Load More";

this.filterDataLoaded = false;



this.applyFilter = function(){

	
	
var self = this;


    if(this.resolvedTkt == undefined && this.uatOrProd == undefined && this.pendOrClosed == undefined && this.yrTkt == undefined && this.fromDate==undefined&&this.toDate==undefined){
    alert("No filter selected!");

    }else{
        IssueDetailserv.applyFilterAndLoad(this.uatOrProd,this.pendOrClosed,this.yrTkt,this.fromDate,this.toDate,this.resolvedTkt )
            .then(function(data){


                self.filterDataLoaded = true;
            	self.result.length = 0;
            	self.result = data;
            	//$window.scrollTo(0, 0);
            	 $("html,body").animate({scrollTop: '0px'}, "slow");

            })
    }




}


this.loadMore = function(){
var self = this;
self.buttonTxt="Loading....";


IssueDetailserv.getMoreIssues(this.pageCnt)
.then(function(data){
	//console.log(data);
	if(data.length<10){
	self.loadMoreBtnVisible = false;
	}
	self.result =self.result.concat(data);

	self.pageCnt = self.pageCnt + 1;
	

})
self.buttonTxt="Load More";


}

}


app.service("IssueDetailserv",function($http){

	var self = this;

	self.getMoreIssues = function(pageCnt){

            		var promise1 = $http.get('/SFMSAssist/allIssuesRestCall/'+pageCnt);
            		var promise2 = promise1.then(function(response){
            			return response.data;
            		});
            		return promise2;

            	}


     self.applyFilterAndLoad =function(uatOrProd,pendOrClosed,yrTkt,fromDate,toDate){
    	 
    	 
    	 
    	 
                    if(uatOrProd == undefined){
                        uatOrProd = 0;
                    }
                    if(pendOrClosed == undefined){
                        pendOrClosed = 0;
                    }
                    
                    if(yrTkt == undefined){
                    	yrTkt = 0;
                    }
                    if(fromDate==undefined||toDate==undefined)
                    	{
                    	fromDate=0;
                    	toDate=0;
                    	}
/*if(resolvedTkt==undefined)
	{
	resolvedTkt=0;
	}*/

                    //console.log("in applyFilterAndLoad serv");
                    var promise1 = $http.get('/SFMSAssist/getIssuesAfterFilter/filter?uatOrProd='+uatOrProd+'&pendOrClosed='+pendOrClosed+"&yrTkt="+yrTkt+
                    		"&fromDate="+fromDate+"&toDate="+toDate);
                    var promise2 = promise1.then(function(response){
                    		return response.data;
                    });
                    return promise2;

     }





});



