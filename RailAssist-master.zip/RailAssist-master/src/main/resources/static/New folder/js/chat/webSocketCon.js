
function getSocketConn(a)
{
	
	alert(this.value+"value");
	alert(a.parentNode.value+"pValue");
	alert(a.parentNode.name+"pname");
	alert(a.parentNode.id+"pid");
	alert(this.name+"name");
	alert(this.id+"id");

	
	}
$(document).ready(function(){
	
	getSocketConn(a);
	
	
});
