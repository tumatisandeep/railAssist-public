var stompClient = null;


function sendName() {
	var sender = $("#sender").val();

    stompClient.send('/cast/broad/'+sender, {}, JSON.stringify({'name': $("#name").val()}));
    $('#name').val('');
	$("#name").focus();
	$('#send').prop('disabled', true);
}

//for user who sends
function showGreeting(message)
{
	
	
	var arr = message.split('$@*');
	
	var user = $('#user').text().trim();
	
	//   alert("user :"+typeof(user)+ " arr[0] :"+typeof(arr[0]));
	
	//   alert("name :"+arr[0]+"user :"+user);
	
	//   alert( arr[0].trim() == user);
	//   alert(arr[0].trim() ===user);
	
if( arr[0].trim() == user){
	$("#mydiv").append('<div class="w3-row" ><div class="w3-container w3-half"></div><div class="w3-container w3-half w3-panel w3-card-4" style="   background-color:#CFD8DC; border-radius: 19px;">'+
			'<p id="cdate" class="w3-tiny w3-opacity">'+ arr[1] +'</p>'+
			'<p id="cname" class="w3-tiny">'+ arr[0] +'</p>'+
			'<p id="ccontent" class="w3-small">'+ arr[2] + '</p></div></div>');
}else{
	$("#mydiv").append('<div class="w3-row" ><div class="w3-container w3-half w3-panel w3-card-4" style="   background-color:#80CBC4; border-radius: 19px;">'+
			'<p id="cdate" class="w3-tiny w3-opacity">'+ arr[1] +'</p>'+
			'<p id="cname" class="w3-tiny">'+ arr[0] +'</p>'+
			'<p id="ccontent" class="w3-small">'+ arr[2] + '</p></div></div>');
}
	

	//$("#greetings").append("<tr><td>" + message + "</td></tr>");
	
	
	
    $("#mydiv").scrollTop($("#mydiv")[0].scrollHeight);
}	


$(function () {
	
	 /*$.ajax({

			url : "/broadcast",

		});*/
	 
	var socket = new SockJS('/gs-guide-websocket');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function (frame) {
        console.log('Connected: ' + frame);
        stompClient.subscribe('/test/greetings', function (greeting) {
        	showGreeting(JSON.parse(greeting.body).content);
            //alert(greeting);
            
        });
        $("#name").focus();
    });
	var sender = $("#sender").val();

   
});

$(document).ready(function(){
	$("#mydiv").scrollTop($("#mydiv")[0].scrollHeight);
    $('#send').prop('disabled',true);
    $('#name').keyup(function(){
        $('#send').prop('disabled', this.value == "" ? true : false);     
    })
    $("#name").keypress(function(event) {
        if (event.which == 13) {
            event.preventDefault();
            $("#send").click();
        }
    });
});
