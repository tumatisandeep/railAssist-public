var stompClient = null;

var popup ;


function setConnected(connected) {
	
	$("#popup").prop("disabled", connected);
	$("#disconnect").prop("disabled", !connected);
	if (connected) {
		$("#tab").show();
	} else {
		location.reload();
	}
}


function chat(receiver) {
	var sender = $("#sender").val();
	var url = "/chat/" + sender + "/" + receiver;

	popup = window
			.open(
					url,
					url,
					"PoP_Up",
					"width=450,height=500,location=no,status=no,resizable=no,directories=no,menubar=no,toolbar=no, scrollbars=yes");

}



function disconnect() {
	if (stompClient != null) {
		stompClient.disconnect();
	}
	setConnected(false);
	console.log("Disconnected");
}

function sendMessages(response)
{
			$.each(  $.parseJSON(response.body), function( key, value ) {
				b=document.getElementById(key);
				//alert(value);
				//b.innerHTML.style.color='red';
				//alert("red");
				b.innerHTML = "<span style='color:#FF0000'>"+ value +"</span>";;
				b.style.fontWeight = 'bold';
				
				/*popup.focus();
				  popup.moveTo(50,50);
				  popup.resizeTo(500,300);*/
			});
	
	
	}



$( document ).ready(function() {
	
	//alert("chat js");
	var sender=$("#sender").val();
	var socket = new SockJS('/hello');
	stompClient = Stomp.over(socket);
	stompClient.connect({}, function(frame) {
		setConnected(true);
		console.log('Connected: ' + frame);
		stompClient.subscribe('/user/'+sender+'/'+'message',
				function(greeting) {
			
					sendMessages(greeting);
				});
		$("#name").focus();

	});
	
	$(".chat_button").click(function(e) {
		e.preventDefault();
		chat($(this).val());
	});

	$.ajax({
		url : "/loginusers",
		 success: function(response) {
		         document.getElementById(response).bgcolor="red";
         		       
        }

	});

	
	
	$("#popup").click(function(e) {

		e.preventDefault();
		connect();
	});
	$("#disconnect").click(function(e) {
		e.preventDefault();
		disconnect();
	});

	$("#logout1").click(function() {
		$("#logoutForm").submit();
	});	

});

/*$(document).ready(function(){
    setInterval(function(){
     $.ajax({
             url: '/server',
            dataType: 'json',
            success: function(response) {
            	// var marker = JSON.stringify(response);
            	 //var arr = marker.split(',');
            	
            	var blink_speed = 500;
            		    var t = setInterval(function () {
            		    	
            		        var ele = document.getElementById(response);
            		        ele.className += " blink";
            		        ele.style.visibility = (ele.style.visibility == 'hidden' ? '' : 'hidden');
            		    }, blink_speed);  
            			      	
            }
        });
    }, 1000);
    
    
});
*/