package com.rail.assist.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class IndentPoRelationPk implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "PO_INDENT_NUMBER")
	private long poIndentNumber;

	@Column(name = "INDENT_ID")
	private Long indentId;

	public long getPoIndentNumber() {
		return poIndentNumber;
	}

	public void setPoIndentNumber(long poIndentNumber) {
		this.poIndentNumber = poIndentNumber;
	}

	public Long getIndentId() {
		return indentId;
	}

	public void setIndentId(Long indentId) {
		this.indentId = indentId;
	}
	
	

}
