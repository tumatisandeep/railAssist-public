package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the city_info database table.
 * 
 */
@Entity
@Table(name="city_info")
@NamedQuery(name="CityInfo.findAll", query="SELECT c FROM CityInfo c")
public class CityInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CITY_ID")
	private int cityId;

	@Column(name="CITY_NAME")
	private String cityName;

	public CityInfo() {
	}

	public int getCityId() {
		return this.cityId;
	}

	public void setCityId(int cityId) {
		this.cityId = cityId;
	}

	public String getCityName() {
		return this.cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

}