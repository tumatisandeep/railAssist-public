package com.rail.assist.service;

import java.util.Map;

import com.rail.assist.dto.IndentDataDto;
import com.rail.assist.dto.IndentPreviewDto;
import com.rail.assist.entities.IndentDetail;
import com.rail.assist.entities.ItemsData;

public interface IndentService {

	IndentDataDto getIndentData(long id) throws NumberFormatException, Exception;

	IndentDataDto getIndentDataWithIndentId(long uniqueId) throws NumberFormatException, Exception;

	/**
	 * @param itemsData
	 * @param indentDto 
	 * @return
	 * @throws Exception 
	 * @throws NumberFormatException 
	 */
	IndentDetail createIndentPreview(ItemsData itemsData, IndentPreviewDto indentDto) throws NumberFormatException, Exception;

	/**
	 * @param indentData
	 * @return
	 * @throws Exception 
	 */
	Map<String, Object> getIndentDataToPrint(IndentDetail indentData) throws Exception;
	
}
