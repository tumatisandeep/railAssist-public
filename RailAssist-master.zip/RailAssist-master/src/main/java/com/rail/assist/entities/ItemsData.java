package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.rail.assist.dto.ItemsGroupWiseData;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * The persistent class for the indent_details database table.
 * 
 */
@Entity
@Table(name = "items_data")
@NamedQuery(name = "ItemsData.findAll", query = "SELECT i FROM ItemsData i")
public class ItemsData implements Serializable {
	private static final long serialVersionUID = 1L;

	
	private int id;

	@Id
	@Column(name = "ITEM_ID")
	private long itemId;
	
	@Column(name = "CATEGORY_ID")
	private int categoryId;
	
	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "PART_NUMBER")
	private String partNumber;

	@Column(name = "LF_NUMBER")
	private String lfNumber;
	
	@Column(name = "PRICE")
	private double price;
	
	@Column(name = "UNITS")
	private String units;

	@Column(name = "GROUP_ID")
	private int groupId;
	
	@Column(name = "TYPE")
	private String type;
	

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_MODIFIED")
	private Date lastUpdate;

	@Temporal(TemporalType.DATE)
	@Column(name = "LOGGED_ON")
	private Date loggedOn;

	@Column(name = "LOGGED_BY")
	private long loggedBy;
	
	@Transient
	@JsonProperty("isItemPresent")
	boolean isItemPresent;
	
	
	@Transient
	@JsonProperty("totalCount")
	int totalCount;
	
	@Transient
	@JsonProperty("countOfItemsInStock")
	int countOfItemsInStock;

	@Transient
	@JsonProperty("categoryString")
	String categoryString;
	
	@Transient
	@JsonProperty("dataPresent")
	String dataPresent;
	
	
	@Transient
	@JsonProperty("isItemInStockTable")
	private boolean isItemInStockTable;
	
	
	@Transient
	@JsonProperty("stockAvailable")
	private long stockAvailable;

	
	@Transient
	@JsonProperty("lastPurchaseDetails")
	private String lastPurchaseDetails;
	
	@Transient
	@JsonProperty("lastPurchaseDetailsId")
	private long lastPurchaseDetailsId;
	
	@Transient
	@JsonProperty("isLsastPurchaseDetailsFound")
	private boolean isLastPurchaseDetailsFound;
	
	@Transient
	@JsonProperty("poDataOfItem")
	private Map<String,Integer> poDataOfItem;
	
	
	@Transient
	@JsonProperty("categoriesData")
	private Map<String,ItemsGroupWiseData> categoriesData;
	
	
	
	@Transient
	@JsonProperty("totalNumberOfItems")
	private long totalNumberOfItems;
	
	@Transient
	@JsonProperty("vendorsDataList")
	private Map<String,Integer> vendorsDataList;
	
	
	
	@Transient
	@JsonProperty("isItemsAvailableToIssueForChallan")
	private boolean isItemsAvailableToIssueForChallan;
	

	
	
	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getCountOfItemsInStock() {
		return countOfItemsInStock;
	}

	public void setCountOfItemsInStock(int countOfItemsInStock) {
		this.countOfItemsInStock = countOfItemsInStock;
	}

	public boolean getIsItemsAvailableToIssueForChallan() {
		return isItemsAvailableToIssueForChallan;
	}

	public void setIsItemsAvailableToIssueForChallan(boolean isItemsAvailableToIssueForChallan) {
		this.isItemsAvailableToIssueForChallan = isItemsAvailableToIssueForChallan;
	}

	public Map<String,Integer> getVendorsDataList() {
		return vendorsDataList;
	}

	public void setVendorsDataList(Map<String,Integer> vendorsDataList) {
		this.vendorsDataList = vendorsDataList;
	}

	public boolean isLastPurchaseDetailsFound() {
		return isLastPurchaseDetailsFound;
	}

	public void setLastPurchaseDetailsFound(boolean isLastPurchaseDetailsFound) {
		this.isLastPurchaseDetailsFound = isLastPurchaseDetailsFound;
	}

	public long getTotalNumberOfItems() {
		return totalNumberOfItems;
	}

	public void setTotalNumberOfItems(long totalNumberOfItems) {
		this.totalNumberOfItems = totalNumberOfItems;
	}

	public Map<String, ItemsGroupWiseData> getCategoriesData() {
		return categoriesData;
	}

	public void setCategoriesData(Map<String, ItemsGroupWiseData> categoriesData) {
		this.categoriesData = categoriesData;
	}

	public String getLastPurchaseDetails() {
		return lastPurchaseDetails;
	}

	public long getLastPurchaseDetailsId() {
		return lastPurchaseDetailsId;
	}

	public void setLastPurchaseDetailsId(long i) {
		this.lastPurchaseDetailsId = i;
	}

	public String isLastPurchaseDetails() {
		return lastPurchaseDetails;
	}

	public void setLastPurchaseDetails(String lastPurchaseDetails) {
		this.lastPurchaseDetails = lastPurchaseDetails;
	}

	public long getStockAvailable() {
		return stockAvailable;
	}

	public void setStockAvailable(long stockAvailable) {
		this.stockAvailable = stockAvailable;
	}

	public boolean isItemInStockTable() {
		return isItemInStockTable;
	}

	public void setItemInStockTable(boolean isItemInStockTable) {
		this.isItemInStockTable = isItemInStockTable;
	}

	

	public boolean isItemPresent() {
		return isItemPresent;
	}



	public int getCategory_id() {
		return categoryId;
	}

	
	public void setItemPresent(boolean isItemPresent) {
		this.isItemPresent = isItemPresent;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getId() {
		return id;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public long getItemId() {
		return itemId;
	}

	
	public String getDescription() {
		return description;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public String getLfNumber() {
		return lfNumber;
	}

	public double getPrice() {
		return price;
	}

	public String getUnits() {
		return units;
	}

	public int getGroupId() {
		return groupId;
	}

	public String getType() {
		return type;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public Date getLoggedOn() {
		return loggedOn;
	}

	public long getLoggedBy() {
		return loggedBy;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	

	public void setDescription(String description) {
		this.description = description;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public void setLfNumber(String lfNumber2) {
		this.lfNumber = lfNumber2;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public void setLoggedOn(Date loggedOn) {
		this.loggedOn = loggedOn;
	}

	public void setLoggedBy(long l) {
		this.loggedBy = l;
	}
	
	
	
	
	
	

	public String getCategoryString() {
		return categoryString;
	}

	public void setCategoryString(String categoryString) {
		this.categoryString = categoryString;
	}

	public Map<String, Integer> getPoDataOfItem() {
		return poDataOfItem;
	}

	public void setPoDataOfItem(Map<String, Integer> poDataOfItem) {
		this.poDataOfItem = poDataOfItem;
	}

	@PrePersist
	void createdAt() {
		this.loggedOn = new Date();
		this.lastUpdate = new Date();

	}

	@PreUpdate
	void updatedAt() {
		this.lastUpdate = new Date();
	}

	
	
	
	public String getDataPresent() {
		return dataPresent;
	}

	public void setDataPresent(String dataPresent) {
		this.dataPresent = dataPresent;
	}

	@Override
	public String toString() {
		return "ItemsData [id=" + id + ", itemId=" + itemId + ", category_id=" + categoryId + ", description="
				+ description + ", partNumber=" + partNumber + ", lfNumber=" + lfNumber + ", price=" + price
				+ ", units=" + units + ", groupId=" + groupId + ", type=" + type + ", lastUpdate=" + lastUpdate
				+ ", loggedOn=" + loggedOn + ", loggedBy=" + loggedBy + "]";
	}
	
	

}