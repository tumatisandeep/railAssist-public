package com.rail.assist.serviceImplementation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rail.assist.config.CurrentUser;
import com.rail.assist.constants.AssistConstants;
import com.rail.assist.constants.AssistConstantsParameters;
import com.rail.assist.dto.AllDataDto;
import com.rail.assist.entities.IndentDetail;
import com.rail.assist.entities.MaterialIssueData;
import com.rail.assist.entities.MaterialsReceivedData;
import com.rail.assist.entities.PurchaseOrderDetail;
import com.rail.assist.entities.UserDetail;
import com.rail.assist.repository.GenderRepository;
import com.rail.assist.repository.IndentDetailRepository;
import com.rail.assist.repository.IndentPoRepository;
import com.rail.assist.repository.ItemsDataRepository;
import com.rail.assist.repository.MaterialsIssueDataRepository;
import com.rail.assist.repository.MaterialsIssueRelationRepository;
import com.rail.assist.repository.MaterialsReceivedDataRepository;
import com.rail.assist.repository.PoDetailRepository;
import com.rail.assist.repository.StockAvailableRepository;
import com.rail.assist.repository.UserAccountStatusRepository;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.repository.UserLoginStatusRepository;
import com.rail.assist.repository.VendorsDataRepository;
import com.rail.assist.service.AllDataService;
import com.rail.assist.service.HomeService;

@Service
public class AllDataServiceImpl implements AllDataService {


	@Autowired
	GenderRepository genderRepository;

	@Autowired
	UserLoginStatusRepository userLoginStatusRepository;

	@Autowired
	UserAccountStatusRepository userAccountStatusRepository;

	@Autowired
	UserDetailsRepository userDetailsRepository;

	@Autowired
	MaterialsIssueDataRepository materialsIssueDataRepository;

	@Autowired
	ItemsDataRepository itemsDataRepository;

	@Autowired
	MaterialsIssueRelationRepository materialsIssueRelationRepository;

	@Autowired
	private AssistConstants assistConstants;

	@Autowired
	private StockAvailableRepository stockAvailableRepository;

	@Autowired
	private IndentPoRepository indentPoRepository;
	
	@Autowired
	private CurrentUser currentUser;
	
	@Autowired
	private HomeService  homeService;
	
	@Autowired
	private IndentDetailRepository indentDetailRepository;
	
	@Autowired
	PoDetailRepository poDetailRepository;
	
	@Autowired
	VendorsDataRepository vendorsDataRepository;

	@Autowired
	MaterialsReceivedDataRepository materialsReceivedDataRepository;
	

	/* (non-Javadoc)
	 * @see com.rail.assist.service.AllDataService#getDataByDateAndloggedBy(java.util.Date, java.util.Date, boolean)
	 */
	@Override
	//@Transactional(rollbackFor=Throwable.class)
	public List<AllDataDto> getDataByDateAndloggedBy(Date dateF, Date dateT, boolean logged) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.rail.assist.service.AllDataService#getAllDataWithCategory(int, int)
	 */
	@Override
	public List<AllDataDto> getAllDataWithCategory(int selectedCategory, int pageCnt) throws Exception {
        List<AllDataDto> allData=new ArrayList<>();

		
		try{

			
			//System.out.println(selectedCategory+"......"+pageCnt);
			
		if(selectedCategory==1)
		{
			
			// for indent loading

			
			Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "id"));
	        Pageable pageable = new PageRequest(pageCnt, 10, sort);
			List<IndentDetail> indentDetails = homeService.getAllIndents(pageable);

			for (IndentDetail indentDetail : indentDetails) {

				AllDataDto indentDto = new AllDataDto();
				indentDto.setId("Indent id: "+String.valueOf(indentDetail.getIndentId()));
				indentDto.setId1("Item id: "+String.valueOf(indentDetail.getItemId()));
				indentDto.setId2("Quantity: "+String.valueOf(indentDetail.getQuantityReq()));
				indentDto.setLoggedDate(indentDetail.getCreatedOn());
				UserDetail userLogged = userDetailsRepository.findByUserId(indentDetail.getIndentLoggedBy());
				indentDto.setLoggedBy("Logged by: "+userLogged.getUserFirstName() + " " + userLogged.getUserLastName());
				indentDto.setUniqueId(indentDetail.getId());
				indentDto.setTotalCount(indentDetailRepository.count());
				indentDto.setTitle("Indent " + indentDetail.getIndentId() + " is generated for the item "
						+ indentDetail.getItemId());
				indentDto.setDesc("Indent is generated for the value of " + indentDetail.getValue()
						+ ", and the quantity required is " + indentDetail.getQuantityReq() + " for the financial year "
						+ indentDetail.getFinancialYear());
				indentDto.setCategory(selectedCategory);
				allData.add(indentDto);

			}
		}
		
		else if(selectedCategory==2){
			// for PO loading

			
		//	System.out.println("in side else if 2");
			
			Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "createdOn"));
	        Pageable pageable = new PageRequest(pageCnt, 10, sort);
			List<PurchaseOrderDetail> poDetails = homeService.getAllPos(pageable);

			//System.out.println(poDetails.size()+" po details size");
			
			for (PurchaseOrderDetail poData : poDetails) {

				AllDataDto poDto = new AllDataDto();
				poDto.setId("PO no: "+poData.getPoNumber());
				poDto.setId1("Serial no:"+String.valueOf(poData.getSerialNumber()));
				poDto.setId2("Indents: "+String.valueOf(poData.getNumberOfIndents()));
				poDto.setLoggedDate(poData.getCreatedOn());
				UserDetail userLogged = userDetailsRepository.findByUserId(poData.getCreatedBy());
				poDto.setLoggedBy("Logged by: "+userLogged.getUserFirstName() + " " + userLogged.getUserLastName());
				poDto.setUniqueId(poData.getSerialNumber());
				poDto.setDesc("Purchase order is given by "
						+ vendorsDataRepository.findById(poData.getSuppliedBy()).getSupplierDesc() + " with "
						+ poData.getNumberOfIndents() + " indents.");
				poDto.setTitle("Purchase order Id is " + poData.getPoNumber());
				poDto.setTotalCount(poDetailRepository.count());
poDto.setCategory(selectedCategory);
				allData.add(poDto);

			}
		
			
			
			
		}
		else if(selectedCategory==3){
			
			// for received loading

			Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "id"));
	        Pageable pageable = new PageRequest(pageCnt, 10, sort);
			List<MaterialsReceivedData> receivedDetails = homeService.getAllItemsReceivedData(pageable);

			for (MaterialsReceivedData receivedData : receivedDetails) {

				AllDataDto receivedDto = new AllDataDto();
				receivedDto.setId("Item id: "+String.valueOf(receivedData.getItemId()));
				receivedDto.setId1("PO number"+String.valueOf(receivedData.getPoNumber()));
				receivedDto.setId2("Quantity"+String.valueOf(receivedData.getNumberOfItemsReceived()));
				receivedDto.setLoggedDate(receivedData.getCreatedon());
				UserDetail userLogged = userDetailsRepository.findByUserId(receivedData.getCreatedBy());
				receivedDto.setLoggedBy("Logged by: "+userLogged.getUserFirstName() + " " + userLogged.getUserLastName());
				receivedDto.setUniqueId(receivedData.getId());
				receivedDto.setTotalCount(materialsReceivedDataRepository.count());
				receivedDto.setTitle(receivedData.getItemId() + "  is received.");
				receivedDto.setDesc("These items were received against purchase order " + receivedData.getPoNumber());
receivedDto.setCategory(selectedCategory);
				allData.add(receivedDto);

			}
		}
		else if(selectedCategory==4){
			// for challans loading
			
			Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "materialIssueId"));
	        Pageable pageable = new PageRequest(pageCnt, 10, sort);
			List<MaterialIssueData> challanDetails = homeService.getAllItemsChallanData(pageable);

			for (MaterialIssueData challanData : challanDetails) {

				AllDataDto issuedDto = new AllDataDto();
				issuedDto.setId("Challan no: "+challanData.getChallanNumber());

				if (challanData.getMaterialIssuedBy() == Integer.valueOf(
						assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_I_RYP)))
					issuedDto.setId1("Issued from: "+assistConstants
							.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_I_RYP_DESC));
				else
					issuedDto.setId1("Issued from: "+assistConstants
							.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_II_RYP_DESC));

				issuedDto.setId2("Issued to: "+challanData.getMaterialIssueTo());
				issuedDto.setLoggedDate(challanData.getCreatedOn());
				UserDetail userLogged = userDetailsRepository.findByUserId(challanData.getCreatedBy());
				issuedDto.setLoggedBy("Logged by: "+userLogged.getUserFirstName() + " " + userLogged.getUserLastName());
				issuedDto.setUniqueId(challanData.getMaterialIssueId());
				issuedDto.setTitle("Challan " + challanData.getChallanNumber() + " generated for "
						+ challanData.getTotalNoOfItemsIssued() + " items.");
				issuedDto.setDesc(challanData.getTotalNoOfItemsIssued() + "  item is issued in this challan for "
						+ challanData.getMaterialIssueTo() + ". "); // materials
				issuedDto.setTotalCount(materialsIssueDataRepository.count());
				issuedDto.setCategory(selectedCategory);
				allData.add(issuedDto);

			}
		
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		return allData;
	}
	
	
	
}
