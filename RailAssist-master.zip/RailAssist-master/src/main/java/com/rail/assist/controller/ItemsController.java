package com.rail.assist.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.rail.assist.config.CurrentUser;
import com.rail.assist.constants.AssistConstantsParameters;
import com.rail.assist.dto.FilterDto;
import com.rail.assist.entities.Category;
import com.rail.assist.entities.GroupDetails;
import com.rail.assist.entities.ItemsData;
import com.rail.assist.entities.StockAvailable;
import com.rail.assist.entities.UserDetail;
import com.rail.assist.entities.VendorsData;
import com.rail.assist.repository.CategoryRepository;
import com.rail.assist.repository.GroupDetailRepository;
import com.rail.assist.repository.ItemsDataRepository;
import com.rail.assist.repository.StockAvailableRepository;
import com.rail.assist.repository.VendorsDataRepository;
import com.rail.assist.service.ItemsService;

@Controller
public class ItemsController {

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	ItemsDataRepository itemsDataRepository;

	@Autowired
	CurrentUser currentUser;

	@Autowired
	StockAvailableRepository stockAvailableRepository;

	@Autowired
	GroupDetailRepository groupDetailRepository;

	@Autowired
	VendorsDataRepository vendorsDataRepository;
	
	@Autowired
	ItemsService  itemsService;

	@RequestMapping(value = "/addNewItem", method = RequestMethod.GET)
	public String displayAddItemForm(Model model) throws Exception {

		List<GroupDetails> groupDetails = groupDetailRepository.findAll();

		model.addAttribute("groupDetails", groupDetails);

		return "addNewItem";

	}

	@RequestMapping(value = "/addNewVendor", method = RequestMethod.GET)
	public String addNewVendor(Model model) throws Exception {

		// List<Category> categories = categoryRepository.findAll();

		// model.addAttribute("itemsCategories", categories);

		return "addNewVendor";

	}

	@RequestMapping(value = "/submitNewItem", method = RequestMethod.POST)
	public String submitIndent(@RequestParam("partNumber") String partNumber, @RequestParam("lfNumber") String lfNumber,
			@RequestParam("units") String units, @RequestParam("itemType") int itemType,
			@RequestParam("criticalityType") int criticalityType, @RequestParam("subCat") int subCat,
			@RequestParam("itemId") long itemId, @RequestParam("desc") String desc, Model model,
			RedirectAttributes redirectAttributes) throws Exception {
		
		boolean itemAdded=false;
		try {

			/*System.out.println(partNumber + " ---- " + lfNumber + "----- " + units + " -- " + itemType + " ---- "
					+ criticalityType + " ----- " + " ---" + subCat + "----- " + itemId);*/

			ItemsData itemsData = new ItemsData();

			itemsData.setCategoryId(subCat);
			itemsData.setDescription(desc);
			itemsData.setGroupId(itemType);
			itemsData.setItemId(itemId);
			itemsData.setPartNumber(partNumber);
			itemsData.setLfNumber(lfNumber);
			itemsData.setUnits(units);
			itemsData.setLoggedBy(currentUser.getCurrentUser().getUserId());

			if (criticalityType == AssistConstantsParameters.CRITICALITY_CRITICAL)
				itemsData.setType("CRITICAL");

			else if (criticalityType == AssistConstantsParameters.CRITICALITY_NON_CRITICAL)
				itemsData.setType("NON CRITICAL");
			
			

			//itemsDataRepository.save(itemsData);

			StockAvailable stockAvailable = new StockAvailable();

			stockAvailable.setItemId(itemId);
			stockAvailable.setQuantityAvailable(AssistConstantsParameters.NO_ITEMS_AVAILABLE);

			//stockAvailableRepository.save(stockAvailable);
			
			itemAdded=itemsService.addItem(stockAvailable,itemsData);

			
			//System.out.println("after saving");
		}

		catch (Exception e) {
			e.printStackTrace();
			itemAdded=false;
		}

		redirectAttributes.addFlashAttribute("itemIdCreated", itemId);
		redirectAttributes.addFlashAttribute("itemCreated", itemAdded);

		return "redirect:/home";
	}

	@RequestMapping(value = "/submitNewVendor", method = RequestMethod.POST)
	public String submitNewVendor(@RequestParam("supplierDesc") String supplierDesc, @RequestParam("city") String city,
			@RequestParam("phoneNumber") long phoneNumber, @RequestParam("email") String email,
			@RequestParam(value="fax", required=false) String fax, @RequestParam("altPhoneNumber") long altPhoneNumber, Model model,
			RedirectAttributes redirectAttributes) throws Exception {
		try {
			//System.out.println("Fax "+fax);
			VendorsData vendor = new VendorsData();

			vendor.setAltPhoneNum((int) altPhoneNumber);
			vendor.setCity(city);
			vendor.setEmail(email);
			vendor.setFax(fax);
			vendor.setPhoneNum((int) phoneNumber);
			vendor.setSupplierDesc(supplierDesc);
			UserDetail user = currentUser.getCurrentUser();
			vendor.setCreatedBy(String.valueOf(user.getUserId()));

			vendorsDataRepository.save(vendor);

			//System.out.println("after saving");

			redirectAttributes.addFlashAttribute("vendorCreated", supplierDesc);
			redirectAttributes.addFlashAttribute("vendorAdded", true);
		}

		catch (Exception e) {

			redirectAttributes.addFlashAttribute("vendorCreated", supplierDesc);
			redirectAttributes.addFlashAttribute("vendorAdded", false);
			e.printStackTrace();

		}

		return "redirect:/home";
	}

	@RequestMapping(value = "/viewAllItems", method = RequestMethod.GET)
	public String viewAllItems(Model model) throws Exception {

		try {
			List<GroupDetails> groups = groupDetailRepository.findAll();

			Map<Integer, String> allCategories = new HashMap<>();

			for (GroupDetails string : groups) {
				allCategories.put(string.getGroupId(), string.getGroupDesc());

			}
			String json = new Gson().toJson(allCategories);

			model.addAttribute("categoryJson", json);
			
			return "itemsList";

		} catch (Exception e) {

			e.printStackTrace();
			throw e;
		}


	}

	@RequestMapping(value = "/applyFilterData", method = RequestMethod.POST, consumes = MediaType.ALL_VALUE)
	public @ResponseBody String applyFilterData(@RequestBody String json, RedirectAttributes redirectAttributes)
			throws Exception {

		try {
			
			System.out.println(json);
			
			JSONArray filterJson = new JSONArray(json);

			List<FilterDto> filterDtoList = new ArrayList<>();

			//System.out.println(filterJson);

			for (int i = 0; i < filterJson.length(); i++) {
				FilterDto filterDto = new FilterDto();

				filterDto.setSelectedType(filterJson.getJSONObject(i).get("selectedType").toString());

				filterDto.setValue1((filterJson.getJSONObject(i).get("value1").toString()));

				filterDto.setValue2(Integer.valueOf(filterJson.getJSONObject(i).get("value2").toString()));

				filterDto.setValueSelected(Integer.valueOf(filterJson.getJSONObject(i).get("value").toString()));

				filterDtoList.add(filterDto);

			}

			List<ItemsData> itemsData = new ArrayList<>();

			if (filterDtoList.get(1).getValueSelected() != 0) {

				if (filterDtoList.get(1).getValueSelected() == 1)
					itemsData = itemsDataRepository.findByGroupIdAndDescription(filterDtoList.get(0).getValueSelected(),
							filterDtoList.get(1).getValue1());

				else if (filterDtoList.get(1).getValueSelected() == 2)
					itemsData = itemsDataRepository.findByGroupIdAndPartNumber(filterDtoList.get(0).getValueSelected(),
							filterDtoList.get(1).getValue1());

				else if (filterDtoList.get(1).getValueSelected() == 3)
					itemsData = itemsDataRepository.findByGroupIdAndItemId(filterDtoList.get(0).getValueSelected(),
							Integer.valueOf(filterDtoList.get(1).getValue1()));

			}

			else if (filterDtoList.get(1).getValueSelected() == 0) {

				itemsData = itemsDataRepository.findByGroupId(filterDtoList.get(0).getValueSelected());

			}

			//System.out.println(itemsData.size());

			if (filterDtoList.get(2).getValueSelected() == 1 && filterDtoList.get(3).getValueSelected() == 0) { // executes when available selected without stock range
				

				itemsData=itemsData.stream().parallel().filter(p->checkForStockAvailableWithOutrange(p)).collect(Collectors.toList());
				
				}
			
			else if(filterDtoList.get(2).getValueSelected() == 1 && filterDtoList.get(3).getValueSelected() == 1) {  // executes when vaailable selected with stock range
				
				Long maxRange = Long.valueOf(filterDtoList.get(3).getValue1());
				Long minRange = Long.valueOf(filterDtoList.get(3).getValue2());

				itemsData = itemsData.stream().parallel()
						.filter(p -> checkForAvailableItemsWithInRange(p, maxRange, minRange))
						.collect(Collectors.toList());

				
			}

			else if (filterDtoList.get(2).getValueSelected() == 2) {  // executes when not available selected 

				
				itemsData = itemsData.stream().filter(p -> checkForNotAvailableItems(p)).collect(Collectors.toList());				
				
			}

			if (!itemsData.isEmpty()) {
				itemsData.get(0).setGroupId(10); // for search results
				itemsData.get(0).setDataPresent("dataPresent");
				itemsData.get(0).setCategoryString("Search results");
				String itemsDataJson = new Gson().toJson(itemsData);

				// System.out.println(itemsDataJson);

				return itemsDataJson;
			}

			else {

				ItemsData itemData = new ItemsData();

				itemData.setGroupId(10);
				itemData.setDataPresent("noData");
				itemData.setCategoryString("Search Results");
				itemsData.add(itemData);

				/*
				 * itemsData.get(0).setGroupId(10); // for search results
				 * itemsData.get(0).setCategoryString("noData");
				 */
				String itemsDataJson = new Gson().toJson(itemsData);

				// System.out.println(itemsDataJson);

				// String itemsDataJson = new Gson().toJson("noData");

				return itemsDataJson;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	private boolean checkForAvailableItemsWithInRange(ItemsData p, Long maxRange, Long minRange) {
		
		StockAvailable available = stockAvailableRepository.findByItemIdAndQuantityAvailableGreaterThanEqualAndQuantityAvailableLessThanEqual(p.getItemId(),minRange,maxRange);

		return available!=null?true:false;
	}

	private boolean checkForStockAvailableWithOutrange(ItemsData p) {
	
		StockAvailable available = stockAvailableRepository.findByItemIdAndQuantityAvailableGreaterThan(Long.valueOf(p.getItemId()),AssistConstantsParameters.NO_ITEMS_AVAILABLE);
		
		return available!=null?true:false;
		
		
	}

	private boolean checkForNotAvailableItems(ItemsData p) {

		StockAvailable available = stockAvailableRepository.findByItemIdAndQuantityAvailableGreaterThan(p.getItemId(),AssistConstantsParameters.NO_ITEMS_AVAILABLE);

		
		return (available==null)?true:false;
		
	}

}
