package com.rail.assist.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.jasperreports.JasperReportsPdfView;

import com.google.gson.Gson;
import com.rail.assist.config.CurrentUser;
import com.rail.assist.constants.AssistConstants;
import com.rail.assist.constants.AssistConstantsParameters;
import com.rail.assist.dto.IndentDataDto;
import com.rail.assist.dto.IndentPreviewDto;
import com.rail.assist.dto.PreviewDtoStrings;
import com.rail.assist.entities.Consignee;
import com.rail.assist.entities.IndentDetail;
import com.rail.assist.entities.IndentSerialNumber;
import com.rail.assist.entities.ItemsData;
import com.rail.assist.repository.AcceptableMakeRepository;
import com.rail.assist.repository.ConsigneeRepository;
import com.rail.assist.repository.DepotRepository;
import com.rail.assist.repository.IndentDetailRepository;
import com.rail.assist.repository.IndentPoRepository;
import com.rail.assist.repository.IndentSerialNumberRepository;
import com.rail.assist.repository.IndentorRepository;
import com.rail.assist.repository.ItemsDataRepository;
import com.rail.assist.repository.MaterialsIssueRelationRepository;
import com.rail.assist.repository.MaterialsRequiredAtRepository;
import com.rail.assist.repository.PoDetailRepository;
import com.rail.assist.repository.StockAvailableRepository;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.repository.VendorsDataRepository;
import com.rail.assist.service.IndentService;

@Controller
public class IndentController {

	@Autowired
	CurrentUser currentUser;

	@Autowired
	ConsigneeRepository consigneeRepository;

	@Autowired
	IndentorRepository indentorRepository;

	@Autowired
	MaterialsRequiredAtRepository materialsRequiredAtRepository;

	@Autowired
	DepotRepository depotRepository;

	@Autowired
	AcceptableMakeRepository acceptableMakeRepository;

	@Autowired
	IndentDetailRepository indentDetailRepository;

	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	UserDetailsRepository userDetailsRepository;

	@Autowired
	ItemsDataRepository itemsDataRepository;

	@Autowired
	StockAvailableRepository stockAvailableRepository;

	@Autowired
	MaterialsIssueRelationRepository materialsIssueRelationRepository;

	@Autowired
	VendorsDataRepository vendorsDataRepository;

	@Autowired
	IndentPoRepository indentPoRepository;

	@Autowired
	PoDetailRepository poDetailRepository;

	@Autowired
	IndentService indentService;

	@Autowired
	private AssistConstants assistConstants;
	
	@Autowired
	private IndentSerialNumberRepository indentSerialNumberRepository;

	@RequestMapping(value = "/indentForm", method = RequestMethod.GET)
	public String displayIndentForm(Model model) throws Exception {


		try {
			
			
			LocalDate cur=LocalDate.now();
			
			List<String> financialYears=new ArrayList<>();
			
			if(cur.getMonth().getValue()>=4) {
				
				financialYears.add(String.valueOf(cur.getYear())+"-"+String.valueOf(cur.getYear()+1));
				financialYears.add(String.valueOf(cur.getYear()+1)+"-"+String.valueOf(cur.getYear()+2));
				financialYears.add(String.valueOf(cur.getYear()+2)+"-"+String.valueOf(cur.getYear()+3));


				
			}
			else {
			
				financialYears.add(String.valueOf(cur.getYear()-1)+"-"+String.valueOf(cur.getYear()));
				
				financialYears.add(String.valueOf(cur.getYear())+"-"+String.valueOf(cur.getYear()+1));
				financialYears.add(String.valueOf(cur.getYear()+1)+"-"+String.valueOf(cur.getYear()+2));


				
			}
			
			model.addAttribute("financialYear", financialYears);
			return "indentForm";
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@RequestMapping(value = "/submitIndent", method = RequestMethod.POST)
	public String submitIndent(@RequestParam("indentId") long indentId, @RequestParam("qtyReq") int qtyReq,
			@RequestParam("offeredDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date offeredDate,
			@RequestParam("units") String units, @RequestParam("purpose") String purpose,
			@RequestParam("itemId") long itemId, @RequestParam("indentType") int indentType,
			@RequestParam(value = "description", required = false) String description,
			@RequestParam(value = "price", required = false) Double price,
			@RequestParam(value = "lastPurchasedData", required = false) String lastPurchasedData,
			@RequestParam("article") int article, @RequestParam("indentingOfficer") String controllingOfficer,
			@RequestParam(value = "likelySupplier", required = false) Integer likelySupplier,
			@RequestParam("financialYear") String financialYear, Model model,
			RedirectAttributes redirectAttributes) throws Exception {
		try {

		//	System.out.println(indentId + "----" + qtyReq + "----" + offeredDate + "----" + units + "----" + description
		//			+ "88888" + purpose + "------" + itemId + ",,,," + lastPurchasedData + "---" + article + "---"
			//		+ likelySupplier);

			IndentPreviewDto indentDto = new IndentPreviewDto();

			indentDto.setIndentId(indentId);
			indentDto.setQtyIndented(qtyReq);
			indentDto.setDate(offeredDate);
			indentDto.setUnits(units);
			indentDto.setPurpose(purpose);
			indentDto.setItemId(itemId);
			indentDto.setIndentType(indentType);
			indentDto.setDesc(description);
			indentDto.setFinancialYear(financialYear);
			if (price != null)
				indentDto.setRate(Double.valueOf(price));
			else
				indentDto.setRate(0.00);

			indentDto.setLastpurchaseDetails(lastPurchasedData);
			if (article == 1)
				indentDto.setArticleEnclosed(true);
			if (article == 2)
				indentDto.setArticleEnclosed(false);

			indentDto.setControllingOfficer(controllingOfficer);

			if (likelySupplier != null)
				indentDto.setLikelySupplier(likelySupplier);
			else
				indentDto.setLikelySupplier(0);

			ItemsData itemsData = itemsDataRepository.findByItemId(new Long(itemId));

			IndentDetail indent = indentService.createIndentPreview(itemsData, indentDto);
			
			indent.setFinancialYear(financialYear);
			

			IndentPreviewDto previewDto = generatePreviewDetails(indent);

			
			previewDto.getConsumptionYear1();
			
			model.addAttribute("indentDetail", previewDto);
			// indentDetailRepository.save(indent);
			// redirectAttributes.addFlashAttribute("indentLoggedSuccess",
			// true);
			// redirectAttributes.addFlashAttribute("indentId", indentId);

			PreviewDtoStrings stringDto=new PreviewDtoStrings();
			
			stringDto.setPo1Data(previewDto.getoSPoData1());
			stringDto.setPo2Data(previewDto.getoSPoData2());
			stringDto.setPo3Data(previewDto.getoSPoData3());
			stringDto.setPo4Data(previewDto.getoSPoData4());
			stringDto.setAllocation(previewDto.getAlocation());
			stringDto.setDescription(previewDto.getDesc());
			stringDto.setLastPurchaseDetails(previewDto.getLastpurchaseDetails());
			stringDto.setPurpose(previewDto.getPurpose());
			stringDto.setUnits(previewDto.getUnits());
			stringDto.setControlingOfficer(previewDto.getControllingOfficer());
			String json = new Gson().toJson(stringDto);

			model.addAttribute("jsonString", json);
			
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;

		}

		model.addAttribute("vendors", vendorsDataRepository.findAll());
		return "indentPreviewDetails";
	}

	private IndentPreviewDto generatePreviewDetails(IndentDetail indent) throws Exception {

		try {
			IndentPreviewDto preview = new IndentPreviewDto();
			//DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

			//System.out.println(indent.toString());
			preview.setLikelySupplier((int) indent.getLikelySupplier());
			preview.setItemId(indent.getItemId());
			preview.setDate(indent.getDate());
			preview.setSerialNumber((int) indent.getSerialNumber());
			preview.setIndentor(indentorRepository.findByIndentorId(indent.getIndentor()).getIndentorDesc());
			Consignee consignee = consigneeRepository.findById((int) indent.getConsignee());
			preview.setConsignee(consignee.getConsigneeDesc());
			preview.setConsigneeCode(consignee.getConsigneeId());
			preview.setMatReqAt(materialsRequiredAtRepository.findById(indent.getMaterialsRequiredAt()).getLocationDesc());
			preview.setDepot(depotRepository.findByDepotId(indent.getDepot()).getDepotDesc());
			preview.setQtyIndented((int) indent.getQuantityReq());
			preview.setUnits(indent.getUnits());
			preview.setAlocation(indent.getAllocation());
			preview.setDesc(indent.getDescription());
			preview.setPurpose(indent.getPurpose());
			preview.setLastpurchaseDetails(indent.getLastPurchaseParticulars());
			//System.out.println(indent.getOsaAgnstIndents()+" out standing against indents !!");
			preview.setOaIndents(indent.getOsaAgnstIndents());
			preview.setOaPo(indent.getOsaAgnstPo());
			preview.setQtyAvailable((int) indent.getStockAvailable());
			preview.setIndentId(indent.getIndentId());
			preview.setRate((double) indent.getRate());
			preview.setValue((long) (indent.getRate() * indent.getQuantityReq()));
			preview.setIndentType(indent.getIndentType());

			//LocalDate today = LocalDate.now();
			//int month = today.getMonthValue();

			//System.out.println("Month++++++++++++="+month+" year:::::::::"+today.getYear());
			
			/*if (month < 4)
				preview.setFinancialYear(String.valueOf(today.getYear() - 1) + "-" + String.valueOf(today.getYear()));
			else
				preview.setFinancialYear(String.valueOf(today.getYear()) + "-" + String.valueOf(today.getYear()+1));*/

			//System.out.println("Financial year :::::::::::: "+preview.getFinancialYear());
			
			preview.setFinancialYear(indent.getFinancialYear());
			
			String[] osIndentData = indent.getOsIndentData().split("%%");

			int j = 1;

			for (String string : osIndentData) {
				if (j == 1)
					preview.setoSindentsData1(string);

				if (j == 2)
					preview.setoSindentsData2(string);

				if (j == 3)
					preview.setoSindentsData3(string);
				if (j == 4)
					preview.setoSindentsData4(string);

				j++;
			}

			String[] osPoData = indent.getOsPoData().split("&&");

			int m = 1;
			for (String string : osPoData) {

				if (m == 1) {

					String[] osPoData1 = string.split("%%");

					preview.setoSPoData1(osPoData1[0]);
					preview.setoSPoData1Date(osPoData1[1]);

				} else if (m == 2) {

					String[] osPoData2 = string.split("%%");

					preview.setoSPoData2(osPoData2[0]);
					preview.setoSPoData2Date(osPoData2[1]);

				//	System.out.println(preview.getoSPoData2() + "++++++++++++" + preview.getoSPoData2Date());

				} else if (m == 3) {
					String[] osPoData3 = string.split("%%");
					preview.setoSPoData3(osPoData3[0]);
					preview.setoSPoData3Date(osPoData3[1]);

				} else if (m == 4) {

					String[] osPoData4 = string.split("%%");

					preview.setoSPoData4(osPoData4[0]);
					preview.setoSPoData4Date(osPoData4[1]);

				}

				m++;

			}

			preview.setLikelySupplierDesc(vendorsDataRepository.findById(indent.getLikelySupplier()).getSupplierDesc());

			preview.setControllingOfficer(indent.getControllingOfficer());

			// if (indent.getControllingOfficer() == 1)
			// preview.setControllingOfficer(
			// assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_ADEN_DESC));
			//
			// else if (indent.getControllingOfficer() == 2)
			// preview.setControllingOfficer(
			// assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_XEN_DESC));

			preview.setApprovingOfficer(assistConstants.getParameterValue(AssistConstantsParameters.APPROVING_OFFICER));

			preview.setIndentingOfficer(assistConstants.getParameterValue(AssistConstantsParameters.INDENTING_OFFICER));

			if (indent.getArticleEnclosed() == 1)
				preview.setArticleEnclosed(true);

			
			String[] consumpArr=indent.getConsmpLstThreeYrs().split("%%");
			preview.setConsumptionYear1(Integer.valueOf(consumpArr[0]));
			preview.setConsumptionYear2(Integer.valueOf(consumpArr[1]));
			preview.setConsumptionYear3(Integer.valueOf(consumpArr[2]));

			
			//System.out.println(preview.toString());
			return preview;
		} catch (Exception e) {
			      
			e.printStackTrace();
			
			throw e;
		}

	}

	@RequestMapping("/showDetails/{id}")
	public String showIndent(@PathVariable long id, Model model) throws NumberFormatException, Exception {
		try {
			//System.out.println(id + " ---------" + id);

			IndentDataDto indentDataDto = new IndentDataDto();

			indentDataDto = indentService.getIndentData(id);

			model.addAttribute("indentDetail", indentDataDto);
			//System.out.println(indentDataDto.toString());
			return "viewIndentDetails";
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}

	}

	@RequestMapping("/showIndentDetails/{id}")
	public String showIndentDetails(@PathVariable long id, Model model) throws NumberFormatException, Exception {

		try {
			IndentDataDto indentDataDto = new IndentDataDto();

			indentDataDto = indentService.getIndentDataWithIndentId(id);

			model.addAttribute("indentDetail", indentDataDto);
			
			//System.out.println(indentDataDto.toString());


			return "viewIndentDetails";
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}

	}

	@RequestMapping(value = "/printIndentForm", method = RequestMethod.POST)
	ModelAndView generateIndentForm1(@RequestParam("indentId") long indentId) throws Exception {
		try {
			IndentDetail indentData = indentDetailRepository.findByIndentId(indentId);

			JasperReportsPdfView view = new JasperReportsPdfView();
			view.setUrl("classpath:jasper/indent.jrxml");
			view.setApplicationContext(applicationContext);
			Map<String, Object> model = new HashMap<>();

			model = indentService.getIndentDataToPrint(indentData);

			return new ModelAndView(view, model);
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}

	}

	@RequestMapping(value = "/submitPreviewdindent", method = RequestMethod.POST)
	public String submitPreviewdindent(@RequestParam("requisitionNumber") long indentId,
			@RequestParam("idNo") long itemId, @RequestParam("date") String date,
			@RequestParam("serialNo") long serialNo, @RequestParam("qtyDemanded") int qtyDemanded,
			@RequestParam("units") String units, @RequestParam("allocation") String allocation,
			@RequestParam("desc") String desc, @RequestParam(value = "purpose") String purpose,
			@RequestParam("lastPurchaseDetails") String lastPurchaseDetails,
			@RequestParam("qtyAvailable") long qtyAvailable, @RequestParam("qtyAgstIndent") int qtyAgstIndent,
			@RequestParam("qtyAgstPo") int qtyAgstPo, @RequestParam("rate") long rate,
			@RequestParam(value = "consumptionYear1", required = true) long consumptionYear1,
			@RequestParam("consumptionYear2") long consumptionYear2,
			@RequestParam("consumptionYear3") long consumptionYear3,
			@RequestParam(value = "oSindentsData1", required = true) String oSindentsData1,
			@RequestParam(value = "oSindentsData2", required = true) String oSindentsData2,
			@RequestParam(value = "oSindentsData3", required = true) String oSindentsData3,
			@RequestParam(value = "oSindentsData4", required = true) String oSindentsData4,
			@RequestParam(value="oSPoData1", required = true) String oSPoData1, @RequestParam(value="oSPoData2", required = true) String oSPoData2,
			@RequestParam(value = "oSPoData3", required = true) String oSPoData3,
			@RequestParam(value = "oSPoData4", required = true) String oSPoData4,
			@RequestParam(value = "likelySupplier", required = true) long likelySupplier,
			@RequestParam("financialYear") String financialYear, @RequestParam("articleEnclosed") String articleEnclosed,
			@RequestParam("oSPoDataDate1")  String oSPoData1Date,
			@RequestParam("oSPoDataDate2") String oSPoData2Date,
			@RequestParam("oSPoDataDate3") String oSPoData3Date,
			@RequestParam("oSPoDataDate4") String oSPoData4Date,
			@RequestParam(value = "controllingOfficer", required = true) String controllingOfficer,
			@RequestParam("indentType") int indentType, Model model, RedirectAttributes redirectAttributes)
			throws Exception {
		try {

		/*	System.out.println(indentId + "  ---  " + itemId + "  ---  " + date + "  ---  " + serialNo + "  ---  "
					+ qtyDemanded + "  ---  " + units + "  ---  " + desc + "  ---  " + purpose + "  ---  "
					+ lastPurchaseDetails + "  ---    ---  " + qtyAvailable + "  ---  " + qtyAgstIndent
					+ "  ---  " + qtyAgstPo + "  ---  " + consumptionYear1 + "  ---  " + consumptionYear2 + "  ---  "
					+ consumptionYear3 + "  ---  " + oSindentsData1 + "  ---  " + oSindentsData2 + "  ---  "
					+ oSindentsData3 + "  ---  " + oSindentsData4 + "  ---  " + oSPoData1 + "  ---  " + oSPoData2
					+ "  ---  " + oSPoData3 + "  ---  " + oSPoData4 + "  ---  " + likelySupplier + "  ---  "
					+ financialYear + "  ---  " + articleEnclosed + "  ---  " + controllingOfficer + " --"
					+ oSPoData1Date + " --" + oSPoData2Date + "---" + oSPoData3Date + "===" + oSPoData4Date);*/

			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

			DateFormat nonEditedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
			
			DateFormat editedDateFormat = new SimpleDateFormat("yyyy-MM-dd");

			DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
			 
			
			IndentDetail indentData = new IndentDetail();

			Date oSPoData1DateObj=null;
			Date oSPoData2DateObj=null;
			Date oSPoData3DateObj=null;
			Date oSPoData4DateObj=null;
			
			Date dateObj=null;
			
			String oSPoData1DateString=null;
			String oSPoData2DateString=null;

			String oSPoData3DateString=null;
			String oSPoData4DateString=null;
			

			if(date.charAt(4)=='-') {
				
				dateObj=editedDateFormat.parse(date);		
				}
			else {
				 dateObj = (Date)formatter.parse(date);
				
			}
			
			if (!oSPoData1Date.equals("NA") && oSPoData1Date.charAt(4) == '-') {
				// here we will get edited date
				oSPoData1DateObj = editedDateFormat.parse(oSPoData1Date);
				 oSPoData1DateString=dateFormat.format(oSPoData1DateObj);
			}

			else if (!oSPoData1Date.equals("NA") && oSPoData1Date.charAt(4) != '-') {
				// here will get unedited date
				oSPoData1DateObj = nonEditedDateFormat.parse(oSPoData1Date);
				 oSPoData1DateString=dateFormat.format(oSPoData1DateObj);

			}
			else {
				 oSPoData1DateString="NA";

			}

			
			if (!oSPoData2Date.equals("NA") && oSPoData2Date.charAt(4) == '-') {
				// here we will get edited date
				oSPoData2DateObj = editedDateFormat.parse(oSPoData2Date);
				 oSPoData2DateString=dateFormat.format(oSPoData2DateObj);

			}

			else if (!oSPoData2Date.equals("NA") && oSPoData2Date.charAt(4) != '-') {
				// here will get unedited date
				oSPoData2DateObj = nonEditedDateFormat.parse(oSPoData2Date);
				 oSPoData2DateString=dateFormat.format(oSPoData2DateObj);

			}
			else {
				 oSPoData2DateString="NA";

			}
			

			if (!oSPoData3Date.equals("NA") && oSPoData3Date.charAt(4) == '-') {
				// here we will get edited date
				oSPoData3DateObj = editedDateFormat.parse(oSPoData3Date);
				 oSPoData3DateString=dateFormat.format(oSPoData3DateObj);

			}

			else if (!oSPoData3Date.equals("NA") && oSPoData3Date.charAt(4) != '-') {
				// here will get unedited date
				oSPoData3DateObj = nonEditedDateFormat.parse(oSPoData3Date);
				 oSPoData3DateString=dateFormat.format(oSPoData3DateObj);

			}
			else {
				
				 oSPoData3DateString="NA";

			}
			
			if (!oSPoData4Date.equals("NA") && oSPoData4Date.charAt(4) == '-') {
				// here we will get edited date
				oSPoData4DateObj = editedDateFormat.parse(oSPoData4Date);
				 oSPoData4DateString=dateFormat.format(oSPoData4DateObj);

			}

			else if (!oSPoData4Date.equals("NA") && oSPoData4Date.charAt(4) != '-') {
				// here will get unedited date
				oSPoData4DateObj = nonEditedDateFormat.parse(oSPoData4Date);
				 oSPoData4DateString=dateFormat.format(oSPoData4DateObj);


			}
			else {
				
				 oSPoData4DateString="NA";

			}
			
			indentData.setIndentId(indentId);
			indentData.setItemId(itemId);
			indentData.setIndentor(
					Integer.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.INDENTOR)));
			indentData.setConsignee(
					Integer.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.CONSIGNEE)));
			indentData.setDate(dateObj);
			indentData.setMaterialsRequiredAt(Integer
					.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.MATERIALS_REQUIRED_AT)));
			indentData.setDepot(Integer.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.DEPOT)));
			indentData.setQuantityReq(qtyDemanded);
			indentData.setAllocation(allocation);
			indentData.setUnits(units);
			indentData.setAcceptableMake(
					Integer.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.ACCEPTABLE_MAKE)));
			indentData.setAllocation(allocation);
			indentData.setPurpose(purpose);
			indentData.setValue(rate*qtyDemanded);
			indentData.setRate(rate);
			indentData.setDescription(desc);
			indentData.setSerialNumber(serialNo);
			indentData.setLikelySupplier(likelySupplier);
			indentData.setPoQuantityRcvd(AssistConstantsParameters.NO_ITEMS_RECEIVED); // as nothing is received as of now
			if(articleEnclosed.equals("true"))
			indentData.setArticleEnclosed(1);
			else
				indentData.setArticleEnclosed(2);

			/*if (controllingOfficer == 1)
				indentData.setControllingOfficer(Integer.valueOf(
						assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_ADEN)));
			else
				indentData.setControllingOfficer(Integer
						.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_XEN)));
*/
			
			indentData.setControllingOfficer(controllingOfficer);
			indentData.setStockAvailable(qtyAvailable);
			indentData.setOsaAgnstIndents(qtyAgstIndent);
			indentData.setOsaAgnstPo(qtyAgstPo);
			indentData.setConsmpLstThreeYrs(consumptionYear1 + "%%" + consumptionYear2 + "%%" + consumptionYear3);
			//System.out.println(oSindentsData1 + "%%" + oSindentsData2 + "%%" + oSindentsData3 + "%%" + oSindentsData4);
			indentData.setOsIndentData(
					oSindentsData1 + "%%" + oSindentsData2 + "%%" + oSindentsData3 + "%%" + oSindentsData4);
			/*System.out.println(oSPoData1 + "%%" + oSPoData1Date + "&&" + oSPoData2 + "%%" + oSPoData2Date + "&&"
					+ oSPoData3 + "%%" + oSPoData3Date + "&&" + oSPoData4 + "%%" + oSPoData4Date);*/
			indentData.setOsPoData(oSPoData1 + "%%" + oSPoData1DateString + "&&" + oSPoData2 + "%%"
					+ oSPoData2DateString + "&&" + oSPoData3 + "%%" + oSPoData3DateString + "&&"
					+ oSPoData4 + "%%" + oSPoData4DateString);
			indentData.setFinancialYear(financialYear);
			indentData.setIndentLoggedBy(currentUser.getCurrentUser().getUserId());
			indentData.setIndentType(indentType);

			if (indentType == AssistConstantsParameters.INDENT_TYPE_NORMAL)
				indentData.setLastPurchaseParticulars(lastPurchaseDetails);
			else {
				indentData.setLastPurchaseParticulars(
						assistConstants.getParameterValue(AssistConstantsParameters.LAST_PURCHASE_DATA_RC_INDENT));
			}
		
			
			IndentDetail indentData1 = indentDetailRepository.findByIndentId(indentId);
			
			if(indentData1==null) {
			indentDetailRepository.save(indentData);
			
			
			
			
			IndentSerialNumber serialNumber = indentSerialNumberRepository.findByFinancialYearAndItemType(financialYear,
					Long.valueOf(String.valueOf(itemId).substring(0, 1)));

			
			if (serialNumber == null) {
				IndentSerialNumber i = new IndentSerialNumber();
				i.setItemType(Integer.valueOf(String.valueOf(itemId).substring(0, 1)));
				i.setFinancialYear(financialYear);
				i.setLastUpdate(new Date());
				i.setSerialNumber(1); // as this is first entry
				indentSerialNumberRepository.save(i);

			}
			else
			{
			//serialNumber.setSerialNumber(serialNumber.getSerialNumber()+1);
			
			//indentSerialNumberRepository.save(serialNumber);
			
				serialNumber.setSerialNumber(serialNumber.getSerialNumber()+1); // as this is first entry
				serialNumber.setLastUpdate(new Date());
				indentSerialNumberRepository.save(serialNumber);

			
			}
			
			redirectAttributes.addFlashAttribute("indentLogged", true);
			redirectAttributes.addFlashAttribute("indentId", indentId);
			}
			else {
				redirectAttributes.addFlashAttribute("indentLogged", "alreadyPresent");
				redirectAttributes.addFlashAttribute("indentId", indentId);
			}
				

		} catch (Exception e) {
			e.printStackTrace();
			redirectAttributes.addFlashAttribute("indentLogged", false);
			redirectAttributes.addFlashAttribute("indentId", indentId);
		}
		return "redirect:/home";
	}
}
