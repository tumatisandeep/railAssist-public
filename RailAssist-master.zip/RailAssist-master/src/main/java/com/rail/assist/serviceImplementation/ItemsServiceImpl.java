package com.rail.assist.serviceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.rail.assist.entities.ItemsData;
import com.rail.assist.entities.StockAvailable;
import com.rail.assist.repository.GenderRepository;
import com.rail.assist.repository.ItemsDataRepository;
import com.rail.assist.repository.MaterialsIssueDataRepository;
import com.rail.assist.repository.MaterialsIssueRelationRepository;
import com.rail.assist.repository.StockAvailableRepository;
import com.rail.assist.repository.UserAccountStatusRepository;
import com.rail.assist.repository.UserDesignationRepository;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.repository.UserLoginStatusRepository;
import com.rail.assist.service.ItemsService;

@Service
public class ItemsServiceImpl implements ItemsService {

	@Autowired
	UserDesignationRepository userDesignationRepository;

	@Autowired
	GenderRepository genderRepository;

	@Autowired
	UserLoginStatusRepository userLoginStatusRepository;

	@Autowired
	UserAccountStatusRepository userAccountStatusRepository;

	@Autowired
	UserDetailsRepository userDetailsRepository;
	
	@Autowired
	MaterialsIssueDataRepository materialsIssueDataRepository;
	
	@Autowired
	ItemsDataRepository itemsDataRepository;
	
	@Autowired
	StockAvailableRepository stockAvailableRepository;

	@Autowired
	MaterialsIssueRelationRepository materialsIssueRelationRepository;

	

	
	public List<ItemsData> getAllItems(int catId) throws Exception {

       try {
		return itemsDataRepository.findTop12ByGroupId(catId);
		    //return (List<IssueDetail>) issueDetailRepository.findAll(pageable);
	} catch (Exception e) {
		      
		e.printStackTrace();
		throw e;
	}
    }




	@Override
	public boolean addItem(StockAvailable stockAvailable, ItemsData itemsData)  {
		
		
		try{

		itemsDataRepository.save(itemsData);


		stockAvailableRepository.save(stockAvailable);
		
		return true;

		}catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}




		

}
