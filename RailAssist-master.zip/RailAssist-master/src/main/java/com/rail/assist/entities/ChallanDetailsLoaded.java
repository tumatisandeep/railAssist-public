package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the indent_details database table.
 * 
 */
@Entity
@Table(name = "challan_details_loaded")
@NamedQuery(name = "ChallanDetailsLoaded.findAll", query = "SELECT i FROM ChallanDetailsLoaded i")
public class ChallanDetailsLoaded implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	@Column(name = "note_no")
	private String noteNo;

	
	private String date;

	@Column(name = "idn")
	private String idn;

	@Column(name = "quantity")
	private float quantity;

	@Column(name = "issued_to")
	private String issuedTo;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_update")
	private Date dateObj;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNoteNo() {
		return noteNo;
	}

	public void setNoteNo(String noteNo) {
		this.noteNo = noteNo;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getIdn() {
		return idn;
	}

	public void setIdn(String idn) {
		this.idn = idn;
	}

	public float getQuantity() {
		return quantity;
	}

	public void setQuantity(float quantity) {
		this.quantity = quantity;
	}

	public String getIssuedTo() {
		return issuedTo;
	}

	public void setIssuedTo(String issuedTo) {
		this.issuedTo = issuedTo;
	}

	public Date getDateObj() {
		return dateObj;
	}

	public void setDateObj(Date dateObj) {
		this.dateObj = dateObj;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}