package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the purchase_order_details database table.
 * 
 */
@Embeddable
public class PurchaseOrderDetailPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PURCHASE_ORDER_DETAILS_ID")
	private int purchaseOrderDetailsId;

	@Column(name="SUPPLY_ORDER_ID")
	private int supplyOrderId;

	public PurchaseOrderDetailPK() {
	}
	public int getPurchaseOrderDetailsId() {
		return this.purchaseOrderDetailsId;
	}
	public void setPurchaseOrderDetailsId(int purchaseOrderDetailsId) {
		this.purchaseOrderDetailsId = purchaseOrderDetailsId;
	}
	public int getSupplyOrderId() {
		return this.supplyOrderId;
	}
	public void setSupplyOrderId(int supplyOrderId) {
		this.supplyOrderId = supplyOrderId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PurchaseOrderDetailPK)) {
			return false;
		}
		PurchaseOrderDetailPK castOther = (PurchaseOrderDetailPK)other;
		return 
			(this.purchaseOrderDetailsId == castOther.purchaseOrderDetailsId)
			&& (this.supplyOrderId == castOther.supplyOrderId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.purchaseOrderDetailsId;
		hash = hash * prime + this.supplyOrderId;
		
		return hash;
	}
}