package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the user_details database table.
 * 
 */
@Embeddable
public class UserDetailPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="USER_DETAILS_ID")
	private int userDetailsId;

	@Column(name="USER_ID")
	private int userId;

	public UserDetailPK() {
	}
	public int getUserDetailsId() {
		return this.userDetailsId;
	}
	public void setUserDetailsId(int userDetailsId) {
		this.userDetailsId = userDetailsId;
	}
	public int getUserId() {
		return this.userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof UserDetailPK)) {
			return false;
		}
		UserDetailPK castOther = (UserDetailPK)other;
		return 
			(this.userDetailsId == castOther.userDetailsId)
			&& (this.userId == castOther.userId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.userDetailsId;
		hash = hash * prime + this.userId;
		
		return hash;
	}
}