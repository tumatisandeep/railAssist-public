package com.rail.assist.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.jasperreports.JasperReportsPdfView;

import com.google.gson.Gson;
import com.rail.assist.config.CurrentUser;
import com.rail.assist.constants.AssistConstants;
import com.rail.assist.constants.AssistConstantsParameters;
import com.rail.assist.dto.ItemsIssuedDtoHome;
import com.rail.assist.entities.MaterialIssueData;
import com.rail.assist.repository.IndentDetailRepository;
import com.rail.assist.repository.IndentPoRepository;
import com.rail.assist.repository.MaterialsIssueDataRepository;
import com.rail.assist.repository.MaterialsIssueRelationRepository;
import com.rail.assist.repository.PoDetailRepository;
import com.rail.assist.repository.StockAvailableRepository;
import com.rail.assist.service.ChallanService;
import com.rail.assist.service.IssuingDetailsService;

@Controller
public class ItemsIssuedData {

	@Autowired
	CurrentUser currentUser;

	@Autowired
	IndentDetailRepository indentDetailRepository;

	@Autowired
	PoDetailRepository poDetailRepository;

	@Autowired
	IndentPoRepository indentPoRepository;

	@Autowired
	MaterialsIssueDataRepository materialsIssueDataRepository;

	@Autowired
	MaterialsIssueRelationRepository materialsIssueRelationRepository;

	@Autowired
	StockAvailableRepository stockAvailableRepository;

	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	IssuingDetailsService issuingDetailsService;

	@Autowired
	ChallanService challanService;

	@Autowired
	private AssistConstants assistConstants;
	

	@RequestMapping(value = "/itemsIssuingDetails", method = RequestMethod.GET)
	public String itemsDataSpent(Model model, RedirectAttributes redirectAttributes) throws Exception {

	
		return "itemsIssuingDetails";
	}

	@RequestMapping(value = "/submitItemIssuingData", method = RequestMethod.POST, consumes = MediaType.ALL_VALUE)
	public @ResponseBody String submitItemIssuingData(@RequestBody String json, RedirectAttributes redirectAttributes)
			throws Exception {
		String response = null;
		JSONArray itemsIssued = new JSONArray(json);
		//System.out.println(json);
		String itemsIssuedDataAdded="failure";

		try {
			
			itemsIssuedDataAdded=issuingDetailsService.addChallanDetails(itemsIssued);
			
			response=itemsIssuedDataAdded;

		} catch (Exception e) {
			response = "failure";
			e.printStackTrace();
		}

		Map<String, String> responseMap = new HashMap<>();

		responseMap.put("response", response);
		responseMap.put("challanNumber", itemsIssued.getString(0));

		String responseJson = new Gson().toJson(responseMap);

	//	System.out.println(responseJson + " ---- response Json--");
		return responseJson;
	}

	@RequestMapping("/issuedDetails/{id}")
	public String showIssuedDetails(@PathVariable int id, Model model) throws NumberFormatException, Exception {


		ItemsIssuedDtoHome itemsData = new ItemsIssuedDtoHome();

		itemsData = challanService.getChallanData(id);

		model.addAttribute("itemsData", itemsData);

		return "viewIssuedDetails";

	}

	@RequestMapping(value = "/printChallan", method = RequestMethod.POST)
	ModelAndView generateIssuingDataReport(@RequestParam("challanId") long challanId) throws Exception {

		try {
			JasperReportsPdfView view = new JasperReportsPdfView();
			view.setUrl("classpath:jasper/issuingChallan.jrxml");
			view.setApplicationContext(applicationContext);
			
			
			
			Map<String, Object> model = new HashMap<>();

			List<Map<String, String>> challanDetails = issuingDetailsService.printChallan(challanId);

			MaterialIssueData materialIssue = materialsIssueDataRepository.findByMaterialIssueId(challanId);

			if (Integer.valueOf(
					assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_I_RYP)) == materialIssue
							.getMaterialIssuedBy())
				model.put("issuedFrom",
						assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_I_RYP_DESC));

			if (Integer.valueOf(
					assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_II_RYP)) == materialIssue
							.getMaterialIssuedBy())
				model.put("issuedFrom",
						assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_II_RYP_DESC));

			//System.out.println(challanDetails+"challan challan challan");
			
			model.put("listData", challanDetails);

			model.put("issuedTo", materialIssue.getMaterialIssueTo());
			model.put("challanNumber", materialIssue.getChallanNumber());
			model.put("date", materialIssue.getDateIssue());
			
			model.put("imageLocation", assistConstants.getParameterValue(AssistConstantsParameters.CHALLAN_REPORT_IMAGE_PATH));

			return new ModelAndView(view, model);
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}

	}

	@RequestMapping(value = "/returnToHomeFromChallanForm", method = { RequestMethod.GET, RequestMethod.POST })
	public String returnToHomeFromPo(@RequestParam(value = "response", required = false) String response, RedirectAttributes model)
			throws JSONException {

		//System.out.println(response);

		JSONObject json = new JSONObject(response);

		//System.out.println(json.getString("response") + " ------ " + json.getString("challanNumber"));

		
		if(json.getString("response").equals("success")){
			model.addFlashAttribute("challanAdded", json.getString("response"));
			model.addFlashAttribute("challanNumber", json.getString("challanNumber"));
		}
		
		else {
			model.addFlashAttribute("challanAdded", json.getString("response"));
			model.addFlashAttribute("challanNumber", json.getString("challanNumber"));
			
		}
		

		return "redirect:/home";
	}
	
	
	
}
