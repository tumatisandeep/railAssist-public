package com.rail.assist.dto;

import java.util.Date;
import java.util.List;

public class ItemsIssuedDtoHome {
	
	private int noOfItems;
	
	private long id;

	private String challanNumber;
	
	private String loggedBy;
	
	private String title;
	
	private String desc;
	
	private Date date;
	
	private String issuedFrom;
	
	private String issuedTo;
	
	private long uniqueRelationNo;
	
	private boolean challanFound;
	
	private String issuedToPerson;
	
	
	public boolean isChallanFound() {
		return challanFound;
	}

	public void setChallanFound(boolean challanNotFound) {
		this.challanFound = challanNotFound;
	}

	public long getUniqueRelationNo() {
		return uniqueRelationNo;
	}

	public List<ItemsIssuedDataDto> getList() {
		return list;
	}

	public void setUniqueRelationNo(long uniqueRelationNo) {
		this.uniqueRelationNo = uniqueRelationNo;
	}

	public void setList(List<ItemsIssuedDataDto> list) {
		this.list = list;
	}

	private List<ItemsIssuedDataDto> list;

	
	
	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getNoOfItems() {
		return noOfItems;
	}

	public String getChallanNumber() {
		return challanNumber;
	}

	public String getLoggedBy() {
		return loggedBy;
	}

	public String getTitle() {
		return title;
	}

	public String getDesc() {
		return desc;
	}

	public Date getDate() {
		return date;
	}

	public String getIssuedFrom() {
		return issuedFrom;
	}

	public String getIssuedTo() {
		return issuedTo;
	}

	public void setNoOfItems(int noOfItems) {
		this.noOfItems = noOfItems;
	}

	public void setChallanNumber(String challanNumber) {
		this.challanNumber = challanNumber;
	}

	public void setLoggedBy(String string) {
		this.loggedBy = string;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setIssuedFrom(String issuedFrom) {
		this.issuedFrom = issuedFrom;
	}

	public void setIssuedTo(String issuedTo) {
		this.issuedTo = issuedTo;
	}

	public String getIssuedToPerson() {
		return issuedToPerson;
	}

	public void setIssuedToPerson(String issuedToPerson) {
		this.issuedToPerson = issuedToPerson;
	}
	
	
}
