package com.rail.assist.serviceImplementation;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rail.assist.config.CurrentUser;
import com.rail.assist.dto.ItemsReceivedDtoHome;
import com.rail.assist.entities.IndentPoRelation;
import com.rail.assist.entities.MaterialsReceivedData;
import com.rail.assist.entities.StockAvailable;
import com.rail.assist.repository.IndentPoRepository;
import com.rail.assist.repository.MaterialsReceivedDataRepository;
import com.rail.assist.repository.StockAvailableRepository;
import com.rail.assist.service.ItemsReceivedService;

@Service
public class ItemsReceivedServiceImpl implements ItemsReceivedService {

	@Autowired
	MaterialsReceivedDataRepository materialsReceivedDataRepository;

	@Autowired
	private IndentPoRepository indentPoRepository;

	@Autowired
	private CurrentUser currentUser;

	@Autowired
	private StockAvailableRepository stockAvailableRepository;

	public MaterialsReceivedData getItemReceivedDetails(long id) {

		MaterialsReceivedData itemData = materialsReceivedDataRepository.findById(id);

		return itemData;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.rail.assist.service.ItemsReceivedService#addItemsReceivedData(long,
	 * int, java.util.Date, java.lang.String)
	 */
	@Override
	////@Transactional(rollbackFor=Throwable.class)
	public boolean addItemsReceivedData(long itemId, int quantityReceived, Date dateReceived, String poIndentNumber) throws Exception {
		MaterialsReceivedData materialsData = new MaterialsReceivedData();

		try {
			//int i=5/0;
			String poNumber=poIndentNumber.substring(poIndentNumber.indexOf(":")+1, poIndentNumber.indexOf("for")).trim();
			long indentId=Long.valueOf(poIndentNumber.substring(poIndentNumber.indexOf("indent")+"indent".length()).trim());
			
			materialsData.setItemId(itemId);
			materialsData.setNumberOfItemsReceived(quantityReceived);
			materialsData.setDateReceived(dateReceived);
			materialsData.setPoNumber(poNumber);
			materialsData.setCreatedBy(currentUser.getCurrentUser().getUserId());
			materialsData.setIndentId(indentId);
			materialsReceivedDataRepository.save(materialsData);

			// need to update if data is received partially or completely

			IndentPoRelation indentPoId = indentPoRepository.findByPoNumberAndItemIdAndIdIndentId(poNumber, itemId, indentId);
			if (indentPoId.getPoReceivedQuantity() > indentPoId.getQtyReceived())
				indentPoId.setQtyReceived(indentPoId.getQtyReceived() + quantityReceived);

			// if(indentPoId.getQuantityIndented()==indentPoId.getQtyReceived())
			// indentPoId.setIsTotalQtyReceived(AssistConstantsParameters.TOTAL_QUANTITY_RECEIVED_FOR_INDNET_IN_PO);

			indentPoRepository.save(indentPoId);

			// need to increase the value in stock table

			StockAvailable stockAvailable = stockAvailableRepository.findByItemId(itemId);
			if (stockAvailable == null) {
				StockAvailable stockAvailableItem = new StockAvailable();

				stockAvailableItem.setItemId(itemId);
				stockAvailableItem.setQuantityAvailable(quantityReceived);
				stockAvailableItem.setDataPresent(true);
				stockAvailableRepository.save(stockAvailableItem);

			}

			else {
				stockAvailable.setQuantityAvailable(stockAvailable.getQuantityAvailable() + quantityReceived);
				stockAvailableRepository.save(stockAvailable);
			}

			return true;

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
			//return false;
		}
	}

}
