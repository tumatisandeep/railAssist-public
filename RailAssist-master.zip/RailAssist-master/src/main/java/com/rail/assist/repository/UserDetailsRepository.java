package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.UserDetail;


public interface UserDetailsRepository extends JpaRepository<UserDetail,Long> {
	
	UserDetail findByUserMailIdAndUserPassword(String id,String password);

	UserDetail findByUserId(long id);
	
	
	
}



