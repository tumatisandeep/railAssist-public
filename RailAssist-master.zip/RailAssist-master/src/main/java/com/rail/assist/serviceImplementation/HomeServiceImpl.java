package com.rail.assist.serviceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.rail.assist.entities.IndentDetail;
import com.rail.assist.entities.MaterialIssueData;
import com.rail.assist.entities.MaterialsReceivedData;
import com.rail.assist.entities.PurchaseOrderDetail;
import com.rail.assist.repository.IndentDetailRepository;
import com.rail.assist.repository.MaterialsIssueDataRepository;
import com.rail.assist.repository.MaterialsReceivedDataRepository;
import com.rail.assist.repository.PoDetailRepository;
import com.rail.assist.service.HomeService;

@Service
public class HomeServiceImpl implements HomeService {


	@Autowired
	private IndentDetailRepository indentDetailRepository;

	@Autowired
	private PoDetailRepository poDetailRepository;



	@Autowired
	private MaterialsIssueDataRepository materialsIssueDataRepository;

	@Autowired
	private MaterialsReceivedDataRepository materialsReceivedDataRepository;
	
	

	@Override
	////@Transactional(rollbackFor=Throwable.class)
	public List<IndentDetail> getAllIndents(Pageable pageable) {
    	
		
		try {
			return indentDetailRepository.findAll(pageable).getContent();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
    }


	@Override
	public long getTotalCountOfIndents() {
		
		try {
			return indentDetailRepository.count();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


	@Override
	public List<PurchaseOrderDetail> getAllPos(Pageable pageable) {
		
		try {
			return poDetailRepository.findAll(pageable).getContent();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
}



	
	@Override
	public List<MaterialsReceivedData> getAllItemsReceivedData(Pageable pageable) {

		try {
			return materialsReceivedDataRepository.findAll(pageable).getContent();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}



	@Override
	public List<MaterialIssueData> getAllItemsChallanData(Pageable pageable) {

		
		try {
			return materialsIssueDataRepository.findAll(pageable).getContent();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	
	
}
