package com.rail.assist.serviceImplementation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rail.assist.config.CurrentUser;
import com.rail.assist.constants.AssistConstants;
import com.rail.assist.constants.AssistConstantsParameters;
import com.rail.assist.dto.IndentDataDto;
import com.rail.assist.dto.IndentPreviewDto;
import com.rail.assist.entities.ChallanDetailsLoaded;
import com.rail.assist.entities.Consignee;
import com.rail.assist.entities.IndentDetail;
import com.rail.assist.entities.IndentPoRelation;
import com.rail.assist.entities.ItemsData;
import com.rail.assist.entities.MaterialsIssueRelation;
import com.rail.assist.entities.StockAvailable;
import com.rail.assist.entities.UserDetail;
import com.rail.assist.entities.VendorsData;
import com.rail.assist.repository.AcceptableMakeRepository;
import com.rail.assist.repository.ChallanDetailsLoadedRepository;
import com.rail.assist.repository.ConsigneeRepository;
import com.rail.assist.repository.DepotRepository;
import com.rail.assist.repository.IndentDetailRepository;
import com.rail.assist.repository.IndentPoRepository;
import com.rail.assist.repository.IndentorRepository;
import com.rail.assist.repository.ItemsDataRepository;
import com.rail.assist.repository.MaterialsIssueRelationRepository;
import com.rail.assist.repository.MaterialsRequiredAtRepository;
import com.rail.assist.repository.PoDetailRepository;
import com.rail.assist.repository.StockAvailableRepository;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.repository.VendorsDataRepository;
import com.rail.assist.service.IndentService;
import com.rail.assist.special.NumberToText;

@Service
public class IndentServiceImpl implements IndentService {

	@Autowired
	CurrentUser currentUser;

	@Autowired
	ConsigneeRepository consigneeRepository;

	@Autowired
	IndentorRepository indentorRepository;

	@Autowired
	MaterialsRequiredAtRepository materialsRequiredAtRepository;

	@Autowired
	DepotRepository depotRepository;

	@Autowired
	AcceptableMakeRepository acceptableMakeRepository;

	@Autowired
	IndentDetailRepository indentDetailRepository;

	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	UserDetailsRepository userDetailsRepository;

	@Autowired
	ItemsDataRepository itemsDataRepository;

	@Autowired
	StockAvailableRepository stockAvailableRepository;

	@Autowired
	MaterialsIssueRelationRepository materialsIssueRelationRepository;

	@Autowired
	VendorsDataRepository vendorsDataRepository;

	@Autowired
	IndentPoRepository indentPoRepository;

	@Autowired
	PoDetailRepository poDetailRepository;

	@Autowired
	IndentService indentService;

	@Autowired
	AssistConstants assistConstants;
	
	@Autowired
	ChallanDetailsLoadedRepository challanDetailsLoadedRepository;

	public IndentDataDto getIndentData(long id) throws NumberFormatException, Exception {

		try {
			//System.out.println(id + "======");

			IndentDataDto indentDataDto = new IndentDataDto();

			IndentDetail indentData = indentDetailRepository.findOne((int) id);

			indentDataDto = getIndentData(indentData);

			return indentDataDto;
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}

	}

	@Override
	public IndentDataDto getIndentDataWithIndentId(long uniqueId) throws NumberFormatException, Exception {

		try {
			IndentDataDto indentDataDto = new IndentDataDto();

			IndentDetail indentData = indentDetailRepository.findByIndentId(uniqueId);
			if (indentData != null) {
				indentDataDto = getIndentData(indentData);
				indentDataDto.setIndentFound(true);
				return indentDataDto;

			}

			else {
				indentDataDto.setIndentFound(false);
				return indentDataDto;

			}
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}

	}

	private IndentDataDto getIndentData(IndentDetail indentData) throws NumberFormatException, Exception {

		try {
			IndentDataDto indentDataDto = new IndentDataDto();

			indentDataDto
					.setIndentor(indentorRepository.findByIndentorId((int) indentData.getIndentor()).getIndentorDesc());

			//System.out.println((int) indentData.getConsignee());
			//System.out.println(consigneeRepository.findById((int) indentData.getConsignee()));
			indentDataDto.setConsignee(consigneeRepository.findById((int) indentData.getConsignee()).getConsigneeDesc());
			indentDataDto.setMaterialsReqAt(materialsRequiredAtRepository
					.findByLocationId((int) indentData.getMaterialsRequiredAt()).getLocationDesc());
			indentDataDto.setDepot(depotRepository.findByDepotId((int) indentData.getDepot()).getDepotDesc());
			indentDataDto.setAcceptableMake(acceptableMakeRepository.findByAcceptableMakeid(indentData.getAcceptableMake())
					.getacceptableMakeDesc());
			UserDetail userData = userDetailsRepository.findByUserId(indentData.getIndentLoggedBy());
			indentDataDto.setIndentloggedBy(userData.getUserFirstName() + " " + userData.getUserLastName());
			
			
			/*if(indentData.getControllingOfficer()==Integer.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_ADEN)))
			indentDataDto.setControllingofficer(assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_ADEN_DESC));
			else
			{
				indentDataDto.setControllingofficer(assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_XEN_DESC));

			}*/
			
			
			indentDataDto.setControllingofficer(indentData.getControllingOfficer());
			
			indentDataDto.setStockAvailable(indentData.getStockAvailable());
			indentDataDto.setosaAgnstIndents(indentData.getOsaAgnstIndents());
			indentDataDto.setosaAgnstPo(indentData.getOsaAgnstPo());
			
			indentDataDto.setFinancialyear(indentData.getFinancialYear());
			if (indentData.getQuantityReq() == indentData.getPoQuantityRcvd()) {
				indentDataDto.setPoReceived(true);
				indentDataDto.setPoDate(indentData.getPoDate());

			}

			else {
				indentDataDto.setPoReceived(false);

			}

			indentDataDto.setId(indentData.getId());
			indentDataDto.setTitle("This is title shoul be written");

			indentDataDto.setPurpose(indentData.getPurpose());
			indentDataDto.setAllocation(indentData.getAllocation());
			indentDataDto.setItemId(indentData.getItemId());
			indentDataDto.setIndentId(indentData.getIndentId());
			indentDataDto.setDate(indentData.getDate());
			indentDataDto.setQuantity((int) indentData.getQuantityReq());

			indentDataDto.setRate(indentData.getRate());
			indentDataDto.setValue(indentData.getValue());
			
			indentDataDto.setLoggedDate(indentData.getCreatedOn());

			return indentDataDto;
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.rail.assist.service.IndentService#createIndentPreview(com.rail.assist
	 * .entities.ItemsData, com.rail.assist.dto.IndentPreviewDto)
	 */
	@Override
	////@Transactional(rollbackFor=Throwable.class)
	public IndentDetail createIndentPreview(ItemsData itemsData, IndentPreviewDto indentDto)
			throws NumberFormatException, Exception {

		try {
			IndentDetail indent = new IndentDetail();

			indent.setIndentId(indentDto.getIndentId());

			indent.setIndentor(Integer.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.INDENTOR)));

			indent.setIndentType(indentDto.getIndentType());

			if (indentDto.getIndentType() == AssistConstantsParameters.INDENT_TYPE_RC) {
				System.out.println("Have to set Serial NUmber for RC indent !!");
			}
			indent.setDate(indentDto.getDate());

			indent.setQuantityReq(indentDto.getQtyIndented());

			indent.setUnits(indentDto.getUnits());

			indent.setPurpose(indentDto.getPurpose());

			indent.setItemId(indentDto.getItemId());

			indent.setAllocation(assistConstants.getParameterValue(AssistConstantsParameters.ALLOCATION_FOR_INDENT));

			indent.setConsignee(Integer.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.CONSIGNEE)));

			indent.setMaterialsRequiredAt(
					Integer.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.MATERIALS_REQUIRED_AT)));

			if (indentDto.getDesc() != null)
				indent.setDescription(indentDto.getDesc());
			else
				indent.setDescription(itemsData.getDescription() + " as per Plasser Pt.No " + itemsData.getPartNumber());
			
			indent.setFinancialYear(indentDto.getFinancialYear());

			// calculating price

			if (indentDto.getRate() == 0) {

				Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "createdOn"));
				Pageable pageable = new PageRequest(0, 1, sort);

				List<IndentPoRelation> recentPo = indentPoRepository.findByItemId(itemsData.getItemId(), pageable)
						.getContent();

				indent.setRate(recentPo.get(0).getRatePurchased());

			} else
				indent.setRate(indentDto.getRate());

			indent.setValue(indent.getRate() * indentDto.getQtyIndented());

			indent.setDepot(Integer.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.DEPOT)));
			indent.setAcceptableMake(
					Integer.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.ACCEPTABLE_MAKE)));

			// indent.setValue(itemsData.getPrice() * qtyReq);

			// stock available
			StockAvailable stock = stockAvailableRepository.findByItemId(indentDto.getItemId());

			if (stock == null)
				indent.setStockAvailable(0);
			else if (stock != null)
				indent.setStockAvailable(stock.getQuantityAvailable());

			// indent.setPoReceived(AssistConstantsParameters.PO_NOT_RECEIVED_FOR_INDENT);//
			// po not
			// received
			// yet

			indent.setPoQuantityRcvd(AssistConstantsParameters.NO_ITEMS_RECEIVED);

			indent.setIndentLoggedBy(currentUser.getCurrentUser().getUserId());

			if (indentDto.getLastpurchaseDetails().equals("NA")) {
				//System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$");
				
				indent.setLastPurchaseParticulars("Not avalable as there is no PO earlier for this item");

			}

			else
				indent.setLastPurchaseParticulars(indentDto.getLastpurchaseDetails());

			if (indentDto.getIndentType() == AssistConstantsParameters.INDENT_TYPE_RC)
				indent.setLikelySupplier(0);

			else if (indentDto.getIndentType() == AssistConstantsParameters.INDENT_TYPE_NORMAL) {

				//System.out.println("1111111111111");
				if (indentDto.getLikelySupplier() != 0) {
					//System.out.println("222222222222222222"+indentDto.getLikelySupplier());
					indent.setLikelySupplier(indentDto.getLikelySupplier());

				}

				else if (indentDto.getLikelySupplier() == 0) {
					Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "createdOn"));
					Pageable pageable = new PageRequest(0, 1, sort);

					List<IndentPoRelation> recentPo = indentPoRepository.findByItemId(itemsData.getItemId(), pageable)
							.getContent();
					//System.out.println(recentPo.size()+"+++++++++++++== size size");
					
					if (!recentPo.isEmpty()) {
						indent.setLikelySupplier((poDetailRepository
								.findByIndentPoReqId(recentPo.get(0).getId().getPoIndentNumber()).getSuppliedBy()));

						//System.out.println(indent.getLikelySupplier()+"   indent indent ");
						
				}
					}
			}

			if (indentDto.isArticleEnclosed())
				indent.setArticleEnclosed(AssistConstantsParameters.PROPRIETERY_ARTICLE_ENCLOSED);
			else if (!indentDto.isArticleEnclosed())
				indent.setArticleEnclosed(AssistConstantsParameters.PROPRIETERY_ARTICLE_NOT_ENCLOSED);

			/*if (indentDto.getControllingOfficer() == Integer
					.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_ADEN)))
				indent.setControllingOfficer(Integer
						.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_ADEN)));
			else if (indentDto.getControllingOfficer() == Integer
					.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_XEN)))
				indent.setControllingOfficer(Integer
						.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_XEN)));
*/
			
			indent.setControllingOfficer(indentDto.getControllingOfficer());
			
			// outstanding indents

			List<IndentDetail> outStandingAgainstIndents = indentDetailRepository.outStandingIndents(indentDto.getItemId());

			int outStandingItemsAvailable = 0;
			for (IndentDetail indentDetail : outStandingAgainstIndents) {

				outStandingItemsAvailable += indentDetail.getQuantityReq()-indentDetail.getPoQuantityRcvd();

			}

			indent.setOsaAgnstIndents(outStandingItemsAvailable);

			// Out Standing PO's

			List<IndentPoRelation> outStandingAgainstPo = indentPoRepository.getOutStandingPoDetails(indentDto.getItemId());
			/*
			 * List<IndentDetail> outStandingAgainstPo =
			 * indentDetailRepository.findByItemIdAndPoReceived(itemId,
			 * AssistConstantsParameters.PO_RECEIVED_FOR_INDENT);
			 */ // List<Map<String,
			// String>>
			// reportDetails;
			int quantityDue = 0;
			for (IndentPoRelation indentPoDetail : outStandingAgainstPo) {
				if (indentPoDetail.getQtyReceived() < indentPoDetail.getPoReceivedQuantity())
					quantityDue += indentPoDetail.getPoReceivedQuantity() - indentPoDetail.getQtyReceived();

			}

			indent.setOsaAgnstPo(quantityDue);

			// consumption of last three years started

			LocalDate today = LocalDate.now();
			
			int month = today.getMonthValue();

			SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");

			// consumption for year one

		//	int fromPastYear1 = 0;
		//	int toPastYear1 = 0;
			int currentFinancialYear=Integer.parseInt(indent.getFinancialYear().substring(0, 4));
			String dateFromPastYear1 = "1-Apr-"+(currentFinancialYear-1);
			String dateToPastYear1 = "31-Mar-"+currentFinancialYear;

			// for 2nd year
		//	int fromPastYear2 = 0;
		//	int fromToYear2 = 0;
			String dateFromPastYear2 = "1-Apr-"+(currentFinancialYear-2);
			String dateToPastYear2 = "31-Mar-"+(currentFinancialYear-1);

			// for year 3rd year

			//int fromPastYear3 = 0;
			//int fromToYear3 = 0;
			String dateFromPastYear3 = "1-Apr-"+(currentFinancialYear-3);
			String dateToPastYear3 = "31-Mar-"+(currentFinancialYear-2);
			
			
			
			

			/*if (month < 4) {
				fromPastYear1 = today.getYear() - 2;
				toPastYear1 = today.getYear() - 1;

				dateFromPastYear1 = "1-Apr-" + fromPastYear1;

				dateToPastYear1 = "31-Mar-" + toPastYear1;

				// for year 2

				fromPastYear2 = fromPastYear1 - 1;
				fromToYear2 = toPastYear1 - 1;

				dateFromPastYear2 = "1-Apr-" + fromPastYear2;

				dateToPastYear2 = "31-Mar-" + fromToYear2;

				// for year 3

				fromPastYear3 = fromPastYear2 - 1;
				fromToYear3 = fromToYear2 - 1;

				dateFromPastYear3 = "1-Apr-" + fromPastYear3;

				dateToPastYear3 = "31-Mar-" + fromToYear3;
			}

			else if (month >= 4 && month < 12) {

				fromPastYear1 = today.getYear() - 1;
				toPastYear1 = today.getYear();

				dateFromPastYear1 = "1-Apr-" + fromPastYear1;

				dateToPastYear1 = "31-Mar-" + toPastYear1;

				// for year 2

				fromPastYear2 = fromPastYear1 - 1;
				fromToYear2 = toPastYear1 - 1;

				dateFromPastYear2 = "1-Apr-" + fromPastYear2;

				dateToPastYear2 = "31-Mar-" + fromToYear2;

				// for year 3

				fromPastYear3 = fromPastYear2 - 1;
				fromToYear3 = fromToYear2 - 1;

				dateFromPastYear3 = "1-Apr-" + fromPastYear3;

				dateToPastYear3 = "31-Mar-" + fromToYear3;

			}*/

			System.out.println(dateFromPastYear1 +" - "+dateToPastYear1);
			System.out.println(dateFromPastYear2 +" - "+dateToPastYear2);

			System.out.println(dateFromPastYear3 +" - "+dateToPastYear3);

			List<MaterialsIssueRelation> materialConsumedYear1 = materialsIssueRelationRepository
					.findByItemIdAndDateIssueGreaterThanEqualAndDateIssueLessThanEqual(indentDto.getItemId(),
							formatter.parse(dateFromPastYear1), formatter.parse(dateToPastYear1));
			int materialsConsumedYear1 = 0;

			System.out.println("List size for "+dateFromPastYear1+" "+materialConsumedYear1.size());
			
			//if (materialConsumedYear1.isEmpty()) {
				System.out.println("inside if "+indentDto.getItemId());
				List<ChallanDetailsLoaded> challanInfoYear1 = challanDetailsLoadedRepository
						.findByIdnAndDateObjGreaterThanEqualAndDateObjLessThanEqual(
								String.valueOf(indentDto.getItemId()), formatter.parse(dateFromPastYear1),
								formatter.parse(dateToPastYear1));

				System.out.println("lost size "+challanInfoYear1.size());
				for (ChallanDetailsLoaded challanInfo : challanInfoYear1) {

					materialsConsumedYear1 += challanInfo.getQuantity();

				}

			//}

			for (MaterialsIssueRelation materialsIssueRelation : materialConsumedYear1) {

				materialsConsumedYear1 += materialsIssueRelation.getQtyIssued();

			}

			List<MaterialsIssueRelation> materialConsumedYear2 = materialsIssueRelationRepository
					.findByItemIdAndDateIssueGreaterThanEqualAndDateIssueLessThanEqual(indentDto.getItemId(),
							formatter.parse(dateFromPastYear2), formatter.parse(dateToPastYear2));

			int materialsConsumedYear2 = 0;

			//if (materialConsumedYear2.isEmpty()) {
			System.out.println("inside 2nd if loop "+indentDto.getItemId());
				List<ChallanDetailsLoaded> challanInfoYear2 = challanDetailsLoadedRepository
						.findByIdnAndDateObjGreaterThanEqualAndDateObjLessThanEqual(
								String.valueOf(indentDto.getItemId()), formatter.parse(dateFromPastYear2),
								formatter.parse(dateToPastYear2));
				System.out.println("inside if loop list size "+challanInfoYear2.size());
				for (ChallanDetailsLoaded challanInfo : challanInfoYear2) {

					materialsConsumedYear2 += challanInfo.getQuantity();

				}

			//}

			for (MaterialsIssueRelation materialsIssueRelation : materialConsumedYear2) {

				materialsConsumedYear2 += materialsIssueRelation.getQtyIssued();

			}

			List<MaterialsIssueRelation> materialConsumedYear3 = materialsIssueRelationRepository
					.findByItemIdAndDateIssueGreaterThanEqualAndDateIssueLessThanEqual(indentDto.getItemId(),
							formatter.parse(dateFromPastYear3), formatter.parse(dateToPastYear3));

			int materialsConsumedYear3 = 0;

			//if (materialConsumedYear3.isEmpty()) {

				List<ChallanDetailsLoaded> challanInfoYear3 = challanDetailsLoadedRepository
						.findByIdnAndDateObjGreaterThanEqualAndDateObjLessThanEqual(
								String.valueOf(indentDto.getItemId()), formatter.parse(dateFromPastYear3),
								formatter.parse(dateToPastYear3));

				for (ChallanDetailsLoaded challanInfo : challanInfoYear3) {

					materialsConsumedYear3 += challanInfo.getQuantity();

				}

			//}

			for (MaterialsIssueRelation materialsIssueRelation : materialConsumedYear3) {

				materialsConsumedYear3 += materialsIssueRelation.getQtyIssued();

			}
			
			String consumptionOfLastThreeYears = String.valueOf(materialsConsumedYear1) + "%%"
					+ String.valueOf(materialsConsumedYear2) + "%%" + String.valueOf(materialsConsumedYear3);

			System.out.println(consumptionOfLastThreeYears);

			indent.setConsmpLstThreeYrs(consumptionOfLastThreeYears);

			// consumption of last three years ended

			// outstanding indent Data started

			Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "createdOn"));
			Pageable pageable = new PageRequest(0, 4, sort);

			List<IndentDetail> outStandingIndentData = indentDetailRepository.outStandingIndentsData(indentDto.getItemId(),
					pageable);

			int i = 0;
			String outStandingData = null;
			for (IndentDetail indentDetail : outStandingIndentData) {

				if (i == 0) {
					outStandingData = String.valueOf(indentDetail.getIndentId());
				}

				if (i == 1) {
					outStandingData = outStandingData + "%%" + String.valueOf(indentDetail.getIndentId());

				}

				if (i == 2) {
					outStandingData = outStandingData + "%%" + String.valueOf(indentDetail.getIndentId());

				}
				if (i == 3) {
					outStandingData = outStandingData + "%%" + String.valueOf(indentDetail.getIndentId());
				}

				i++;
			}

			for (int j = i; j < 4; j++) {
				if (j == 0)
					outStandingData = "Nill";

				else
					outStandingData = outStandingData + "%%" + "Nill";

			}
			indent.setOsIndentData(outStandingData);

			// out standing agaings indent Data ended

			// out standing agnst PO Data started

			List<IndentPoRelation> outStandingAgainstPoData = indentPoRepository.outStandingPoData(indentDto.getItemId(),
					pageable);

			DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");

			dateFormatter.format(new Date());

			int j = 0;
			String outStandingDataPo = null;
			for (IndentPoRelation indentPo : outStandingAgainstPoData) {

				if (j == 0) {
					outStandingDataPo = indentPo.getPoNumber() + "%%" + dateFormatter.format(indentPo.getCreatedOn());

				}

				// && seperates pos
				// %% seperates po and its date
				if (j == 1) {
					outStandingDataPo = outStandingDataPo + "&&" + indentPo.getPoNumber() + "%%"
							+ dateFormatter.format(indentPo.getCreatedOn());

				}

				if (j == 2) {
					outStandingDataPo = outStandingDataPo + "&&" + indentPo.getPoNumber() + "%%"
							+ dateFormatter.format(indentPo.getCreatedOn());

				}
				if (j == 3) {
					outStandingDataPo = outStandingDataPo + "&&" + indentPo.getPoNumber() + "%%"
							+ dateFormatter.format(indentPo.getCreatedOn());
				}

				j++;
			}

			for (int k = j; k < 4; k++) {

				if (k == 0)
					outStandingDataPo = "Nill%%NA";

				else
					outStandingDataPo = outStandingDataPo + "&&" + "Nill%%NA";

			}
			indent.setOsPoData(outStandingDataPo);

			return indent;
		} catch (Exception e) {
			      
			e.printStackTrace();
			
			throw e;
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.rail.assist.service.IndentService#getIndentDataToPrint(com.rail.
	 * assist.entities.IndentDetail)
	 */
	@Override
	public Map<String, Object> getIndentDataToPrint(IndentDetail indentData) throws Exception {

		try {
			Map<String, Object> model = new HashMap<>();

			model.put("indentor", indentorRepository.findByIndentorId((int) indentData.getIndentor()).getIndentorDesc());
			Consignee consignee = consigneeRepository.findById((int) indentData.getConsignee());
			model.put("consigneeCode", Integer.toString(consignee.getConsigneeId()));
			model.put("consigneeNo", consignee.getConsigneeDesc());
			model.put("requiredAt",
					materialsRequiredAtRepository.findById((int) indentData.getMaterialsRequiredAt()).getLocationDesc());
			model.put("depot", depotRepository.findByDepotId(indentData.getDepot()).getDepotDesc());
			model.put("description", indentData.getDescription());
			model.put("nomenclatureNo", "NA");
			model.put("units", indentData.getUnits());
			DateFormat formatter = new SimpleDateFormat("dd/MMM/yyyy");

			model.put("date", formatter.format(indentData.getDate()));

			if (indentData.getIndentType() == AssistConstantsParameters.INDENT_TYPE_RC)
				model.put("requesitionNo", "RC " + String.valueOf(indentData.getIndentId()));
			else if (indentData.getIndentType() == AssistConstantsParameters.INDENT_TYPE_NORMAL)
				model.put("requesitionNo", String.valueOf(indentData.getIndentId()));

			model.put("demandedInFig", Long.toString(indentData.getQuantityReq()));

			model.put("demandedWords", NumberToText.NumberToTextFormat(indentData.getQuantityReq()));

			//System.out.println(NumberToText.NumberToTextFormat(indentData.getQuantityReq()) + "==========");

			model.put("allocation", indentData.getAllocation());
			model.put("rate", Double.toString(indentData.getRate()));
			//System.out.println("Value is "+indentData.getValue());
			model.put("value", String.format("%.2f",indentData.getValue())  );
			model.put("rateInWords", NumberToText.NumberToTextFormat((long) indentData.getRate()));
			model.put("purpose", indentData.getPurpose());
			// for point 1 in indent form
			//System.out.println(indentData.getItemId());

			model.put("stockAvailable", indentData.getStockAvailable());

			model.put("outStandingQtyAgainstIndents", indentData.getOsaAgnstIndents());

			// for point 3

			model.put("quantityDueForPo", indentData.getOsaAgnstPo());

			String[] consumption = indentData.getConsmpLstThreeYrs().split("%%");

			model.put("consumptionYear1", Integer.valueOf(consumption[0])); // point
																			// 4.1

			model.put("consumptionYear2", Integer.valueOf(consumption[1])); // point
																			// 4.2

			model.put("consumptionYear3", Integer.valueOf(consumption[2])); // point
																			// 4.3

			model.put("idNo", String.valueOf(indentData.getItemId())+" "+itemsDataRepository.findByItemId(indentData.getItemId()).getType());

			// for point 5

			String[] osIndentData = indentData.getOsIndentData().split("%%");

			int i = 1;
			for (String string : osIndentData) {
				if (i == 1)
					model.put("outStandingIndents1", string);
				if (i == 2)
					model.put("outStandingIndents2", string);
				if (i == 3)
					model.put("outStandingIndents3", string);
				if (i == 4)
					model.put("outStandingIndents4", string);

				i++;
			}

			if (i < 4) {
				for (long m = i; m <= 4; m++) {
					model.put("outStandingIndents" + m, "NIL");
				}
			}

			// for point 6

			String[] osPoData = indentData.getOsPoData().split("&&");

			int j = 1;
			for (String string : osPoData) {

				if (j == 1) {

					String[] osPoData1 = string.split("%%");

					model.put("outStandingPo1", osPoData1[0] + " " + osPoData1[1]);

				} else if (j == 2) {

					String[] osPoData2 = string.split("%%");

					model.put("outStandingPo2", osPoData2[0] + " " + osPoData2[1]);

				} else if (j == 3) {

					String[] osPoData3 = string.split("%%");

					model.put("outStandingPo3", osPoData3[0] + " " + osPoData3[1]);

				} else if (j == 4) {

					String[] osPoData4 = string.split("%%");

					model.put("outStandingPo4", osPoData4[0] + " " + osPoData4[1]);

				}

				j++;

			}

			if (j < 4) {
				for (long m = j; m <= 4; m++) {
					model.put("outStandingPo" + m, "NIL");
				}
			}

			// for point 7 for RC Indent
			/*
			 * if (indentData.getIndentType() ==
			 * AssistConstantsParameters.INDENT_TYPE_RC) model.put("likelySupplier",
			 * assistConstants.getParameterValue(AssistConstantsParameters.
			 * LIKELY_SUPPLIER_RC_INDENT));
			 * 
			 * else if (indentData.getIndentType() ==
			 * AssistConstantsParameters.INDENT_TYPE_NORMAL) {
			 * 
			 * Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC,
			 * "createdOn")); Pageable pageable = new PageRequest(0, 1, sort);
			 * 
			 * List<IndentPoRelation> indentDataList =
			 * indentPoRepository.findByItemId(indentData.getItemId(), pageable)
			 * .getContent(); if (indentDataList.size() != 0) { System.out.println(
			 * poDetailRepository.findByPoNumber(indentDataList.get(0).getPoNumber()
			 * ).getSuppliedBy() + "by"); System.out.println(vendorsDataRepository
			 * .findById(
			 * poDetailRepository.findByPoNumber(indentDataList.get(0).getPoNumber()
			 * ).getSuppliedBy()) .getId());
			 * 
			 * PurchaseOrderDetail poData =
			 * poDetailRepository.findByPoNumber(indentDataList.get(0).getPoNumber()
			 * );
			 * 
			 * model.put("likelySupplier", poData.getPoNumber() + " " + "Dt" + " " +
			 * formatter.format(poData.getDate()));
			 * 
			 * } else { model.put("likelySupplier", "N/A");
			 * 
			 * } }
			 */

			VendorsData vendorData = vendorsDataRepository.findById(indentData.getLikelySupplier());

			model.put("likelySupplier", vendorData.getSupplierDesc() + " " + vendorData.getCity());

			model.put("lastPurchaseParticulars", indentData.getLastPurchaseParticulars());

			// point 8
			if (indentData.getArticleEnclosed() == AssistConstantsParameters.PROPRIETERY_ARTICLE_ENCLOSED)
				model.put("propritaryArticle", "-YES-");
			else if (indentData.getArticleEnclosed() == AssistConstantsParameters.PROPRIETERY_ARTICLE_NOT_ENCLOSED)
				model.put("propritaryArticle", "-NO-");

			// point 9
			model.put("reasonsForurgentPurchase", "NIL");

			// point 10

			model.put("fundsAvailable", Double.toString(indentData.getRate()));

			// int currentYear = cal.get(Calendar.YEAR);

			//LocalDate today = LocalDate.now();
			//int month = today.getMonthValue();

			/*if (month < 4)
				model.put("fundsAvailableYear",
						String.valueOf(today.getYear() - 2) + "-" + String.valueOf(today.getYear() - 1));
			else
				model.put("fundsAvailableYear",
						String.valueOf(today.getYear() - 1) + "-" + String.valueOf(today.getYear()));*/
			
			model.put("fundsAvailableYear", indentData.getFinancialYear());

			model.put("indentingOfficer", assistConstants.getParameterValue(AssistConstantsParameters.INDENTING_OFFICER));

			/*if (indentData.getControllingOfficer() == 1)
				model.put("controllingOfficer",
						assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_ADEN_DESC));

			else if (indentData.getControllingOfficer() == 2)
				model.put("controllingOfficer",
						assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_XEN_DESC));
*/
			model.put("controllingOfficer", indentData.getControllingOfficer());
			model.put("approvingOfficer", assistConstants.getParameterValue(AssistConstantsParameters.APPROVING_OFFICER));
			
			
			// for image path
			
			model.put("imageLocation", assistConstants.getParameterValue(AssistConstantsParameters.INDENT_REPORT_IMAGE_PATH));
			
			return model;
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}

	}

}
