package com.rail.assist.dto;

import java.util.Date;

public class IndentTableDto {
	
	private long indentId;
	
	private long itemId;
	
	private int numberOfItems;
	
	private double price;
	
	private Date date;

	public long getIndentId() {
		return indentId;
	}

	public long getItemId() {
		return itemId;
	}

	public int getNumberOfItems() {
		return numberOfItems;
	}

	public double getPrice() {
		return price;
	}

	public Date getDate() {
		return date;
	}

	public void setIndentId(long indentId) {
		this.indentId = indentId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	
	
	
	

}
