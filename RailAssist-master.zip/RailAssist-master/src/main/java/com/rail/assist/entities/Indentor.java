package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the category database table.
 * 
 */
@Entity
@Table(name="indentor")
@NamedQuery(name="Indentor.findAll", query="SELECT c FROM Indentor c")
public class Indentor implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private int id;

	@Column(name="INDENTOR_ID")
	private int indentorId;

	@Column(name="INDENTOR_DESC")
	private String indentorDesc;
	
	@Column(name="LAST_UPDATE")
	private Date lastUpdate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIndentorId() {
		return indentorId;
	}

	public void setIndentorId(int indentorId) {
		this.indentorId = indentorId;
	}

	public String getIndentorDesc() {
		return indentorDesc;
	}

	public void setIndentorDesc(String indentorDesc) {
		this.indentorDesc = indentorDesc;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}


}