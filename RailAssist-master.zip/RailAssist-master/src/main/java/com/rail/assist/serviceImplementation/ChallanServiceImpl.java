package com.rail.assist.serviceImplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rail.assist.config.CurrentUser;
import com.rail.assist.constants.AssistConstants;
import com.rail.assist.constants.AssistConstantsParameters;
import com.rail.assist.dto.ItemsIssuedDtoHome;
import com.rail.assist.entities.MaterialIssueData;
import com.rail.assist.entities.UserDetail;
import com.rail.assist.repository.IndentDetailRepository;
import com.rail.assist.repository.IndentPoRepository;
import com.rail.assist.repository.MaterialsIssueDataRepository;
import com.rail.assist.repository.MaterialsIssueRelationRepository;
import com.rail.assist.repository.PoDetailRepository;
import com.rail.assist.repository.StockAvailableRepository;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.service.ChallanService;

@Service
public class ChallanServiceImpl implements ChallanService {

	@Autowired
	CurrentUser currentUser;

	@Autowired
	IndentDetailRepository indentDetailRepository;

	@Autowired
	PoDetailRepository poDetailRepository;

	@Autowired
	IndentPoRepository indentPoRepository;

	@Autowired
	MaterialsIssueDataRepository materialsIssueDataRepository;

	@Autowired
	MaterialsIssueRelationRepository materialsIssueRelationRepository;

	@Autowired
	UserDetailsRepository userDetailsRepository;

	@Autowired
	private AssistConstants assistConstants;

	@Override
	// @Transactional(rollbackFor=Throwable.class)
	public ItemsIssuedDtoHome getChallanData(int id) throws NumberFormatException, Exception {
		ItemsIssuedDtoHome itemsData = new ItemsIssuedDtoHome();

		try {
			MaterialIssueData materialData = materialsIssueDataRepository.findByMaterialIssueId(id);

			itemsData = getChallanData(materialData);
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}

		return itemsData;

	}

	@Override
	// @Transactional(rollbackFor=Throwable.class)
	public ItemsIssuedDtoHome getChallanInfo(String uniqueId) throws NumberFormatException, Exception {

		try {
			ItemsIssuedDtoHome itemsData = new ItemsIssuedDtoHome();

			MaterialIssueData materialData = materialsIssueDataRepository.findByChallanNumber(uniqueId);

			if (materialData != null) {
				itemsData = getChallanData(materialData);
				itemsData.setChallanFound(true);
				return itemsData;
			} else {

				itemsData.setChallanFound(false);
				return itemsData;

			}
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}

	}

	// @Transactional(rollbackFor=Throwable.class)
	private ItemsIssuedDtoHome getChallanData(MaterialIssueData materialData) throws NumberFormatException, Exception {

		ItemsIssuedDtoHome itemsData = new ItemsIssuedDtoHome();
		try {
			

			itemsData.setId(materialData.getMaterialIssueId());
			itemsData.setIssuedToPerson(materialData.getMaterialIssueToPerson());
			itemsData.setChallanNumber(materialData.getChallanNumber());
			itemsData.setNoOfItems(materialData.getTotalNoOfItemsIssued());
			itemsData.setDate(materialData.getDateIssue());

			if (materialData.getMaterialIssuedBy() == Integer
					.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_I_RYP)))
				itemsData.setIssuedFrom(
						assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_I_RYP_DESC));

			if (materialData.getMaterialIssuedBy() == Integer
					.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_II_RYP)))
				itemsData.setIssuedFrom(
						assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_II_RYP_DESC));

			itemsData.setIssuedTo(materialData.getMaterialIssueTo());
			UserDetail user = userDetailsRepository.findByUserId(materialData.getCreatedBy());
			itemsData.setLoggedBy(user.getUserFirstName() + " " + user.getUserLastName());

			itemsData.setUniqueRelationNo(materialData.getUniqueRelationNo());
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}
		return itemsData;

	}

}
