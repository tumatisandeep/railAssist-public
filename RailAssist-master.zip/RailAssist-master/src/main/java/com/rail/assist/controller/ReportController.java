package com.rail.assist.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.jasperreports.JasperReportsPdfView;

@Controller
public class ReportController {

	
	@Autowired
	ApplicationContext applicationContext;
	
	/*@RequestMapping(value = "/generateReport", method = RequestMethod.POST)
	ModelAndView generateIndentForm() {

		Map<String, Object> model = new HashMap<>();

		List<Map<String, String>> reportDetails;

		//model.put("format", "xlsx");
		 model.put("format", "html");

		//model.put("format", "pdf");
		return new ModelAndView("indentReport", model);
	}*/
	
	
	@RequestMapping(value = "/generateReport", method = RequestMethod.POST)
	ModelAndView generateIndentForm1() {

		
		JasperReportsPdfView view =new JasperReportsPdfView();
		view.setUrl("classpath:jasper/indent.jrxml");
		view.setApplicationContext(applicationContext);
		Map<String, Object> model = new HashMap<>();

		//List<Map<String, String>> reportDetails;

		//model.put("format", "xlsx");
		 model.put("format", "html");

		//model.put("format", "pdf");
		return new ModelAndView(view, model);
	}
}
