package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.MaterialsRequiredAt;


public interface MaterialsRequiredAtRepository extends JpaRepository<MaterialsRequiredAt,Integer> {
	
	MaterialsRequiredAt findByLocationId(int id);
	
	MaterialsRequiredAt findById(int id);

	
}



