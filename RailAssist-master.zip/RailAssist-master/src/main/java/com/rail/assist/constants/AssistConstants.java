package com.rail.assist.constants;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.rail.assist.entities.AssistConstantsDef;
import com.rail.assist.repository.AssistConstantsDefRepository;

@Component
public class AssistConstants {
	
	public final static Map<String, String> assistProperties = new HashMap<String, String>();
	
	
	
	@Autowired
	private AssistConstantsDefRepository assistConstantsDefRepository;
	
	
	@PostConstruct
	public void populateAssistPropertyValues() {

		try {
			List<AssistConstantsDef> acdConstantsData = assistConstantsDefRepository.findAll();

			if (acdConstantsData == null || acdConstantsData.isEmpty()) {
				System.out.println("Looks like ACD_DATA table is empty");
			}

			for (AssistConstantsDef acdConstants : acdConstantsData) {

				assistProperties.put(acdConstants.getConstantKey().trim(), acdConstants.getConstantValue());
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		System.out.println("Application is up and running !!");
		
	}

	
	
	public  String getParameterValue( String parameterKey) throws Exception {
	//For Admin only	
		
		String result = assistProperties.get(parameterKey.trim()); 

		//System.out.println(result);
		
		if(result == null)
			throw new RuntimeException("Key "+parameterKey+" is not found");
		else
			return result; 
	
}
	
}