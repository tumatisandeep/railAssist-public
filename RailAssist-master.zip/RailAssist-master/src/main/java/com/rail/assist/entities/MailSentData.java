package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the category database table.
 * 
 */
@Entity
@Table(name = "MAIL_SENT_DATA")
@NamedQuery(name = "MailSentData.findAll", query = "SELECT c FROM MailSentData c")
public class MailSentData implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
	private int id;

	@Column(name = "MAIL_SENT")
	private int isMailSent;

	@Column(name = "DATE")
	private String date;

	@Column(name = "SENT_TIME")
	private Date sentTime;

	@Column(name = "SUCCESS_MESSAGE")
	private String successMessage; // success in case of mail sent

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIsMailSent() {
		return isMailSent;
	}

	public void setIsMailSent(int isMailSent) {
		this.isMailSent = isMailSent;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Date getSentTime() {
		return sentTime;
	}

	public void setSentTime(Date sentTime) {
		this.sentTime = sentTime;
	}

	
	
	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}