package com.rail.assist.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.rail.assist.config.CurrentUser;
import com.rail.assist.dto.PoDtoHome;
import com.rail.assist.entities.PurchaseOrderDetail;
import com.rail.assist.entities.VendorsData;
import com.rail.assist.repository.IndentDetailRepository;
import com.rail.assist.repository.IndentPoRepository;
import com.rail.assist.repository.ItemsDataRepository;
import com.rail.assist.repository.PoDetailRepository;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.repository.VendorsDataRepository;
import com.rail.assist.service.PoService;

@Controller
public class PoController {

	@Autowired
	CurrentUser currentUser;

	@Autowired
	IndentDetailRepository indentDetailRepository;

	@Autowired
	PoDetailRepository poDetailRepository;

	@Autowired
	IndentPoRepository indentPoRepository;

	@Autowired
	ItemsDataRepository itemsDataRepository;

	@Autowired
	VendorsDataRepository vendorsDataRepository;

	@Autowired
	UserDetailsRepository userDetailsRepository;

	@Autowired
	PoService poService;

	@RequestMapping(value = "/poForm", method = RequestMethod.GET)
	public String displayIndentForm(Model model) throws Exception {

		try {
			List<VendorsData> vendors = vendorsDataRepository.findAll();

			model.addAttribute("vendors", vendors);
//throw new ArithmeticException();
			
			
			return "poForm";
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}
	}

	@RequestMapping(value = "/submitPoForm", method = RequestMethod.POST)
	public @ResponseBody String submitPoForm(@RequestBody String json, RedirectAttributes redirectAttributes)
			throws Exception {

		String returnString = null;
		JSONArray poFormData = new JSONArray(json);
		
		boolean poAdded;

		try {

			PurchaseOrderDetail poDetail = poDetailRepository.findByPoNumber(poFormData.getString(0));
			
			PurchaseOrderDetail poDataWithSerialNumber = poDetailRepository.findBySerialNumber(Integer.valueOf(poFormData.getString(3)));

			
			
			
			
			
			
			//PurchaseOrderDetail poDetailWithSerialNumber=poDetailRepository.findBy

			if (poDetail == null  ) {
				
				if(poDataWithSerialNumber!=null) {
					returnString="duplicateSerialNo";

				}

				else {
				poAdded = poService.addPo(poFormData);

				if (!poAdded)
					returnString = "exception";
				else
					returnString = "success";

			}
			}
			else {
				//redirectAttributes.addFlashAttribute("poPresent", true);
				//redirectAttributes.addFlashAttribute("poNumber", poFormData.getString(0));

				returnString = "failure";
			}

		} catch (Exception e) {
			returnString = "exception";
			e.printStackTrace();
		}

		//System.out.println(returnString + "return string");
		Map<String, String> response = new HashMap<>();

		response.put("response", returnString);
		response.put("serialNumber", poFormData.getString(3));
		response.put("poNumber", poFormData.getString(0));

		String responseJson = new Gson().toJson(response);

	//	System.out.println(responseJson + " ---- response Json--");
		return responseJson;

	}

	@RequestMapping("/showPoDetails/{serialNo}")
	public String showPo(@PathVariable long serialNo, Model model) {

		//System.out.println(serialNo + "-----------------");
		PoDtoHome poDto = new PoDtoHome();

		try {
			poDto = poService.showPo(serialNo);
			model.addAttribute("poDto", poDto);
		} catch (Exception e) {
			      
			e.printStackTrace();
		}

		

		return "viewPoDetails";

	}

	@RequestMapping(value = "/returnToHomeFromPo", method = { RequestMethod.GET, RequestMethod.POST })
	public String returnToHomeFromPo(@RequestParam(value = "response", required = false) String response, RedirectAttributes model)
			throws JSONException {

		//System.out.println(response);

		JSONObject json = new JSONObject(response);

	//	System.out.println(json.getString("response") + " ------ " + json.getString("poNumber"));

		model.addFlashAttribute("poAdded", json.getString("response"));
		model.addFlashAttribute("poNumber", json.getString("poNumber"));
		model.addFlashAttribute("serialNumber", json.getString("serialNumber"));

		return "redirect:/home";
	}

}
