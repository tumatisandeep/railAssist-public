package com.rail.assist.dto;

import java.util.Date;
import java.util.List;

public class PoDtoHome {


	long numberOfIndents;

	String poNo;

	String desc;

	long serialNo;

	Date date;

	String supliedBy;

	String title;
	
	String createdBy;
	
	List<IndentDataInfoDto> indentsList;
	
	Date dueDate;
	
	String loggedBy;
	
	String tendorNumber;
	
	int totalQtyToBeReceived;
	
	boolean poFound;
	
	String tenderType;	
	
	Date loggedDate;
	
	
	
	
	public String getTenderType() {
		return tenderType;
	}

	public void setLoggedBy(String loggedBy) {
		this.loggedBy = loggedBy;
	}

	public void setTenderType(String tenderType) {
		this.tenderType = tenderType;
	}

	public boolean isPoFound() {
		return poFound;
	}

	public void setPoFound(boolean poFound) {
		this.poFound = poFound;
	}

	public int getTotalQtyToBeReceived() {
		return totalQtyToBeReceived;
	}

	public void setTotalQtyToBeReceived(int totalQtyToBeReceived) {
		this.totalQtyToBeReceived = totalQtyToBeReceived;
	}

	public String getLoggedBy() {
		return loggedBy;
	}

	

	public String getTendorNumber() {
		return tendorNumber;
	}

	public void setTendorNumber(String tendorNumber) {
		this.tendorNumber = tendorNumber;
	}

	public List<IndentDataInfoDto> getIndentsList() {
		return indentsList;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setIndentsList(List<IndentDataInfoDto> indentsList) {
		this.indentsList = indentsList;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String string) {
		this.createdBy = string;
	}

	public long getNumberOfIndents() {
		return numberOfIndents;
	}

	public String getPoNo() {
		return poNo;
	}

	public String getDesc() {
		return desc;
	}

	public long getSerialNo() {
		return serialNo;
	}

	public Date getDate() {
		return date;
	}

	public String getSupliedBy() {
		return supliedBy;
	}

	public String getTitle() {
		return title;
	}

	public void setNumberOfIndents(long numberOfIndents) {
		this.numberOfIndents = numberOfIndents;
	}

	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public void setSerialNo(long l) {
		this.serialNo = l;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setSupliedBy(String supliedBy) {
		this.supliedBy = supliedBy;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getLoggedDate() {
		return loggedDate;
	}

	public void setLoggedDate(Date loggedDate) {
		this.loggedDate = loggedDate;
	}


}
