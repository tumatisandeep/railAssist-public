/**
 * 
 */
package com.rail.assist.dto;

import java.util.Date;

/**
 * @author Mahideep Tumati
 *
 * Created on Jul 2, 2018
 */
public class ItemsDeliveryDueDto {
	
	private long itemId;
	
	private Date dueDate;
	
	private String poNUmber;
	
	private String vendor;
	
	private long indentId;
	
	private String itemCategory;

	private String dueDateString;
	
	
	
	public String getDueDateString() {
		return dueDateString;
	}

	public void setDueDateString(String dueDateString) {
		this.dueDateString = dueDateString;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getPoNUmber() {
		return poNUmber;
	}

	public void setPoNUmber(String poNUmber) {
		this.poNUmber = poNUmber;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public long getIndentId() {
		return indentId;
	}

	public void setIndentId(long indentId) {
		this.indentId = indentId;
	}

	public String getItemCategory() {
		return itemCategory;
	}

	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}
	
	
	

}
