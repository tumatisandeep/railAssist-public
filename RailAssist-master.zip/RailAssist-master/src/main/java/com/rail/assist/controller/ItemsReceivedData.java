package com.rail.assist.controller;

import java.util.Date;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rail.assist.config.CurrentUser;
import com.rail.assist.entities.MaterialsReceivedData;
import com.rail.assist.repository.IndentPoRepository;
import com.rail.assist.repository.MaterialsReceivedDataRepository;
import com.rail.assist.repository.StockAvailableRepository;
import com.rail.assist.service.ItemsReceivedService;

/**
 * @author Mahideep Tumati
 *
 * Created on May 21, 2018
 */
@Controller
public class ItemsReceivedData {

	@Autowired
	MaterialsReceivedDataRepository materialsReceivedDataRepository;

	@Autowired
	CurrentUser currentUser;

	@Autowired
	StockAvailableRepository stockAvailableRepository;

	@Autowired
	IndentPoRepository indentPoRepository;

	@Autowired
	ItemsReceivedService itemsReceivedService;

	@RequestMapping(value = "/itemsReceivedDetails", method = RequestMethod.GET)
	public String itemsDataSpent(Model model) throws Exception {

		return "itemsReceivedDetails";
	}

	
	@RequestMapping(value = "/submitItemReceivedData", method = RequestMethod.POST, consumes = MediaType.ALL_VALUE)
	public @ResponseBody void submitItemReceivedData(@RequestBody String json, RedirectAttributes redirectAttributes)
			throws Exception {
		//System.out.println(json);

		//JSONArray itemsRcvd = new JSONArray(json);

		//System.out.println(itemsRcvd.getInt(0));

		//System.out.println(itemsRcvd.getInt(1));

		//System.out.println(itemsRcvd.getString(2));

		//System.out.println(itemsRcvd.getString(3));

	}
    

	@RequestMapping(value = "/addItemsReceivedData", method = RequestMethod.POST)
	public String submitItemReceivedData(@RequestParam("itemId") long itemId,
			@RequestParam("quantityReceived") int quantityReceived,
			@RequestParam("dateReceived") @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateReceived,
			@RequestParam("poID") String poIndentNumber, RedirectAttributes redirectAttributes) throws Exception {

		boolean itemAddded = false;

		
		
		try {
		
			
			
			
		//	System.out.println(itemId + "---" + quantityReceived + "---" + dateReceived + "--" + poIndentNumber);

			itemAddded = itemsReceivedService.addItemsReceivedData(itemId, quantityReceived, dateReceived, poIndentNumber);

		} catch (Exception e) {
			e.printStackTrace();
			itemAddded = false;
		}

		if (itemAddded) {
			redirectAttributes.addFlashAttribute("itemId", itemId);
			redirectAttributes.addFlashAttribute("itemIdRcvdDataUpdated", true);
		} else if (!itemAddded) {
			redirectAttributes.addFlashAttribute("itemId", itemId);
		redirectAttributes.addFlashAttribute("itemIdRcvdDataUpdated", false);
		}
		return "redirect:/home";

	}

	@RequestMapping("/showReceivedDetails/{id}")
	public String showPo(@PathVariable long id, Model model) {

		//System.out.println(id + "-----------------");

		MaterialsReceivedData itemsRcvdData = itemsReceivedService.getItemReceivedDetails(id);

		model.addAttribute("itemsRcvdData", itemsRcvdData);

		return "viewItemsRcvdDetails";

	}

}
