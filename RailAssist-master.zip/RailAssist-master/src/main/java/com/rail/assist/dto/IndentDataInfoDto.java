package com.rail.assist.dto;

import java.util.Date;

public class IndentDataInfoDto {


	
	private long indentId;

	private long quantity;

	private Date indentDate;
	
	private boolean isPoReceived;
	
	private String description;
	
	private String partNo;
	
	private double price;
	
	private long itemId;
	
	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	private String itemType;
	
	private Date dueDate;
	
	
	
	
	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getPartNo() {
		return partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public long getIndentId() {
		return indentId;
	}

	public long getQuantity() {
		return quantity;
	}

	public Date getIndentDate() {
		return indentDate;
	}

	public boolean isPoReceived() {
		return isPoReceived;
	}

	public String getDescription() {
		return description;
	}

	public void setIndentId(long indentId) {
		this.indentId = indentId;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public void setIndentDate(Date indentDate) {
		this.indentDate = indentDate;
	}

	public void setPoReceived(boolean isPoReceived) {
		this.isPoReceived = isPoReceived;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
}
