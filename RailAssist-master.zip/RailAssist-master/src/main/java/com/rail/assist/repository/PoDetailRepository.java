package com.rail.assist.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rail.assist.entities.PurchaseOrderDetail;

/**
 * @author Mahideep Tumati
 *
 * Created on Jun 21, 2018
 */
public interface PoDetailRepository extends JpaRepository<PurchaseOrderDetail, Integer> {

	PurchaseOrderDetail findByPoNumber(String poNumber);

	PurchaseOrderDetail findByIndentPoReqId(long id);

	PurchaseOrderDetail findBySerialNumber(long serialNo);

	@Query("from PurchaseOrderDetail po where trunc(po.createdOn)=TO_DATE(?1,'dd-MM-yyyy')")
	List<PurchaseOrderDetail> findByCreatedOnFunction(String date);

	List<PurchaseOrderDetail> findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(Date todayDateObj,
			Date nextDayDateObj);
	
	
	long countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(Date date,
			Date date1);
	
	
	List<PurchaseOrderDetail> findByCreatedByAndCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(int id,Date date1,
			Date date2);
	
	
	List<PurchaseOrderDetail> findByCreatedBy(int id);
	
	//PurchaseOrderDetail findByIdSerialNumber(int serialNum);
	
	
}
