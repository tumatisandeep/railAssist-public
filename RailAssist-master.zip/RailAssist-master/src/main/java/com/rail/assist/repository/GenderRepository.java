package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.Gender;


public interface GenderRepository extends JpaRepository<Gender,Long> {
	

	Gender findByGenderId(int id);
	
}



