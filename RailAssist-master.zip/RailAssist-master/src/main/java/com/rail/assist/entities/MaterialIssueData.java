package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the material_issue database table.
 * 
 */
@Entity
@Table(name="material_issue_data")
@NamedQuery(name="MaterialIssueData.findAll", query="SELECT m FROM MaterialIssueData m")
public class MaterialIssueData implements Serializable {
	private static final long serialVersionUID = 1L;

	
	@Id
	@Column(name="MATERIAL_ISSUE_ID")
	private long materialIssueId;

	@Column(name="CHALLAN_NUMBER")
	private String challanNumber;
	
	@Column(name="MATERIAL_ISSUE_TO")
	private String materialIssueTo;
	
	@Column(name="MATERIAL_ISSUE_TO_PERSON")
	private String materialIssueToPerson;
	
	@Column(name="MATERIAL_ISSUED_BY")
	private int materialIssuedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATE_ISSUE")
	private Date dateIssue;
	

	@Column(name="NO_OF_ITEMS_ISSUED")
	private int totalNoOfItemsIssued;
	
	
	@Column(name="UNIQUE_RELATION_NUMBER")
	private Long uniqueRelationNo;
	
	private String comments;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_ON")
	private Date createdOn;
	
	@Column(name="CREATED_BY")
	private long createdBy;
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_UPDATE")
	private Date lastUpdate;
	

	public Date getCreatedOn() {
		return createdOn;
	}


	public long getCreatedBy() {
		return createdBy;
	}


	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}


	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}


	public MaterialIssueData() {
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public long getMaterialIssueId() {
		return materialIssueId;
	}


	

	public String getMaterialIssueTo() {
		return materialIssueTo;
	}


	public int getMaterialIssuedBy() {
		return materialIssuedBy;
	}


	public Date getDateIssue() {
		return dateIssue;
	}


	public int getTotalNoOfItemsIssued() {
		return totalNoOfItemsIssued;
	}




	public String getComments() {
		return comments;
	}


	public void setMaterialIssueId(long materialIssueId) {
		this.materialIssueId = materialIssueId;
	}


	public void setMaterialIssueTo(String materialIssueTo) {
		this.materialIssueTo = materialIssueTo;
	}


	public void setMaterialIssuedBy(int materialIssuedBy) {
		this.materialIssuedBy = materialIssuedBy;
	}


	public void setDateIssue(Date dateIssue) {
		this.dateIssue = dateIssue;
	}


	public void setTotalNoOfItemsIssued(int totalNoOfItemsIssued) {
		this.totalNoOfItemsIssued = totalNoOfItemsIssued;
	}


	

	public void setComments(String comments) {
		this.comments = comments;
	}


	public String getChallanNumber() {
		return challanNumber;
	}


	public long getUniqueRelationNo() {
		return uniqueRelationNo;
	}


	public void setChallanNumber(String challanNumber) {
		this.challanNumber = challanNumber;
	}


	public void setUniqueRelationNo(Long long1) {
		this.uniqueRelationNo = long1;
	}


	public Date getLastUpdate() {
		return lastUpdate;
	}


	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	
	@PrePersist
	void createdAt() {
		this.createdOn = new Date();
		this.lastUpdate = new Date();

	}

	@PreUpdate
	void updatedAt() {
		this.lastUpdate = new Date();
	}

	

	public String getMaterialIssueToPerson() {
		return materialIssueToPerson;
	}


	public void setMaterialIssueToPerson(String materialIssueToPerson) {
		this.materialIssueToPerson = materialIssueToPerson;
	}


	@Override
	public String toString() {
		return "MaterialIssueData [materialIssueId=" + materialIssueId + ", challanNumber=" + challanNumber
				+ ", materialIssueTo=" + materialIssueTo + ", materialIssuedBy=" + materialIssuedBy + ", dateIssue="
				+ dateIssue + ", totalNoOfItemsIssued=" + totalNoOfItemsIssued + ", uniqueRelationNo="
				+ uniqueRelationNo + ", comments=" + comments + ", createdOn=" + createdOn + ", createdBy=" + createdBy
				+ ", lastUpdate=" + lastUpdate + "]";
	}
	
	
	
	
	
}