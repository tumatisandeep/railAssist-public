package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;


/**
 * The persistent class for the indent_details database table.
 * 
 */
@Entity
@Table(name="indent_details")

@NamedQuery(name="IndentDetail.findAll", query="SELECT i FROM IndentDetail i")
public class IndentDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	

	@Id
	private int id;
	
	
	@Column(name="ACCEPTABLE_MAKE")
	private int acceptableMake;

	private String allocation;

	private double rate;
	
	private long consignee;

	@Temporal(TemporalType.TIMESTAMP)
	private Date date;

	private int depot;


	@Column(name="INDENT_ID")
	private long indentId;

	private int indentor;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_UPDATE")
	private Date lastUpdate;

	@Column(name="MATERIALS_REQUIRED_AT")
	private int materialsRequiredAt;

	
	@Column(name="INDENT_LOGGED_BY")
	private long indentLoggedBy;
	
	
	@Column(name="QUANTITY_RECEIVED")
	private long poQuantityRcvd;  // the quantity in this indent for which po is received
	
	@Column(name="LIKELY_SUPPLIER")
	private long likelySupplier;
	
	private String purpose;

	@Column(name="QUANTITY_REQ")
	private long quantityReq;

	private String units;

	private double value;

	/*@Column(name="PO_RECEIVED")
	private long poReceived;*/
	
	@Column(name="PO_DATE")
	private Date poDate;
	
	@Column(name="PO_NUMBER")
	private String poNumber;
	
	
	@Column(name="ITEM_ID")
	private long itemId;
	
	@Column(name="INDENT_TYPE")
	private int indentType;
	
	@Column(name="DESCRIPTION")
	private String description;
	
	@Column(name="SERIAL_NUMBER")
	private long serialNumber;
	
	@Column(name="ARTICLE_ENCLOSED")
	private int articleEnclosed;
	
	

	@Column(name="CONTROLLING_OFFICER")
	private String controllingOfficer;
	

	@Column(name="STOCK_AVAILABLE")
	private long stockAvailable;
	
	@Column(name="OSA_INDENTS")
	private int osaAgnstIndents;
	
	@Column(name="OSA_PO")
	private int osaAgnstPo;
	
	@Column(name="CONSUMP_THREE_YRS")
	private String consmpLstThreeYrs;
	
	
	
	@Column(name="OS_INDENT_DATA")
	private String osIndentData;
	
	
	@Column(name="OS_PO_DATA")
	private String osPoData;
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_ON")
	private Date createdOn;
	
	
	@Column(name="LAST_PAURCHASE_DATA")
	private String lastPurchaseParticulars;
	
	
	
	@Column(name="FINANCIAL_YEAR")
	private String financialYear;
	
	@Version
	private int version;
	
	
	public String getLastPurchaseParticulars() {
		return lastPurchaseParticulars;
	}

	public void setLastPurchaseParticulars(String lastPurchaseParticulars) {
		this.lastPurchaseParticulars = lastPurchaseParticulars;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public long getPoQuantityRcvd() {
		return poQuantityRcvd;
	}

	public void setPoQuantityRcvd(long quantityReceived) {
		this.poQuantityRcvd = quantityReceived;
	}

	public long getIndentLoggedBy() {
		return indentLoggedBy;
	}

	public void setIndentLoggedBy(long indentLoggedBy) {
		this.indentLoggedBy = indentLoggedBy;
	}
	
	public int getArticleEnclosed() {
		return articleEnclosed;
	}

	public void setArticleEnclosed(int articleEnclosed) {
		this.articleEnclosed = articleEnclosed;
	}
	
	
	public long getSerialNumber() {
		return serialNumber;
	}

	
	
	public String getControllingOfficer() {
		return controllingOfficer;
	}

	public void setControllingOfficer(String controllingOfficer) {
		this.controllingOfficer = controllingOfficer;
	}

	public void setSerialNumber(long serialNo) {
		this.serialNumber = serialNo;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description2) {
		this.description = description2;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	/*public long getPoReceived() {
		return poReceived;
	}*/

	public Date getPoDate() {
		return poDate;
	}

	/*public void setPoReceived(long poReceived) {
		this.poReceived = poReceived;
	}*/

	public void setPoDate(Date poDate) {
		this.poDate = poDate;
	}

	

	public IndentDetail() {
	}

	public int getAcceptableMake() {
		return this.acceptableMake;
	}

	public void setAcceptableMake(int acceptableMake) {
		this.acceptableMake = acceptableMake;
	}

	public String getAllocation() {
		return this.allocation;
	}

	public void setAllocation(String allocation) {
		this.allocation = allocation;
	}

	public long getConsignee() {
		return this.consignee;
	}

	public void setConsignee(long l) {
		this.consignee = l;
	}

	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getDepot() {
		return this.depot;
	}

	public void setDepot(int depot) {
		this.depot = depot;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getIndentId() {
		return this.indentId;
	}

	public void setIndentId(long indentId) {
		this.indentId = indentId;
	}

	public int getIndentor() {
		return this.indentor;
	}

	public void setIndentor(int l) {
		this.indentor = l;
	}

	public Date getLastUpdate() {
		return this.lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public int getMaterialsRequiredAt() {
		return this.materialsRequiredAt;
	}

	public void setMaterialsRequiredAt(int materialsRequiredAt) {
		this.materialsRequiredAt = materialsRequiredAt;
	}

	public String getPurpose() {
		return this.purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public long getQuantityReq() {
		return this.quantityReq;
	}

	public void setQuantityReq(long l) {
		this.quantityReq = l;
	}

	public String getUnits() {
		return this.units;
	}

	public void setUnits(String units) {
		this.units = units;
	}


	

	public double getRate() {
		return rate;
	}

	public double getValue() {
		return value;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public void setValue(double value) {
		this.value = value;
	}

	public int getVersion() {
		return this.version;
	}

	public void setVersion(int version) {
		this.version = version;
	}
	
	
	
	public int getIndentType() {
		return indentType;
	}

	public void setIndentType(int indentType) {
		this.indentType = indentType;
	}
	
	

	public long getLikelySupplier() {
		return likelySupplier;
	}

	public void setLikelySupplier(long i) {
		this.likelySupplier = i;
	}
	
	

	public long getStockAvailable() {
		return stockAvailable;
	}

	public int getOsaAgnstIndents() {
		return osaAgnstIndents;
	}

	public int getOsaAgnstPo() {
		return osaAgnstPo;
	}

	public String getConsmpLstThreeYrs() {
		return consmpLstThreeYrs;
	}

	public String getOsIndentData() {
		return osIndentData;
	}

	public String getOsPoData() {
		return osPoData;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setStockAvailable(long l) {
		this.stockAvailable = l;
	}

	public void setOsaAgnstIndents(int osaAgnstIndents) {
		this.osaAgnstIndents = osaAgnstIndents;
	}

	public void setOsaAgnstPo(int osaAgnstPo) {
		this.osaAgnstPo = osaAgnstPo;
	}

	public void setConsmpLstThreeYrs(String consmpLstThreeYrs) {
		this.consmpLstThreeYrs = consmpLstThreeYrs;
	}

	public void setOsIndentData(String osIndentData) {
		this.osIndentData = osIndentData;
	}

	public void setOsPoData(String osPoData) {
		this.osPoData = osPoData;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	
	
	
	public String getFinancialYear() {
		return financialYear;
	}

	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}

	@PrePersist
	void createdAt() {
		this.createdOn= new Date();
		this.lastUpdate = new Date();

	}

	@PreUpdate
	void updatedAt() {
		this.lastUpdate = new Date();
	}

	
	
	
	
}