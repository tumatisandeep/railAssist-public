package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the transport_details database table.
 * 
 */
@Entity
@Table(name="transport_details")
@NamedQuery(name="TransportDetail.findAll", query="SELECT t FROM TransportDetail t")
public class TransportDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TRANSPORT_DETAILS_ID")
	private int transportDetailsId;

	@Column(name="DRIVERS_NAME")
	private String driversName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="GR_DATE")
	private Date grDate;

	@Column(name="GR_NO")
	private String grNo;

	@Column(name="TRANSPORT_NAME")
	private String transportName;

	@Column(name="VEHICLE_NUMBER")
	private String vehicleNumber;

	private String version;

	public TransportDetail() {
	}

	public int getTransportDetailsId() {
		return this.transportDetailsId;
	}

	public void setTransportDetailsId(int transportDetailsId) {
		this.transportDetailsId = transportDetailsId;
	}

	public String getDriversName() {
		return this.driversName;
	}

	public void setDriversName(String driversName) {
		this.driversName = driversName;
	}

	public Date getGrDate() {
		return this.grDate;
	}

	public void setGrDate(Date grDate) {
		this.grDate = grDate;
	}

	public String getGrNo() {
		return this.grNo;
	}

	public void setGrNo(String grNo) {
		this.grNo = grNo;
	}

	public String getTransportName() {
		return this.transportName;
	}

	public void setTransportName(String transportName) {
		this.transportName = transportName;
	}

	public String getVehicleNumber() {
		return this.vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}