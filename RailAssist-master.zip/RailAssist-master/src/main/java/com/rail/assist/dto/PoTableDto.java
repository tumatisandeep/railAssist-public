package com.rail.assist.dto;

import java.util.Date;

public class PoTableDto {
	
	
	private String poNumber;
	
	private Date date;
	
	private double price;
	
	private String category;
	
	private String suppliedBy;

	private Date dueDate;
	
	
	private int quantity;
	
	private String itemType;
	
	
	
	
	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public Date getDate() {
		return date;
	}

	public double getPrice() {
		return price;
	}

	public String getCategory() {
		return category;
	}

	public String getSuppliedBy() {
		return suppliedBy;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setSuppliedBy(String suppliedBy) {
		this.suppliedBy = suppliedBy;
	}
	
	
	
	

}
