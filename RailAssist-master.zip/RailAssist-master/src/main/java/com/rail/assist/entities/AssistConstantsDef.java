package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

@Entity
@Table(name = "ACD_DATA")
@NamedQuery(name="AssistConstantsDef.findAll", query="SELECT c FROM AssistConstantsDef c")
public class AssistConstantsDef implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private int id;

	@Column(name="ACD_KEY")
	private String constantKey;
	
	@Column(name="ACD_VALUE")
	private String constantValue;

	@Column(name="ACD_VALUE_DESC")
	private String constantDesc;
	

	@Column(name="ACD_OLD_VALUE")
	private String constantOldValue;
	
	
	@Temporal(TemporalType.DATE)
	@Column(name = "CREATED_ON")
	private Date createdOn;
	
	@Column(name = "CREATED_BY")
	private long createdBy;
	
	@Column(name = "UPDATED_BY")
	private long updatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_UPDATE")
	private Date lastUpdate;
	
	@Version
	private Integer version;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getConstantKey() {
		return constantKey;
	}

	public void setConstantKey(String constantKey) {
		this.constantKey = constantKey;
	}

	public String getConstantValue() {
		return constantValue;
	}

	public void setConstantValue(String constantValue) {
		this.constantValue = constantValue;
	}

	public String getConstantDesc() {
		return constantDesc;
	}

	public void setConstantDesc(String constantDesc) {
		this.constantDesc = constantDesc;
	}

	public String getConstantOldValue() {
		return constantOldValue;
	}

	public void setConstantOldValue(String constantOldValue) {
		this.constantOldValue = constantOldValue;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(long updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

	
	
	@PrePersist
	void createdAt() {
		this.createdOn = new Date();
		this.lastUpdate = new Date();

	}

	@PreUpdate
	void updatedAt() {
		this.lastUpdate = new Date();
	}

	
}
