package com.rail.assist.config;

import java.util.Base64;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;




public class RailAssistFilter extends UsernamePasswordAuthenticationFilter {

	@Autowired
	ProcessUser processUser;
	
	
	
	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
			throws AuthenticationException {
		
		UsernamePasswordAuthenticationToken authRequest=null;
		try {
			if (!request.getMethod().equals("POST")) {
				throw new AuthenticationServiceException("Authentication method not supported: " + request.getMethod());
			}

			String userName = request.getParameter("userName");
			String password = Base64.getEncoder().encodeToString(request.getParameter("password").getBytes());
			if (userName == null) {
				userName = "";
			}

			if (password == null) {
				password = "";
			}

			userName = userName.trim();

		/*	UserDetail user = new UserDetail();
			user.setUserMailId(userName);
			user.setUserPassword(password);
*/
			authRequest=processUser.processUserLogin(userName, password);
			
			//System.out.println("authRequest"+authRequest);
			setDetails(request, authRequest);
			
			
		} catch (Exception e) {
			e.printStackTrace();
			//throw e;
		}
		
		return this.getAuthenticationManager().authenticate(authRequest);


	}

}
