package com.rail.assist.dto;

import java.util.Date;

public class ChallanTableDto {
	
	
	private String challanNo;
	
	private int numberOfItems;
	
	private Date date;
	
	private String issuedTo;

	public String getChallanNo() {
		return challanNo;
	}

	public int getNumberOfItems() {
		return numberOfItems;
	}

	public Date getDate() {
		return date;
	}

	public String getIssuedTo() {
		return issuedTo;
	}

	public void setChallanNo(String challanNo) {
		this.challanNo = challanNo;
	}

	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setIssuedTo(String issuedTo) {
		this.issuedTo = issuedTo;
	}

	
	
	
	
	

}
