package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the category database table.
 * 
 */
@Entity
@Table(name="GROUP_DETAILS")
@NamedQuery(name="GroupDetails.findAll", query="SELECT c FROM GroupDetails c")
public class GroupDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="GROUP_ID")
	private int groupId;

	@Column(name="GROUP_DEC")
	private String groupDesc;
	
	@Column(name="CREATED_BY")
	private int createdBy;

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getGroupId() {
		return groupId;
	}

	public String getGroupDesc() {
		return groupDesc;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public void setGroupDesc(String groupDesc) {
		this.groupDesc = groupDesc;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	
	
	
}