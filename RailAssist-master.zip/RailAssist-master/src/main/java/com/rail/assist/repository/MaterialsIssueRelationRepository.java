package com.rail.assist.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.MaterialsIssueRelation;


public interface MaterialsIssueRelationRepository extends JpaRepository<MaterialsIssueRelation,Long> {
	
	
	
	List<MaterialsIssueRelation> findByItemIdAndDateIssueGreaterThanEqualAndDateIssueLessThanEqual(long itemId, Date fromDate,Date toDate);
	
	List<MaterialsIssueRelation> findByUniqueRelationId(long id);
	
	MaterialsIssueRelation findById(long id);
	
	Page<MaterialsIssueRelation> findByItemId(long id,Pageable p);

	
}



