package com.rail.assist.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.rail.assist.config.CurrentUser;
import com.rail.assist.dto.IndentDataDto;
import com.rail.assist.dto.IndentDtoHome;
import com.rail.assist.dto.ItemsDeliveryDueDto;
import com.rail.assist.dto.ItemsIssuedDtoHome;
import com.rail.assist.dto.PoDtoHome;
import com.rail.assist.dto.UserDashBoardDto;
import com.rail.assist.entities.IndentDetail;
import com.rail.assist.entities.IndentPoRelation;
import com.rail.assist.entities.MaterialIssueData;
import com.rail.assist.entities.MaterialsReceivedData;
import com.rail.assist.entities.PurchaseOrderDetail;
import com.rail.assist.entities.UserDetail;
import com.rail.assist.entities.VendorsData;
import com.rail.assist.repository.IndentDetailRepository;
import com.rail.assist.repository.IndentPoRepository;
import com.rail.assist.repository.MaterialsIssueDataRepository;
import com.rail.assist.repository.MaterialsReceivedDataRepository;
import com.rail.assist.repository.MaterialsRequiredAtRepository;
import com.rail.assist.repository.PoDetailRepository;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.repository.VendorsDataRepository;
import com.rail.assist.service.ChallanService;
import com.rail.assist.service.HomeService;
import com.rail.assist.service.IndentService;
import com.rail.assist.service.PoService;


@Controller
public class HomeController {

	@Autowired
	private CurrentUser currentUser;

	@Autowired
	private IndentDetailRepository indentDetailRepository;

	@Autowired
	private UserDetailsRepository userDetailsRepository;

	
	@Autowired
	private VendorsDataRepository vendorsDataRepository;

	@Autowired
	private IndentPoRepository indentPoRepository;

	@Autowired
	private PoDetailRepository poDetailRepository;
	
	@Autowired
	private IndentService indentService;
	
	@Autowired
	private PoService poService; 
	
	@Autowired
	private ChallanService challanService;
	
	@Autowired
	private MaterialsReceivedDataRepository materialsReceivedDataRepository;
	
	@Autowired
	private MaterialsIssueDataRepository materialsIssueDataRepository;
	
	@Autowired
	private MaterialsRequiredAtRepository materialsRequiredAtRepository;
	
	
	@Autowired
	private HomeService homeService;
	
	@RequestMapping("/home")
	public String loadHomePage(Model model, RedirectAttributes redirectAttributes) throws Exception {
		
		
		try {
			
			
			

			//System.out.println("heelo");
		UserDetail userData = currentUser.getCurrentUser();


		
		Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "date"));
        Pageable pageable = new PageRequest(0, 20, sort);
        
        
		List<IndentDetail> indents = indentDetailRepository.findAll(pageable).getContent();

		List<IndentDtoHome> indentsDtoList=new ArrayList<>();
		
		for (IndentDetail indentDetail : indents) {

			IndentDtoHome indentDto = new IndentDtoHome();
			indentDto.setId(indentDetail.getId());
			indentDto.setItemId(indentDetail.getItemId());
			indentDto.setIndentId(indentDetail.getIndentId());
			indentDto.setQuantityReq(indentDetail.getQuantityReq());
			indentDto.setDate(indentDetail.getCreatedOn());
			
			indentDto.setMaterialsRequiredAt(materialsRequiredAtRepository.findById(indentDetail.getMaterialsRequiredAt()).getLocationDesc());

			UserDetail user = userDetailsRepository.findByUserId(indentDetail.getIndentLoggedBy());

			indentDto.setIndentLoggedBy(user.getUserFirstName() + " " + user.getUserLastName());
			indentDto.setTitle("Indent "+indentDetail.getIndentId()+" is generated for the item "+indentDetail.getItemId());
			indentDto.setDescription("Indent is generated for the value of "+ indentDetail.getValue()+", and the quantity required is "+indentDetail.getQuantityReq()+" for the financial year "+indentDetail.getFinancialYear());
			indentsDtoList.add(indentDto);

		}
		indentsDtoList=indentsDtoList.stream().sorted(Comparator.comparing(IndentDtoHome::getDate).reversed()).collect(Collectors.toList());

		
		/*
		 * indentsDtoList.sort((indent2, indent1) -> { return (int)
		 * (indent1.getDate().getTime() - indent2.getDate().getTime()); });
		 * 
		 * 
		 */
		
        
     //   Page<IndentDetail> indentData=indentDetailRepository.findAll(pageable);
        
		/*
		List<Long> recentIndnetIds= new ArrayList<>();
		
		for (IndentDetail indentDetail : indents) {
			
			recentIndnetIds.add(indentDetail.getIndentId());
			
			
		}*/
		
		/*
		Sort sortPo = new Sort(new Sort.Order(Sort.Direction.DESC, "createdOn"));
        Pageable pageablePo = new PageRequest(0, 10, sortPo);
		
        
		Page<PurchaseOrderDetail> purchaseOrderdetails = poDetailRepository.findAll(pageablePo);
        
		
		Map<Long,String> recentPOIds= new HashMap<Long, String>();
		
		for (PurchaseOrderDetail poData : purchaseOrderdetails) {
			
			recentPOIds.put(poData.getSerialNumber(),poData.getPoNumber());
			
			
		}
		*/
		
		// counts for displaying in charts home page
		long indentsGeneratedCount=indentDetailRepository.count();
		long poReceivedCount=poDetailRepository.count();
		long itemsReceivedCount=materialsReceivedDataRepository.count();
		long challansIssuedCount=materialsIssueDataRepository.count();
		
		
		// to get data from po details table whose due date is les thn a month form today
		
		Calendar now = Calendar.getInstance();
		now.set(Calendar.MINUTE, 0);
		now.set(Calendar.SECOND, 0);
		now.set(Calendar.HOUR_OF_DAY, 0);

		Date todayDateObj = now.getTime();
		
		
		now.add(Calendar.DATE, 30);

		//System.out.println("next day++++++++++++++++" + now.getTime());
		Date nextDayDateObj = now.getTime();
		
		// code for due date dashboard
		List<IndentPoRelation> poData = indentPoRepository
				.findByDueDateGreaterThanEqualAndDueDateLessThanEqual(todayDateObj, nextDayDateObj);
		
				List<ItemsDeliveryDueDto> itemsDueData=new ArrayList<>();
				
				
				SimpleDateFormat formatter = new SimpleDateFormat("MMM dd, yyyy");  
			      			
				
		for (IndentPoRelation indentPoRelation : poData) {

			ItemsDeliveryDueDto dto = new ItemsDeliveryDueDto();

			dto.setDueDate(indentPoRelation.getDueDate());
			dto.setDueDateString(formatter.format(indentPoRelation.getDueDate()));
			//System.out.println(indentPoRelation.getDueDate());
			dto.setIndentId(indentPoRelation.getId().getIndentId());
			dto.setItemId(indentPoRelation.getItemId());
			dto.setPoNUmber(indentPoRelation.getPoNumber());
			//System.out.println(indentPoRelation.getPoNumber());
			//System.out.println(poDetailRepository.findByPoNumber(indentPoRelation.getPoNumber().trim()).toString());
			//System.out.println(poDetailRepository.findByPoNumber(indentPoRelation.getPoNumber().trim()).getSuppliedBy());
			//System.out.println(vendorsDataRepository
			//		.findById(poDetailRepository.findByPoNumber(indentPoRelation.getPoNumber()).getSuppliedBy()));
			VendorsData suppliedBy = vendorsDataRepository
					.findById(poDetailRepository.findByPoNumber(indentPoRelation.getPoNumber().trim()).getSuppliedBy());
			
			
			dto.setVendor(suppliedBy.getSupplierDesc() + " " + suppliedBy.getCity());
			dto.setItemCategory(indentPoRelation.getItemCategory());
			itemsDueData.add(dto);

		}
				
				//System.out.println("after for loop");
				// for user dash board
				
				Calendar nowObj = Calendar.getInstance();
				nowObj.set(Calendar.MINUTE, 0);
				nowObj.set(Calendar.SECOND, 0);
				nowObj.set(Calendar.HOUR_OF_DAY, 0);

				
				nowObj.add(Calendar.DATE, 1);
				Date todayDateObj1=nowObj.getTime();
				nowObj.add(Calendar.DATE, -11);

				Date tenDaysBackDate=nowObj.getTime();
				// for indent data 
				
				
			
				List<UserDashBoardDto> userDataDtoList=new ArrayList<>(); // this list is to display data in dash board
				
				// below code is to add last 10 days indents in userDataDtoList list to display in dashboard
				
				List<IndentDetail> pastTenDaysIndentData = indentDetailRepository
						.findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(tenDaysBackDate, todayDateObj1);
				for (IndentDetail indentDetail : pastTenDaysIndentData) {
					
					UserDashBoardDto dto=new UserDashBoardDto();
					
					dto.setActivityPerformed("generated");
					dto.setDate(indentDetail.getCreatedOn());
					dto.setOperationType("Indnet");
					UserDetail user=userDetailsRepository.findByUserId(indentDetail.getIndentLoggedBy());
					dto.setUser(user.getUserFirstName()+" "+user.getUserLastName());
					dto.setpLink(user.getUserPlink());
					dto.setId(String.valueOf(indentDetail.getIndentId()));
					userDataDtoList.add(dto);
				}
				//System.out.println("after for loop at userDATADTO");
				
				// below code is to add last 10 days PO's in userDataDtoList list to display in dashboard
		List<PurchaseOrderDetail> pastTenDaysPoData = poDetailRepository
				.findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(tenDaysBackDate, todayDateObj1);

				for (PurchaseOrderDetail poDataObj : pastTenDaysPoData) {
					
					UserDashBoardDto dto=new UserDashBoardDto();
					
					dto.setActivityPerformed("added");
					dto.setDate(poDataObj.getCreatedOn());
					dto.setOperationType("Purchase Order");
					UserDetail user=userDetailsRepository.findByUserId(poDataObj.getCreatedBy());
					dto.setUser(user.getUserFirstName()+" "+user.getUserLastName());
					dto.setpLink(user.getUserPlink());
					dto.setId(poDataObj.getPoNumber()+"/"+String.valueOf(poDataObj.getSerialNumber()));
					userDataDtoList.add(dto);
				}
				//System.out.println("after for loop at UserDashBoardDto");

				
				// below code is to add last 10 days items received dta  in userDataDtoList list to display in dashboard
				List<MaterialsReceivedData> pastTenDaysReceivedData = materialsReceivedDataRepository
						.findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(tenDaysBackDate, todayDateObj1);

				for (MaterialsReceivedData rceivedData : pastTenDaysReceivedData) {
					
					UserDashBoardDto dto=new UserDashBoardDto();
					
					dto.setActivityPerformed(" information added");
					dto.setDate(rceivedData.getCreatedon());
					dto.setOperationType(rceivedData.getNumberOfItemsReceived()+" Items received");
					UserDetail user=userDetailsRepository.findByUserId(rceivedData.getCreatedBy());
					dto.setUser(user.getUserFirstName()+" "+user.getUserLastName());
					dto.setpLink(user.getUserPlink());
					dto.setId(" | Item id : "+String.valueOf(rceivedData.getItemId()));
					userDataDtoList.add(dto);
				}
				
				//System.out.println("after for loop at MaterialsReceivedData");

				// below code is to add last 10 days challans in userDataDtoList list to display in dashboard
		
		List<MaterialIssueData> pastTenDaysIssueData = materialsIssueDataRepository
				.findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(tenDaysBackDate, todayDateObj1);

				for (MaterialIssueData challanData : pastTenDaysIssueData) {
					
					UserDashBoardDto dto=new UserDashBoardDto();
					
					dto.setActivityPerformed("issued");
					dto.setDate(challanData.getCreatedOn());
					dto.setOperationType("Challan");
					UserDetail user=userDetailsRepository.findByUserId(challanData.getCreatedBy());
					dto.setUser(user.getUserFirstName()+" "+user.getUserLastName());
					dto.setpLink(user.getUserPlink());
					dto.setId(challanData.getChallanNumber());
					userDataDtoList.add(dto);
				}
				
				//System.out.println("after for loop at pastTenDaysIssueData");

				userDataDtoList.sort((dto1, dto2) -> {
					return (int) (dto1.getDate().getTime() - dto2.getDate().getTime());
				});

				
				String json = null; // recent 15 indents data in tabs
	
				json = new Gson().toJson(indentsDtoList);

		
		String itemsDueDelivery=null; // itsms due data dashboard
		
		String userDashBoardData=null; // past 10 days users activities dashboard
		
		itemsDueDelivery=new Gson().toJson(itemsDueData);
		
		
		userDashBoardData=new Gson().toJson(userDataDtoList);
		
		//model.addAttribute("recentPos", recentPOIds);
		//model.addAttribute("recentIndnetIds", recentIndnetIds);
		model.addAttribute("indentUpdates", json);
		model.addAttribute("userName", userData.getUserFirstName() + " " + userData.getUserLastName());
		model.addAttribute("empId", userData.getUserId());
		model.addAttribute("mailId", userData.getUserMailId());
		model.addAttribute("pLink", userData.getUserPlink());
		model.addAttribute("indentsGeneratedCount", indentsGeneratedCount);
		model.addAttribute("poReceivedCount", poReceivedCount);
		model.addAttribute("itemsReceivedCount",itemsReceivedCount);
		model.addAttribute("challansIssuedCount",challansIssuedCount);
		model.addAttribute("itemsDueData", itemsDueDelivery);
		model.addAttribute("userDashBoardData", userDashBoardData);

		//System.out.println("finall retrun");
		
		}catch(Exception e) {
			
			e.printStackTrace();
			
			throw e;
		}
		return "newHome";
	}
	
	
	
	
	
	@RequestMapping(value = "/findIssueOrPO", method = RequestMethod.POST)
	public String viewIndentOrPoOrChallan(@RequestParam("searchOn") int indentPOOrChallan, @RequestParam("uniqueId") String uniqueId,
			Model model,RedirectAttributes redirectAttributes) throws NumberFormatException, Exception {
		try {
			
			
			
			//System.out.println(indentPOOrChallan + " ---------" + uniqueId);
			if (indentPOOrChallan == 1) {

				IndentDataDto indentDataDto = new IndentDataDto();

				if (uniqueId.trim().equals("")) {

					redirectAttributes.addFlashAttribute("indentIdEmpty", true);
					// redirectAttributes.addFlashAttribute("indentId",uniqueId);
					return "redirect:/home";

				} else {

					try {
						Integer.valueOf(uniqueId);

					} catch (NumberFormatException e) {

						redirectAttributes.addFlashAttribute("indentIdEmpty", true);
						return "redirect:/home";

					}

					indentDataDto = indentService.getIndentDataWithIndentId(Integer.valueOf(uniqueId));

					if (!indentDataDto.isIndentFound()) {
						redirectAttributes.addFlashAttribute("indentNotFound", true);
						redirectAttributes.addFlashAttribute("indentId", uniqueId);
						return "redirect:/home";

					} else {
						model.addAttribute("indentDetail", indentDataDto);

						return "viewIndentDetails";
					}

				}

			}

			else if (indentPOOrChallan == 2) {

				//System.out.println(uniqueId + "-----------------");
				PoDtoHome poDto = new PoDtoHome();

				poDto = poService.showPo(uniqueId);

				if (poDto.isPoFound()) {
					model.addAttribute("poDto", poDto);

					return "viewPoDetails";

				}

				else {
					redirectAttributes.addFlashAttribute("poNotFound", true);
					redirectAttributes.addFlashAttribute("poNumber", uniqueId);
					return "redirect:/home";
				}

			}
			

			else {

				ItemsIssuedDtoHome itemsData = new ItemsIssuedDtoHome();

				itemsData = challanService.getChallanInfo(uniqueId);

				// List<MaterialsIssueRelation> materialsIssued=
				// materialsIssueRelationRepository.findByUniqueRelationId(materialData.getUniqueRelationNo());
				if (itemsData.isChallanFound()) {

					model.addAttribute("itemsData", itemsData);
					return "viewIssuedDetails";

				} else {
					redirectAttributes.addFlashAttribute("challanNotFound", true);
					redirectAttributes.addFlashAttribute("challanNumber", uniqueId);
					return "redirect:/home";
				}

			}
		} catch (Exception e) {
			      
			e.printStackTrace();
			
			throw e;
		}
		

	}

	
	
	
	@RequestMapping("/viewAllData")
	public String allIssues(Model model) throws Exception {
		try {


			Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "id"));
			Pageable pageable = new PageRequest(0, 10, sort);
		//	List<IndentDetail> indentDetails = homeService.getAllIndents(pageable);

			
			String json=null;
			
			
			long count=homeService.getTotalCountOfIndents();
			
			
			/*List<AllDataDto> allDataIndent=new ArrayList<>();
			for (IndentDetail indentDetail : indentDetails) {

				AllDataDto indentDto = new AllDataDto();
				indentDto.setId("Indent id:" + String.valueOf(indentDetail.getIndentId()));
				indentDto.setId1("Item id:" + String.valueOf(indentDetail.getItemId()));
				indentDto.setId2("Quantity:" + String.valueOf(indentDetail.getQuantityReq()));
				indentDto.setLoggedDate(indentDetail.getCreatedOn());
				UserDetail userLogged = userDetailsRepository.findByUserId(indentDetail.getIndentLoggedBy());
				indentDto
						.setLoggedBy("Logged by:" + userLogged.getUserFirstName() + " " + userLogged.getUserLastName());
				indentDto.setUniqueId(indentDetail.getId());
				indentDto.setTitle("Indent " + indentDetail.getIndentId() + " is generated for the item "
						+ indentDetail.getItemId());
				indentDto.setDesc("Indent is generated for the value of " + indentDetail.getValue()
						+ ", and the quantity required is " + indentDetail.getQuantityReq() + " for the financial year "
						+ indentDetail.getFinancialYear());
				indentDto.setCategory(1); // for indents
				allDataIndent.add(indentDto);

			}
			
			if(allDataIndent.size()<=10) {
				
				model.addAttribute("loadButton", false);
			}
			else {
				model.addAttribute("loadButton", true);

				}
			
			json = new Gson().toJson(allDataIndent);*/
	
			model.addAttribute("allIndentData", json);

			model.addAttribute("totalNoOfIndents", count);
			
			model.addAttribute("searchNotDone", true);
		

			
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return "allData";
	}
	
	
	
	
	
	

}
