/**
 * 
 */
package com.rail.assist.dto;

import java.util.Date;

/**
 * @author Mahideep Tumati
 *
 * Created on Jul 2, 2018
 */
public class UserDashBoardDto {
	
	private String activityPerformed; // generated for indent or added for po or items received data or issued for challan
	
	private String operationType;// indent or PO or itemsRecived or challan generated
	
	private Date date;
	
	private String user;
	
	private String pLink;
	
	private String id; 

	public String getActivityPerformed() {
		return activityPerformed;
	}

	public void setActivityPerformed(String activityPerformed) {
		this.activityPerformed = activityPerformed;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getpLink() {
		return pLink;
	}

	public void setpLink(String pLink) {
		this.pLink = pLink;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	
	
	
}
