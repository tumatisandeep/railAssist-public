package com.rail.assist.dto;

import java.util.Date;

public class ItemsIssuedDataDto {
	
	
	private long itemId;
	
	
	private int qty;
	
	private String poNumber;

	public long getItemId() {
		return itemId;
	}

	public int getQty() {
		return qty;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	
	
	
	
	
	
	

}
