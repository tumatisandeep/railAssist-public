package com.rail.assist.dto;

import java.util.Date;

public class IndentDataDto {
	

private int id;

	private String title;

	private String purpose;

	private String allocation;

	private String indentor;

	private long indentId;

	private String Consignee;

	private Date date;

	private String materialsReqAt;

	private String depot;

	private int quantity;

	private String acceptableMake;

	private double rate;
	
	private double value;
	
	private Date poDate;

	private boolean poReceived;
	
	private String indentloggedBy;
	
	private long itemId;
	
	private boolean indentFound;
	
	private String controllingofficer;
	
	private String financialyear;
	
	private int osaAgnstIndents;
	
	private int osaAgnstPo;
	
	private long stockAvailable;
	
	private Date loggedDate;
	

	public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}



	
	public String getControllingofficer() {
		return controllingofficer;
	}

	public String getFinancialyear() {
		return financialyear;
	}

	public int getosaAgnstIndents() {
		return osaAgnstIndents;
	}

	public int getosaAgnstPo() {
		return osaAgnstPo;
	}

	public long getStockAvailable() {
		return stockAvailable;
	}

	public void setControllingofficer(String controllingofficer) {
		this.controllingofficer = controllingofficer;
	}

	public void setFinancialyear(String financialyear) {
		this.financialyear = financialyear;
	}

	public void setosaAgnstIndents(int osaAgnstIndents) {
		this.osaAgnstIndents = osaAgnstIndents;
	}

	public void setosaAgnstPo(int osaAgnstPo) {
		this.osaAgnstPo = osaAgnstPo;
	}

	public void setStockAvailable(long l) {
		this.stockAvailable = l;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public String getIndentloggedBy() {
		return indentloggedBy;
	}

	public void setIndentloggedBy(String indentloggedBy) {
		this.indentloggedBy = indentloggedBy;
	}

	public Date getPoDate() {
		return poDate;
	}

	public boolean isPoReceived() {
		return poReceived;
	}

	public void setPoDate(Date poDate) {
		this.poDate = poDate;
	}

	public void setPoReceived(boolean poReceived) {
		this.poReceived = poReceived;
	}

	

	public String getTitle() {
		return title;
	}

	public String getPurpose() {
		return purpose;
	}

	public String getAllocation() {
		return allocation;
	}

	public String getIndentor() {
		return indentor;
	}

	public long getIndentId() {
		return indentId;
	}

	public String getConsignee() {
		return Consignee;
	}

	public Date getDate() {
		return date;
	}

	public String getMaterialsReqAt() {
		return materialsReqAt;
	}

	public String getDepot() {
		return depot;
	}

	public int getQuantity() {
		return quantity;
	}

	public String getAcceptableMake() {
		return acceptableMake;
	}


	public void setTitle(String title) {
		this.title = title;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public void setAllocation(String allocation) {
		this.allocation = allocation;
	}

	public void setIndentor(String indentor) {
		this.indentor = indentor;
	}

	public void setIndentId(long indentId) {
		this.indentId = indentId;
	}

	public void setConsignee(String consignee) {
		Consignee = consignee;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setMaterialsReqAt(String materialsReqAt) {
		this.materialsReqAt = materialsReqAt;
	}

	public void setDepot(String depot) {
		this.depot = depot;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setAcceptableMake(String acceptableMake) {
		this.acceptableMake = acceptableMake;
	}

	public double getRate() {
		return rate;
	}

	public double getValue() {
		return value;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public void setValue(double value) {
		this.value = value;
	}

	public boolean isIndentFound() {
		return indentFound;
	}

	public void setIndentFound(boolean indentFound) {
		this.indentFound = indentFound;
	}

	
	
	public Date getLoggedDate() {
		return loggedDate;
	}

	public void setLoggedDate(Date loggedDate) {
		this.loggedDate = loggedDate;
	}

	@Override
	public String toString() {
		return "IndentDataDto [id=" + id + ", title=" + title + ", purpose=" + purpose + ", allocation=" + allocation
				+ ", indentor=" + indentor + ", indentId=" + indentId + ", Consignee=" + Consignee + ", date=" + date
				+ ", materialsReqAt=" + materialsReqAt + ", depot=" + depot + ", quantity=" + quantity
				+ ", acceptableMake=" + acceptableMake + ", rate=" + rate + ", value=" + value + ", poDate=" + poDate
				+ ", poReceived=" + poReceived + ", indentloggedBy=" + indentloggedBy + ", itemId=" + itemId
				+ ", indentFound=" + indentFound + ", controllingofficer=" + controllingofficer + ", financialyear="
				+ financialyear + ", osaAgnstIndents=" + osaAgnstIndents + ", osaAgnstPo=" + osaAgnstPo
				+ ", stockAvailable=" + stockAvailable + "]";
	}

	
	
	
	
	

}
