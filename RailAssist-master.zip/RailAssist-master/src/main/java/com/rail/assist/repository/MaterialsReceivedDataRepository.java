package com.rail.assist.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rail.assist.entities.MaterialsReceivedData;

public interface MaterialsReceivedDataRepository extends JpaRepository<MaterialsReceivedData, Integer> {

	@Query("from MaterialsReceivedData m where trunc(m.createdOn)=TO_DATE(?1,'dd-MM-yyyy')")
	List<MaterialsReceivedData> findByCreatedOnFunction(String todayDate);

	MaterialsReceivedData findById(long id);

	List<MaterialsReceivedData> findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(Date todayDateObj,
			Date nextDayDateObj);
	
	long countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(Date todayDateObj,
			Date nextDayDateObj);

	/**
	 * @param userId
	 * @param dateF
	 * @param dateT
	 * @return
	 */
	List<MaterialsReceivedData> findByCreatedByAndCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(long userId,
			Date dateF, Date dateT);

	/**
	 * @param userId
	 * @return
	 */
	List<MaterialsReceivedData> findByCreatedBy(long userId);

}
