package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.Consignee;


public interface ConsigneeRepository extends JpaRepository<Consignee,Integer> {
	
	
	Consignee findByConsigneeId(int id);
	
	Consignee findById(int id);

	

	
}



