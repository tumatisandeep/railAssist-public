package com.rail.assist.service;

import com.rail.assist.dto.ItemsIssuedDtoHome;

public interface ChallanService {

	ItemsIssuedDtoHome getChallanData(int id) throws NumberFormatException, Exception;

	ItemsIssuedDtoHome getChallanInfo(String uniqueId) throws NumberFormatException, Exception;



	
	
}
