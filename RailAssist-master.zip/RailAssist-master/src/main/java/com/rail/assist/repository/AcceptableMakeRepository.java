package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.AcceptableMake;


public interface AcceptableMakeRepository extends JpaRepository<AcceptableMake,Long> {
	
	AcceptableMake findByAcceptableMakeid(int id);
	
}



