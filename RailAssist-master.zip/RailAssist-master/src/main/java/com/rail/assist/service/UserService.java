package com.rail.assist.service;

import java.util.List;

import org.springframework.security.core.GrantedAuthority;

import com.rail.assist.dto.UserDto;
import com.rail.assist.entities.UserDetail;

public interface UserService {

	void insertUser(UserDto userDto, String hashedPassword) throws NumberFormatException, Exception;

	List<GrantedAuthority> findAllRoles(UserDetail userDetailInfo1) throws Exception;

}
