package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the material_issue database table.
 * 
 */
@Embeddable
public class MaterialIssuePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="MATERIAL_ISSUE_ID")
	private int materialIssueId;

	@Column(name="GATE_PASS")
	private int gatePass;

	public MaterialIssuePK() {
	}
	public int getMaterialIssueId() {
		return this.materialIssueId;
	}
	public void setMaterialIssueId(int materialIssueId) {
		this.materialIssueId = materialIssueId;
	}
	public int getGatePass() {
		return this.gatePass;
	}
	public void setGatePass(int gatePass) {
		this.gatePass = gatePass;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof MaterialIssuePK)) {
			return false;
		}
		MaterialIssuePK castOther = (MaterialIssuePK)other;
		return 
			(this.materialIssueId == castOther.materialIssueId)
			&& (this.gatePass == castOther.gatePass);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.materialIssueId;
		hash = hash * prime + this.gatePass;
		
		return hash;
	}
}