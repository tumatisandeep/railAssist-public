package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.UserAccountStatus;


public interface UserAccountStatusRepository extends JpaRepository<UserAccountStatus,Long> {
	
	UserAccountStatus findByUserAccountStatusId(int id);

}



