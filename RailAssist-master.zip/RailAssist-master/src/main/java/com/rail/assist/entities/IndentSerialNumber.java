package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the indent_serial_number database table.
 * 
 */
@Entity
@Table(name = "indent_serial_number")
@NamedQuery(name = "IndentSerialNumber.findAll", query = "SELECT i FROM IndentSerialNumber i")
public class IndentSerialNumber implements Serializable {
	private static final long serialVersionUID = 1L;

	
	@Id
	private int id;

	
	@Column(name = "item_type")
	private long itemType;
	
	@Column(name = "finalcial_year")
	private String financialYear;
	
	@Column(name = "indent_serial_number")
	private int serialNumber;

	
	@Temporal(TemporalType.DATE)
	@Column(name = "last_update")
	private Date lastUpdate;


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public long getItemType() {
		return itemType;
	}


	public void setItemType(long itemType) {
		this.itemType = itemType;
	}


	public String getFinancialYear() {
		return financialYear;
	}


	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}


	public int getSerialNumber() {
		return serialNumber;
	}


	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}


	public Date getLastUpdate() {
		return lastUpdate;
	}


	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	

}