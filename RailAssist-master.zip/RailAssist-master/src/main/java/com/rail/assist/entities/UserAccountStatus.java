package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the user_account_status database table.
 * 
 */
@Entity
@Table(name="user_account_status")
@NamedQuery(name="UserAccountStatus.findAll", query="SELECT u FROM UserAccountStatus u")
public class UserAccountStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="USER_ACCOUNT_STATUS_ID")
	private int userAccountStatusId;

	@Column(name="USER_ACCOUNT_STATUS_DESC")
	private String userAccountStatusDesc;

	//bi-directional many-to-one association to UserDetail
	@OneToMany(mappedBy="userAccountStatusBean")
	private List<UserDetail> userDetails;

	public UserAccountStatus() {
	}

	public int getUserAccountStatusId() {
		return this.userAccountStatusId;
	}

	public void setUserAccountStatusId(int userAccountStatusId) {
		this.userAccountStatusId = userAccountStatusId;
	}

	public String getUserAccountStatusDesc() {
		return this.userAccountStatusDesc;
	}

	public void setUserAccountStatusDesc(String userAccountStatusDesc) {
		this.userAccountStatusDesc = userAccountStatusDesc;
	}

	public List<UserDetail> getUserDetails() {
		return this.userDetails;
	}

	public void setUserDetails(List<UserDetail> userDetails) {
		this.userDetails = userDetails;
	}

	public UserDetail addUserDetail(UserDetail userDetail) {
		getUserDetails().add(userDetail);
		userDetail.setUserAccountStatusBean(this);

		return userDetail;
	}

	public UserDetail removeUserDetail(UserDetail userDetail) {
		getUserDetails().remove(userDetail);
		userDetail.setUserAccountStatusBean(null);

		return userDetail;
	}

}