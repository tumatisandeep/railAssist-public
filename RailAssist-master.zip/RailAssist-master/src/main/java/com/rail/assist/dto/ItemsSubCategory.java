package com.rail.assist.dto;

public class ItemsSubCategory {

	
	
	private int catId;
	
	private String desc;
	
	private int groupId;

	public int getCatId() {
		return catId;
	}

	public String getDesc() {
		return desc;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	
	
}
