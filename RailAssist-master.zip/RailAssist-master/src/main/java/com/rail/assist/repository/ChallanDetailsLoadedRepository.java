package com.rail.assist.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.ChallanDetailsLoaded;


public interface ChallanDetailsLoadedRepository extends JpaRepository<ChallanDetailsLoaded, Integer> {
	
	List<ChallanDetailsLoaded> findByIdnAndDateObjGreaterThanEqualAndDateObjLessThanEqual(String idn, Date fromDate,Date toDate);
	

}
