package com.rail.assist.dto;

import java.util.List;
import java.util.Map;

import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ItemsWithPoDto {

	
	
	private int id;
	private long itemId;
	private String description;
	private String partNumber;
	private long stockAvailable;
	private Map<String,Integer> poNumbersWithItemsNotReceived;
	private boolean isOutStandingPoExists;
	
	
	private boolean isItemPresent;
	
	
	
	
	public boolean isOutStandingPoExists() {
		return isOutStandingPoExists;
	}
	public void setOutStandingPoExists(boolean isOutStandingPoExists) {
		this.isOutStandingPoExists = isOutStandingPoExists;
	}
	public boolean isItemPresent() {
		return isItemPresent;
	}
	public void setItemPresent(boolean isItemPresent) {
		this.isItemPresent = isItemPresent;
	}
	public int getId() {
		return id;
	}
	public long getItemId() {
		return itemId;
	}
	
	
	public long getStockAvailable() {
		return stockAvailable;
	}
	public void setStockAvailable(long stockAvailable) {
		this.stockAvailable = stockAvailable;
	}
	
	public Map<String, Integer> getPoNumbersWithItemsNotReceived() {
		return poNumbersWithItemsNotReceived;
	}
	public void setPoNumbersWithItemsNotReceived(Map<String, Integer> poNumbersWithItemsNotReceived) {
		this.poNumbersWithItemsNotReceived = poNumbersWithItemsNotReceived;
	}
	public String getDescription() {
		return description;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setItemId(long itemId) {
		this.itemId = itemId;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	
	
	
}
