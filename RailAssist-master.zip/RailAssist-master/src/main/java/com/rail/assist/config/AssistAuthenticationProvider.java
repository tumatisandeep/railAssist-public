package com.rail.assist.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

import com.rail.assist.entities.UserDetail;
import com.rail.assist.repository.UserDetailsRepository;





public class AssistAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	UserDetailsRepository userDetailsRepository;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		try {
			
			//UserDetail user = (UserDetail) authentication.getPrincipal();
			//UserDetail userObj = validateUserInfo(user);
			//return new UsernamePasswordAuthenticationToken(userObj, userObj.getUserPassword());

			 return authentication;
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}
	}

	private UserDetail validateUserInfo(UserDetail user) {

		String userId = user.getUserMailId();
		String password = user.getUserPassword();

		UserDetail userAccInfoFinalObj = userDetailsRepository.findByUserMailIdAndUserPassword(userId, password);

		if (userAccInfoFinalObj == null) {
			throw new BadCredentialsException("User  not exists.");

		}
		
		else{
			
		}

/*		user.setUserLoginStat(AssistConstantsParameters.USER_LOGGED_IN_CURRENTLY);
*/
		return userAccInfoFinalObj;

	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

}
