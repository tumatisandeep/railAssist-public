package com.rail.assist.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;


/**
 * The persistent class for the gender database table.
 * 
 */
@Entity
@NamedQuery(name="UserType.findAll", query="SELECT g FROM UserType g")
public class UserType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="USER_TYPE_ID")
	private int userTypeId;
 
	@Column(name="USER_TYPE_DESC")
	private String UserTypeDescDesc;

	public int getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(int userTypeId) {
		this.userTypeId = userTypeId;
	}

	public String getUserTypeDescDesc() {
		return UserTypeDescDesc;
	}

	public void setUserTypeDescDesc(String userTypeDescDesc) {
		UserTypeDescDesc = userTypeDescDesc;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}