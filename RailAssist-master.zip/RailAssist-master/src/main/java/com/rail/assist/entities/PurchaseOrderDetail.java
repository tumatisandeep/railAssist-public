package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.Version;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The persistent class for the purchase_order_details database table.
 * 
 */
@Entity
@Table(name = "purchase_order_details")
@NamedQuery(name = "PurchaseOrderDetail.findAll", query = "SELECT p FROM PurchaseOrderDetail p")
public class PurchaseOrderDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "PO_NO")
	private String poNumber;

	@Id
	@Column(name = "SERIAL_NUMBER")
	private long serialNumber;

	@Column(name = "TENDER_NUMBER")
	private String tenderNumber;


	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "OPENED_ON_DATE")
	private Date openedOnDate;


	@Column(name = "NUMBER_OF_INDENTS")
	private int numberOfIndents;

	@Column(name = "INDENTS_PO_REQ_ID")
	private long indentPoReqId;

	@Column(name = "SUPPLIED_BY")
	private long suppliedBy;
	

	@Column(name = "TENDER_TYPE")
	private String tenderType;
	

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "IMP_DUE_DATE")
	private Date impDueDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "OMC_DUE_DATE")
	private Date omcDueDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "IND_DUE_DATE")
	private Date indDueDate;

	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_ON")
	private Date createdOn;

	@Column(name = "CREATED_BY")
	private int createdBy;
	
	@Column(name = "UPDATED_BY")
	private int updatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_UPDATE")
	private Date lastUpdate;

	
	@Version
	private int version;
	

	@Transient
	@JsonProperty("totalQtyToBeReceived")
	private boolean totalQtyToBeReceived;
	
	
	
	
	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public PurchaseOrderDetail() {
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public long getSuppliedBy() {
		return suppliedBy;
	}

	public void setSuppliedBy(long suppliedBy) {
		this.suppliedBy = suppliedBy;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public long getSerialNumber() {
		return serialNumber;
	}

	public String getTenderNumber() {
		return tenderNumber;
	}

	
	public Date getOpenedOnDate() {
		return openedOnDate;
	}

	

	public int getNumberOfIndents() {
		return numberOfIndents;
	}

	public long getIndentPoReqId() {
		return indentPoReqId;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	
	public int getVersion() {
		return version;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public void setSerialNumber(long serialNumber) {
		this.serialNumber = serialNumber;
	}

	public void setTenderNumber(String tenderNumber) {
		this.tenderNumber = tenderNumber;
	}

	
	public void setOpenedOnDate(Date openedOnDate) {
		this.openedOnDate = openedOnDate;
	}

	

	public void setNumberOfIndents(int numberOfIndents) {
		this.numberOfIndents = numberOfIndents;
	}

	public void setIndentPoReqId(long indentPoReqId) {
		this.indentPoReqId = indentPoReqId;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	
	public void setVersion(int version) {
		this.version = version;
	}

	public String getTenderType() {
		return tenderType;
	}

	public void setTenderType(String tenderType) {
		this.tenderType = tenderType;
	}

	
	
	
	
	public Date getImpDueDate() {
		return impDueDate;
	}

	public Date getOmcDueDate() {
		return omcDueDate;
	}

	public Date getIndDueDate() {
		return indDueDate;
	}

	public void setImpDueDate(Date impDueDate) {
		this.impDueDate = impDueDate;
	}

	public void setOmcDueDate(Date omcDueDate) {
		this.omcDueDate = omcDueDate;
	}

	public void setIndDueDate(Date indDueDate) {
		this.indDueDate = indDueDate;
	}

	
	
	
	public boolean isTotalQtyToBeReceived() {
		return totalQtyToBeReceived;
	}

	public void setTotalQtyToBeReceived(boolean totalQtyToBeReceived) {
		this.totalQtyToBeReceived = totalQtyToBeReceived;
	}

	@PrePersist
	void createdAt() {
		this.createdOn=this.lastUpdate = new Date();

	}

	@PreUpdate
	void updatedAt() {
		this.lastUpdate = new Date();
	}

	
	
	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "PurchaseOrderDetail [poNumber=" + poNumber + ", serialNumber=" + serialNumber + ", tenderNumber="
				+ tenderNumber + ", openedOnDate=" + openedOnDate + ", numberOfIndents=" + numberOfIndents
				+ ", indentPoReqId=" + indentPoReqId + ", suppliedBy=" + suppliedBy + ", tenderType=" + tenderType
				+ ", impDueDate=" + impDueDate + ", omcDueDate=" + omcDueDate + ", indDueDate=" + indDueDate
				+ ", createdOn=" + createdOn + ", createdBy=" + createdBy + ", lastUpdate=" + lastUpdate + ", version="
				+ version + ", totalQtyToBeReceived=" + totalQtyToBeReceived + "]";
	}

	
	
	
}