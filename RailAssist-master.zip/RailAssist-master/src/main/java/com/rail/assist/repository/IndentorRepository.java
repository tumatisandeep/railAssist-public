package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.Indentor;


public interface IndentorRepository extends JpaRepository<Indentor,Integer> {
	
	Indentor findByIndentorId(int id );
	
	
}



