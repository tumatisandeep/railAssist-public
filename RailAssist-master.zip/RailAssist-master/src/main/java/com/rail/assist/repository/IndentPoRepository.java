package com.rail.assist.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rail.assist.entities.IndentPoRelation;
import com.rail.assist.entities.IndentPoRelationPk;

public interface IndentPoRepository extends JpaRepository<IndentPoRelation, IndentPoRelationPk> {

	List<IndentPoRelation> findByItemId(long itemId);

	List<IndentPoRelation> findByIdPoIndentNumber(Long id);
	
	IndentPoRelation findByIdIndentIdAndPoNumber(long id,String po);

	//List<IndentPoRelation> findByItemIdAndIsTotalQtyReceived(long itemId, int qtyRceivedOrNot);

	IndentPoRelation findByPoNumber(String poNumber,long itemId);

	@Query(value = "select indentPo from IndentPoRelation indentPo where indentPo.itemId in (?1) and indentPo.qtyReceived>indentPo.qtyIssued")
	List<IndentPoRelation> findByItemsLeft(long itemId);

	Page<IndentPoRelation> findByItemId(long itemId, Pageable pageable);

	List<IndentPoRelation> findByIdIndentId(long indentId);

	
	@Query(value = "select indentPo from IndentPoRelation indentPo where indentPo.itemId in (?1) and indentPo.qtyReceived<indentPo.poReceivedQuantity")
	List<IndentPoRelation> outStandingPoData(long itemId,Pageable pageable);
	
	
	@Query("select indentPo from IndentPoRelation indentPo where indentPo.itemId in (?1) and indentPo.quantityIndented>indentPo.poReceivedQuantity")
	List<IndentPoRelation> poReceivedForAllItemsInIndent(long itemId);

	@Query("select indentPo from IndentPoRelation indentPo where indentPo.itemId in (?1) and indentPo.poReceivedQuantity>indentPo.qtyReceived")
	List<IndentPoRelation> getOutStandingPoDetails(long itemId);

	IndentPoRelation findByPoNumberAndItemId(String poNumber,long itemId);
	
	IndentPoRelation findByPoNumberAndItemIdAndIdIndentId(String poNumber,long itemId,long indentID);

	
	List<IndentPoRelation> findByDueDateGreaterThanEqualAndDueDateLessThanEqual(Date todyDate,Date nextMonthdate);
	
}
