package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the designation database table.
 * 
 */
@Entity
@NamedQuery(name="Designation.findAll", query="SELECT d FROM Designation d")
public class Designation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DESIGNATION_ID")
	private int designationId;

	@Column(name="DESIGNATION_DESC")
	private String designationDesc;

	@Column(name="DESIGNATION_VERSION")
	private int designationVersion;

	@Column(name="FIRST_INSERT")
	private int firstInsert;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_UPDATE")
	private Date lastUpdate;

	@Column(name="LAST_UPDATE_BY")
	private int lastUpdateBy;

	//bi-directional many-to-one association to UserDetail
	@OneToMany(mappedBy="designation")
	private List<UserDetail> userDetails;

	public Designation() {
	}

	public int getDesignationId() {
		return this.designationId;
	}

	public void setDesignationId(int designationId) {
		this.designationId = designationId;
	}

	public String getDesignationDesc() {
		return this.designationDesc;
	}

	public void setDesignationDesc(String designationDesc) {
		this.designationDesc = designationDesc;
	}

	public int getDesignationVersion() {
		return this.designationVersion;
	}

	public void setDesignationVersion(int designationVersion) {
		this.designationVersion = designationVersion;
	}

	public int getFirstInsert() {
		return this.firstInsert;
	}

	public void setFirstInsert(int firstInsert) {
		this.firstInsert = firstInsert;
	}

	public Date getLastUpdate() {
		return this.lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public int getLastUpdateBy() {
		return this.lastUpdateBy;
	}

	public void setLastUpdateBy(int lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}

	public List<UserDetail> getUserDetails() {
		return this.userDetails;
	}

	public void setUserDetails(List<UserDetail> userDetails) {
		this.userDetails = userDetails;
	}

	public UserDetail addUserDetail(UserDetail userDetail) {
		getUserDetails().add(userDetail);
		userDetail.setDesignation(this);

		return userDetail;
	}

	public UserDetail removeUserDetail(UserDetail userDetail) {
		getUserDetails().remove(userDetail);
		userDetail.setDesignation(null);

		return userDetail;
	}

}