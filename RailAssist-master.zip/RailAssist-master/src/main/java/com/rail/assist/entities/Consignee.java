package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the category database table.
 * 
 */
@Entity
@Table(name="consignee_data")
@NamedQuery(name="Consignee.findAll", query="SELECT c FROM Consignee c")
public class Consignee implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private int id;

	@Column(name="CONSIGNEE_CODE")
	private int consigneeId;

	@Column(name="CONSIGNEE_DESC")
	private String consigneeDesc;
	
	@Column(name="LAST_UPDATE")
	private Date lastUpdate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	

	public int getConsigneeId() {
		return consigneeId;
	}

	public void setConsigneeId(int consigneeId) {
		this.consigneeId = consigneeId;
	}

	public String getConsigneeDesc() {
		return consigneeDesc;
	}

	public void setConsigneeDesc(String consigneeDesc) {
		this.consigneeDesc = consigneeDesc;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	
}