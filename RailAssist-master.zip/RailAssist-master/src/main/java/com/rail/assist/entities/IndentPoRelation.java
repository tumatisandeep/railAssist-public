package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;


import java.util.Date;

/**
 * The persistent class for the purchase_order_details database table.
 * 
 */
@Entity
@Table(name = "INDENTS_PO_RELATION")
@NamedQuery(name = "IndentPoRelation.findAll", query = "SELECT p FROM IndentPoRelation p")
public class IndentPoRelation implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	
	@EmbeddedId
	private IndentPoRelationPk id;
	
	
	@Column(name = "ITEM_ID")
	private long itemId;
	
	
	@Column(name = "SERIAL_NUMBER")
	private long serialNumber;


	@Column(name = "PO_NUMBER")
	private String poNumber;

	@Column(name = "RATE_PURCHASED")
	private double ratePurchased;

	@Column(name = "GST")
	private double gst;

	@Column(name = "QUANTITY_INDENTED")
	private int quantityIndented;
	
	@Column(name = "QUANTITY_RECEIVED")
	private int qtyReceived;
	
	@Column(name = "QUANTITY_ISSUED")
	private int qtyIssued;
	
	/*@Column(name = "IS_TOTAL_QUANTITY_RECEIVED")
	private int isTotalQtyReceived;*/
		
	
	@Column(name = "ITEM_CATEGORY")
	private String itemCategory;
	

	@Column(name = "PO_RECEIVED_QUANTITY")
	private int poReceivedQuantity;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_UPDATE")
	private Date lastUpdate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_ON")
	private Date createdOn;

	@Column(name = "CREATED_BY")
	private long createdBy;
	
	@Column(name = "DUE_DATE")
	private Date dueDate;
	
	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	@Version
	private int version;
	
	
	
	public int getPoReceivedQuantity() {
		return poReceivedQuantity;
	}

	public void setPoReceivedQuantity(int poReceivedQuantity) {
		this.poReceivedQuantity = poReceivedQuantity;
	}

	/*public int getIsTotalQtyReceived() {
		return isTotalQtyReceived;
	}

	public void setIsTotalQtyReceived(int isTotalQtyReceived) {
		this.isTotalQtyReceived = isTotalQtyReceived;
	}
*/

	public IndentPoRelation() {
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

	public int getQtyReceived() {
		return qtyReceived;
	}

	public void setQtyReceived(int qtyReceived) {
		this.qtyReceived = qtyReceived;
	}

	public String getItemCategory() {
		return itemCategory;
	}

	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}

	public int getQtyIssued() {
		return qtyIssued;
	}

	public void setQtyIssued(int qtyIssued) {
		this.qtyIssued = qtyIssued;
	}

	public int getQuantityIndented() {
		return quantityIndented;
	}

	public void setQuantityIndented(int qty) {
		this.quantityIndented = qty;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long l) {
		this.itemId = l;
	}

	public double getGst() {
		return gst;
	}

	public void setGst(double gst) {
		this.gst = gst;
	}

	

	public long getSerialNumber() {
		return serialNumber;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public double getRatePurchased() {
		return ratePurchased;
	}

	public int getVersion() {
		return version;
	}

	

	public IndentPoRelationPk getId() {
		return id;
	}

	public void setId(IndentPoRelationPk id) {
		this.id = id;
	}

	public void setSerialNumber(long serialNumber) {
		this.serialNumber = serialNumber;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public void setRatePurchased(double ratePurchased) {
		this.ratePurchased = ratePurchased;
	}

	public void setVersion(int version) {
		this.version = version;
	}
	
	

	@PrePersist
	void createdAt() {
		this.lastUpdate=this.createdOn = new Date();

	}

	@PreUpdate
	void updatedAt() {
		this.lastUpdate = new Date();
	}


}