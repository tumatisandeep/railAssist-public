package com.rail.assist.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rail.assist.entities.MaterialIssueData;

public interface MaterialsIssueDataRepository extends JpaRepository<MaterialIssueData, Integer> {

	MaterialIssueData findByChallanNumber(String challanId);

	MaterialIssueData findByMaterialIssueId(long challanId);

	MaterialIssueData findByUniqueRelationNo(long id);

	@Query("from MaterialIssueData m where trunc(m.createdOn)=TO_DATE(?1,'dd-MM-yyyy')")
	List<MaterialIssueData> findByCreatedOnFunction(String format);

	List<MaterialIssueData> findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(Date todayDateObj,
			Date nextDayDateObj);

	long countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(Date startDateMonth1, Date endDateMonth1);

	/**
	 * @param userId
	 * @param dateF
	 * @param dateT
	 * @return
	 */
	List<MaterialIssueData> findByCreatedByAndCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(long userId,
			Date dateF, Date dateT);

	List<MaterialIssueData> findByCreatedBy(long userId);

}
