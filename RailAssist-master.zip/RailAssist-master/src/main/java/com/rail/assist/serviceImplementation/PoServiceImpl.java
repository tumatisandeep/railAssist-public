package com.rail.assist.serviceImplementation;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rail.assist.config.CurrentUser;
import com.rail.assist.constants.AssistConstantsParameters;
import com.rail.assist.dto.IndentDataInfoDto;
import com.rail.assist.dto.PoDtoHome;
import com.rail.assist.entities.IndentDetail;
import com.rail.assist.entities.IndentPoRelation;
import com.rail.assist.entities.IndentPoRelationPk;
import com.rail.assist.entities.PurchaseOrderDetail;
import com.rail.assist.entities.UserDetail;
import com.rail.assist.repository.IndentDetailRepository;
import com.rail.assist.repository.IndentPoRepository;
import com.rail.assist.repository.ItemsDataRepository;
import com.rail.assist.repository.PoDetailRepository;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.repository.VendorsDataRepository;
import com.rail.assist.service.PoService;

@Service

public class PoServiceImpl implements PoService {

	@Autowired
	CurrentUser currentUser;

	@Autowired
	IndentDetailRepository indentDetailRepository;

	@Autowired
	PoDetailRepository poDetailRepository;

	@Autowired
	IndentPoRepository indentPoRepository;

	@Autowired
	ItemsDataRepository itemsDataRepository;

	@Autowired
	VendorsDataRepository vendorsDataRepository;

	@Autowired
	UserDetailsRepository userDetailsRepository;

	public PoDtoHome showPo(long serialNo) throws Exception {

		try {
			PoDtoHome poDto = new PoDtoHome();

			PurchaseOrderDetail poDetails = poDetailRepository.findBySerialNumber(serialNo);
			//System.out.println(poDetails.getPoNumber());
			DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");

			poDto.setNumberOfIndents(poDetails.getNumberOfIndents());

			poDto.setPoNo(poDetails.getPoNumber());

			poDto.setSerialNo(poDetails.getSerialNumber());

			poDto.setTitle("Purchase order " + poDetails.getPoNumber() + " is issued for " + poDetails.getNumberOfIndents()+" indent "
					+ " on " + dateFormatter
							.format(poDetails.getOpenedOnDate() )+ " with respective due dates.");

			poDto.setSupliedBy(vendorsDataRepository.findById(poDetails.getSuppliedBy()).getSupplierDesc());

			UserDetail user = userDetailsRepository.findByUserId(poDetails.getCreatedBy());
			poDto.setLoggedBy(user.getUserFirstName() + " " + user.getUserLastName());

			//IndentDataInfoDto indentDto = new IndentDataInfoDto();

			List<IndentPoRelation> indentDataList = indentPoRepository
					.findByIdPoIndentNumber((poDetails.getIndentPoReqId()));

			List<IndentDataInfoDto> allIndentsInPo = new ArrayList<>();

			for (IndentPoRelation indentDataInfoDto : indentDataList) {

				IndentDataInfoDto indentData = new IndentDataInfoDto();

				indentData.setIndentId(Long.valueOf(indentDataInfoDto.getId().getIndentId()));
				indentData.setIndentDate(indentDataInfoDto.getCreatedOn());
				indentData.setItemId(indentDataInfoDto.getItemId());

				allIndentsInPo.add(indentData);
			}

			poDto.setIndentsList(allIndentsInPo);

			poDto.setTendorNumber(poDetails.getTenderNumber());
			poDto.setDate(poDetails.getOpenedOnDate());
			poDto.setTenderType(poDetails.getTenderType());
			poDto.setLoggedDate(poDetails.getCreatedOn());
			//poDto.setLoggedBy(userDetailsRepository.findByUserId(poDetails.getCreatedBy()).getUserFirstName());
			return poDto;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	@Override
	public PoDtoHome showPo(String poNum) throws Exception {

		try {
			PoDtoHome poDto = new PoDtoHome();
			DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");

			PurchaseOrderDetail poDetails = poDetailRepository.findByPoNumber(poNum);
			if(poDetails!=null) {
			//System.out.println(poDetails.getPoNumber());

			poDto.setNumberOfIndents(poDetails.getNumberOfIndents());

			poDto.setPoNo(poDetails.getPoNumber());

			poDto.setSerialNo(poDetails.getSerialNumber());

			poDto.setTitle("Purchase order " + poDetails.getPoNumber() + " is issued for " + poDetails.getNumberOfIndents()+" indent "
					+ " on" + dateFormatter
							.format(poDetails.getOpenedOnDate() )+ " with respective due dates.");
			poDto.setSupliedBy(vendorsDataRepository.findById(poDetails.getSuppliedBy()).getSupplierDesc());

			UserDetail user = userDetailsRepository.findByUserId(poDetails.getCreatedBy());
			poDto.setLoggedBy(user.getUserFirstName() + " " + user.getUserLastName());

			// IndentDataInfoDto indentDto =new IndentDataInfoDto();

			List<IndentPoRelation> indentDataList = indentPoRepository
					.findByIdPoIndentNumber((poDetails.getIndentPoReqId()));

			List<IndentDataInfoDto> allIndentsInPo = new ArrayList<>();

			for (IndentPoRelation indentDataInfoDto : indentDataList) {

				IndentDataInfoDto indentData = new IndentDataInfoDto();

				indentData.setIndentId(Long.valueOf(indentDataInfoDto.getId().getIndentId()));
				indentData.setIndentDate(indentDataInfoDto.getCreatedOn());
				indentData.setItemId(indentDataInfoDto.getItemId());

				allIndentsInPo.add(indentData);
			}

			poDto.setIndentsList(allIndentsInPo);

			poDto.setTenderType(poDetails.getTenderType());
			poDto.setTendorNumber(poDetails.getTenderNumber());
			poDto.setDate(poDetails.getOpenedOnDate());
			poDto.setLoggedDate(poDetails.getCreatedOn());
			//	poDto.setLoggedBy(userDetailsRepository.findByUserId(poDetails.getCreatedBy()).getUserFirstName());
			poDto.setPoFound(true);
			}
			
			else {
				poDto.setPoFound(false);
			}
			return poDto;
		} catch (Exception e) {
			
			e.printStackTrace();
			
			throw e;
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.rail.assist.service.PoService#addPo(com.rail.assist.entities.
	 * PurchaseOrderDetail)
	 */
	@Override
	@Transactional(rollbackFor=Throwable.class)
	public boolean addPo(JSONArray poFormData) throws JSONException, ParseException {

		try {

			Date dateObj=new Date();
			
			//System.out.println(poFormData.getJSONArray(4));

			PurchaseOrderDetail poData = new PurchaseOrderDetail();

			poData.setPoNumber(poFormData.getString(0));

			poData.setTenderType(poFormData.getString(1));

			poData.setTenderNumber(poFormData.getString(0)); // Make a substring
																// of PO. should
																// be changed

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX");

			Date openedData = dateFormat.parse(poFormData.getString(2));

			poData.setSerialNumber(poFormData.getLong(3));

			poData.setOpenedOnDate(openedData);

			//System.out.println(poData.getOpenedOnDate());

			poData.setSuppliedBy(poFormData.getInt(5));

			// Date date = dateFormat.parse(poFormData.getString(5));

			// poData.setDate(date);

			// poData.setSupplierData(1);// to be changed

			poData.setImpDueDate(dateFormat.parse(poFormData.getString(6)));

			poData.setIndDueDate(dateFormat.parse(poFormData.getString(7)));

			poData.setOmcDueDate(dateFormat.parse(poFormData.getString(8)));

			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("yyMMddhhmmssMs");
			String indentPOReqId = ft.format(dNow);

			int numberOfIndents = 0;
			//System.out.println(poFormData.getJSONArray(4).length() + "length.......");
			for (int i = 0; i < poFormData.getJSONArray(4).length(); i++) {

				IndentPoRelation indentPo = new IndentPoRelation();

				IndentPoRelationPk pkObj = new IndentPoRelationPk();

				pkObj.setIndentId(Long.valueOf(poFormData.getJSONArray(4).getJSONObject(i).get("indentId").toString()));

				pkObj.setPoIndentNumber(Long.valueOf(indentPOReqId));

				// indentPo.setPoIndentNumber(Long.valueOf(indentPOReqId));

				// indentPo.setIndentId(Long.valueOf(poFormData.getJSONArray(4).getJSONObject(i).get("indentId").toString()));

				indentPo.setId(pkObj);

				indentPo.setCreatedBy(currentUser.getCurrentUser().getUserId());

				indentPo.setPoNumber(poFormData.getString(0));

				indentPo.setRatePurchased(
						Double.parseDouble(poFormData.getJSONArray(4).getJSONObject(i).get("price").toString()));

				indentPo.setSerialNumber(poFormData.getLong(3));

				indentPo.setGst(Double.valueOf(poFormData.getJSONArray(4).getJSONObject(i).get("gst").toString()));

				IndentDetail indentDataOfItem = indentDetailRepository.findByIndentId(
						Long.valueOf(poFormData.getJSONArray(4).getJSONObject(i).get("indentId").toString()));
				
				indentPo.setItemId(indentDataOfItem.getItemId());

				indentPo.setQuantityIndented((int) indentDataOfItem.getQuantityReq()); // quantity
																						// indented

				indentPo.setQtyReceived(AssistConstantsParameters.NO_ITEMS_RECEIVED); // as
																						// no
																						// items
																						// are
																						// received
																						// yet,
																						// this
																						// will
																						// be
																						// updated
																						// once
																						// item
																						// is
																						// received
				
				

				indentPo.setQtyIssued(AssistConstantsParameters.NO_ITEMS_ISSUED);
			

				if (Integer.valueOf(poFormData.getJSONArray(4).getJSONObject(i).get("itemCategory")
						.toString()) == AssistConstantsParameters.INDENT_ITEM_CATEGORY_IMP) {
					indentPo.setItemCategory("IMP");
					indentPo.setDueDate(dateFormat.parse(poFormData.getString(6)));
				}
				else if (Integer.valueOf(poFormData.getJSONArray(4).getJSONObject(i).get("itemCategory")
						.toString()) == AssistConstantsParameters.INDENT_ITEM_CATEGORY_IND) {
					indentPo.setItemCategory("IND");
					indentPo.setDueDate(dateFormat.parse(poFormData.getString(7)));
				}

				else if (Integer.valueOf(poFormData.getJSONArray(4).getJSONObject(i).get("itemCategory")
						.toString()) == AssistConstantsParameters.INDENT_ITEM_CATEGORY_OMC) {
					indentPo.setItemCategory("OMC");
					indentPo.setDueDate(dateFormat.parse(poFormData.getString(8)));
				}
				// indentPo.setIsTotalQtyReceived(AssistConstantsParameters.PARTIAL_QUANTITY_RECEIVED_FOR_INDNET_IN_PO);

				indentPo.setPoReceivedQuantity(
						Integer.valueOf(poFormData.getJSONArray(4).getJSONObject(i).get("qtyReceived").toString()));

				indentPo.setCreatedOn(dateObj);
				
				
				indentPoRepository.saveAndFlush(indentPo);

				// updated in indent data when po is released for that indent

				IndentDetail indentData = indentDetailRepository.findByIndentId(
						Long.valueOf(poFormData.getJSONArray(4).getJSONObject(i).get("indentId").toString()));

				indentData.setPoQuantityRcvd(indentData.getPoQuantityRcvd()
						+ Integer.valueOf(poFormData.getJSONArray(4).getJSONObject(i).get("qtyReceived").toString()));
				
			//	indentData.setO

				/*
				 * if(indentData.getPoQuantityRcvd()==indentData.getQuantityReq(
				 * )) indentData.setPoReceived(AssistConstantsParameters.
				 * PO_RECEIVED_FOR_INDENT);
				 */

				// indentData.setPoDate(new Date());
				
				

				indentDetailRepository.save(indentData);

				numberOfIndents++;

			}

			poData.setNumberOfIndents(numberOfIndents);

			//System.out.println(Long.valueOf(indentPOReqId));
			
			poData.setIndentPoReqId(Long.valueOf(indentPOReqId));

			poData.setCreatedBy((int) currentUser.getCurrentUser().getUserId());
			
			poData.setUpdatedBy((int) currentUser.getCurrentUser().getUserId());
			poData.setCreatedOn(dateObj);
			
			//int j=1/0;
			poDetailRepository.save(poData);

			//System.out.println("11111111");

			return true;

		} catch (Exception e) {
			
			e.printStackTrace();
			
			//System.out.println("inside exceptions");

			throw e;
			// return false;
		}

	}

}
