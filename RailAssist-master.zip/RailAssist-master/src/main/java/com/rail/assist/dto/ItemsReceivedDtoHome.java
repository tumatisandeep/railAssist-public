package com.rail.assist.dto;

import java.util.Date;

public class ItemsReceivedDtoHome {
	
	private long id;
	
	private long itemId;
	
	private long indentId;
	
	private String poNumber;
	
	private int receivedWithIndentOrPo;
	
	private Date receivedOn;
	
	private int numberOfItemsReceived;
	
	private String loggedBy;
	
	private String title;
	
	private String desc;
	
	

	public long getId() {
		return id;
	}

	public void setId(long l) {
		this.id = l;
	}

	public String getTitle() {
		return title;
	}

	public String getDesc() {
		return desc;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getLoggedBy() {
		return loggedBy;
	}

	public void setLoggedBy(String string) {
		this.loggedBy = string;
	}

	public long getItemId() {
		return itemId;
	}

	public long getIndentId() {
		return indentId;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public int getReceivedWithIndentOrPo() {
		return receivedWithIndentOrPo;
	}

	public Date getReceivedOn() {
		return receivedOn;
	}

	public int getNumberOfItemsReceived() {
		return numberOfItemsReceived;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public void setIndentId(long indentId) {
		this.indentId = indentId;
	}

	public void setPoNumber(String string) {
		this.poNumber = string;
	}

	public void setReceivedWithIndentOrPo(int receivedWithIndentOrPo) {
		this.receivedWithIndentOrPo = receivedWithIndentOrPo;
	}

	public void setReceivedOn(Date receivedOn) {
		this.receivedOn = receivedOn;
	}

	public void setNumberOfItemsReceived(int numberOfItemsReceived) {
		this.numberOfItemsReceived = numberOfItemsReceived;
	}
	
	
	
	
	
	

}
