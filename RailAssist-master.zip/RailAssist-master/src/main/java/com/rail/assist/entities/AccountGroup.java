package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the account_groups database table.
 * 
 */
@Entity
@Table(name="account_groups")
@NamedQuery(name="AccountGroup.findAll", query="SELECT a FROM AccountGroup a")
public class AccountGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ACCOUNT_GROUPS_ID")
	private int accountGroupsId;

	@Column(name="ACCOUNT_GROUPS_DESC")
	private String accountGroupsDesc;

	private int version;

	public AccountGroup() {
	}

	public int getAccountGroupsId() {
		return this.accountGroupsId;
	}

	public void setAccountGroupsId(int accountGroupsId) {
		this.accountGroupsId = accountGroupsId;
	}

	public String getAccountGroupsDesc() {
		return this.accountGroupsDesc;
	}

	public void setAccountGroupsDesc(String accountGroupsDesc) {
		this.accountGroupsDesc = accountGroupsDesc;
	}

	public int getVersion() {
		return this.version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

}