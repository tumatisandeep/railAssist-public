package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.Depot;


public interface DepotRepository extends JpaRepository<Depot,Integer> {
	
	Depot findByDepotId(int id);
	
}



