package com.rail.assist.dto;

public class PreviewDtoStrings {

    private String po1Data;
	
    private String po2Data;
	
    private String po3Data;
	
    private String po4Data;
	
    private String description;
	
    private String purpose;
	
    private String lastPurchaseDetails;
	
    private String allocation;
	
    private String units;
    
    private String controlingOfficer;
	
	

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getPo1Data() {
		return po1Data;
	}

	public String getPo2Data() {
		return po2Data;
	}

	public String getPo3Data() {
		return po3Data;
	}

	public String getPo4Data() {
		return po4Data;
	}

	public void setPo1Data(String po1Data) {
		this.po1Data = po1Data;
	}

	public void setPo2Data(String po2Data) {
		this.po2Data = po2Data;
	}

	public void setPo3Data(String po3Data) {
		this.po3Data = po3Data;
	}

	public void setPo4Data(String po4Data) {
		this.po4Data = po4Data;
	}

	public String getDescription() {
		return description;
	}

	public String getPurpose() {
		return purpose;
	}

	public String getLastPurchaseDetails() {
		return lastPurchaseDetails;
	}

	public String getAllocation() {
		return allocation;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public void setLastPurchaseDetails(String lastPurchaseDetails) {
		this.lastPurchaseDetails = lastPurchaseDetails;
	}

	public void setAllocation(String allocation) {
		this.allocation = allocation;
	}

	public String getControlingOfficer() {
		return controlingOfficer;
	}

	public void setControlingOfficer(String controlingOfficer) {
		this.controlingOfficer = controlingOfficer;
	}
	
	
	
	
}
