package com.rail.assist.dto;

import java.util.Date;

public class ItemsDataDto {
	
	private long indentNumber;
	
	private String desc;
	
	private String partNumber;
	
	private int Qty;
	
	private int qtyRcvd;
	
	private long idNo;
	
	private String category;
	
	private Date dateIndented;

	private boolean poReceived;
	
	private boolean isNull;

	public long getIndentNumber() {
		return indentNumber;
	}

	public String getDesc() {
		return desc;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public int getQty() {
		return Qty;
	}

	public int getQtyRcvd() {
		return qtyRcvd;
	}

	public long getIdNo() {
		return idNo;
	}

	public String getCategory() {
		return category;
	}

	public Date getDateIndented() {
		return dateIndented;
	}

	public boolean isPoReceived() {
		return poReceived;
	}

	public boolean isNull() {
		return isNull;
	}

	public void setIndentNumber(long indentNumber) {
		this.indentNumber = indentNumber;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public void setQty(int qty) {
		Qty = qty;
	}

	public void setQtyRcvd(int qtyRcvd) {
		this.qtyRcvd = qtyRcvd;
	}

	public void setIdNo(long idNo) {
		this.idNo = idNo;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setDateIndented(Date dateIndented) {
		this.dateIndented = dateIndented;
	}

	public void setPoReceived(boolean poReceived) {
		this.poReceived = poReceived;
	}

	public void setNull(boolean isNull) {
		this.isNull = isNull;
	}

	
	

}
