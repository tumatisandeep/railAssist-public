package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the category database table.
 * 
 */
@Entity
@Table(name="depot")
@NamedQuery(name="Depot.findAll", query="SELECT c FROM Depot c")
public class Depot implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private int id;

	@Column(name="DEPOT_ID")
	private int depotId;

	@Column(name="DEPOT_DESC")
	private String depotDesc;
	
	@Column(name="LAST_UPDATE")
	private Date lastUpdate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public int getDepotId() {
		return depotId;
	}

	public void setDepotId(int depotId) {
		this.depotId = depotId;
	}

	public String getDepotDesc() {
		return depotDesc;
	}

	public void setDepotDesc(String depotDesc) {
		this.depotDesc = depotDesc;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	
	
}