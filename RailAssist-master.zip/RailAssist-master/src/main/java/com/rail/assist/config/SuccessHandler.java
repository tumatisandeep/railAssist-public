package com.rail.assist.config;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;

public class SuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {

	
	private String defaultTargetUrl;
    public SuccessHandler(String defaultTargetUrl) {
    	//System.out.println("default url "+defaultTargetUrl);
        setDefaultTargetUrl(defaultTargetUrl);
        this.defaultTargetUrl=defaultTargetUrl;
    }

	
	
	public SuccessHandler() {
		// TODO Auto-generated constructor stub
	}



	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		
		//super.onAuthenticationSuccess(request, response, authentication);

			
		HttpSession session = request.getSession();
        if (session != null) {
            String redirectUrl = (String) session.getAttribute("url_prior_login");
            
           // System.out.println(authentication.isAuthenticated());
            //System.out.println("redirect Url ouside loop "+redirectUrl);

            if (redirectUrl!=null) {
               // System.out.println("redirect Url is "+redirectUrl);

                // we do not forget to clean this attribute from session
                session.removeAttribute("url_prior_login");
                // then we redirect
                getRedirectStrategy().sendRedirect(request, response, redirectUrl);
            } else {
                super.onAuthenticationSuccess(request, response, authentication);
            }
        } else {
        	
        	//System.out.println("redirect Url is NULL ");
            super.onAuthenticationSuccess(request, response, authentication);
        }
		
	}

}
