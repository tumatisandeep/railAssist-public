package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the user_login_status database table.
 * 
 */
@Entity
@Table(name="user_login_status")
@NamedQuery(name="UserLoginStatus.findAll", query="SELECT u FROM UserLoginStatus u")
public class UserLoginStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="USER_LOGIN_STATUS_ID")
	private int userLoginStatusId;

	@Column(name="USER_LOGIN_STATUS_DESC")
	private String userLoginStatusDesc;

	//bi-directional many-to-one association to UserDetail
	@OneToMany(mappedBy="userLoginStatusBean")
	private List<UserDetail> userDetails;

	public UserLoginStatus() {
	}

	public int getUserLoginStatusId() {
		return this.userLoginStatusId;
	}

	public void setUserLoginStatusId(int userLoginStatusId) {
		this.userLoginStatusId = userLoginStatusId;
	}

	public String getUserLoginStatusDesc() {
		return this.userLoginStatusDesc;
	}

	public void setUserLoginStatusDesc(String userLoginStatusDesc) {
		this.userLoginStatusDesc = userLoginStatusDesc;
	}

	public List<UserDetail> getUserDetails() {
		return this.userDetails;
	}

	public void setUserDetails(List<UserDetail> userDetails) {
		this.userDetails = userDetails;
	}

	public UserDetail addUserDetail(UserDetail userDetail) {
		getUserDetails().add(userDetail);
		userDetail.setUserLoginStatusBean(this);

		return userDetail;
	}

	public UserDetail removeUserDetail(UserDetail userDetail) {
		getUserDetails().remove(userDetail);
		userDetail.setUserLoginStatusBean(null);

		return userDetail;
	}

}