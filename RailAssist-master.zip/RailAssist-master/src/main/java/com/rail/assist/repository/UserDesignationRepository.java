package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.Designation;


public interface UserDesignationRepository extends JpaRepository<Designation,Long> {
	

}



