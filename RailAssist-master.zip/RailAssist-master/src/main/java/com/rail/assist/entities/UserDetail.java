package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the user_details database table.
 * 
 */
@Entity
@Table(name="user_details")
@NamedQuery(name="UserDetail.findAll", query="SELECT u FROM UserDetail u")
public class UserDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="USER_DETAILS_ID")
	private int userDetailsId;

	@Column(name="USER_ID")
	private Long userId;

	@Column(name="USER_PLINK")
	private String userPlink;
	
	
	

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_UPDATE")
	private Date lastUpdate;
	
	@Column(name="USER_TYPE")
	private int  userType;
	
	
	public int getUserType() {
		return userType;
	}

	public void setUserType(int userType) {
		this.userType = userType;
	}

	@Column(name="USER_ADDRESS")
	private String userAddress;

	@Column(name="USER_ALT_MOBILE")
	private Long userAltMobile;

	@Version
	@Column(name="USER_DETAILS_VERSION")
	private int userDetailsVersion;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="USER_DOB")
	private Date userDob;

	@Column(name="USER_FIRST_NAME")
	private String userFirstName;

	@Column(name="USER_LAST_NAME")
	private String userLastName;

	@Column(name="USER_MAIL_ID")
	private String userMailId;

	@Column(name="USER_MOBILE")
	private Long userMobile;

	@Column(name="USER_PASSWORD")
	private String userPassword;

	@Column(name="USER_WORK_LOCATION")
	private String userWorkLocation;

	//bi-directional many-to-one association to Gender
	@ManyToOne
	@JoinColumn(name="USER_GENDER")
	private Gender gender;

	//bi-directional many-to-one association to UserAccountStatus
	@ManyToOne
	@JoinColumn(name="USER_ACCOUNT_STATUS")
	private UserAccountStatus userAccountStatusBean;

	//bi-directional many-to-one association to UserLoginStatus
	@ManyToOne
	@JoinColumn(name="USER_LOGIN_STATUS")
	private UserLoginStatus userLoginStatusBean;

	//bi-directional many-to-one association to Designation
	@ManyToOne
	@JoinColumn(name="USER_DESIGNATION")
	private Designation designation;

	
	
	public String getUserPlink() {
		return userPlink;
	}

	public void setUserPlink(String userPlink) {
		this.userPlink = userPlink;
	}
	
	public int getUserDetailsId() {
		return userDetailsId;
	}

	public void setUserDetailsId(int userDetailsId) {
		this.userDetailsId = userDetailsId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(Long long1) {
		this.userId = long1;
	}
	
	
	public UserDetail() {
	}

	

	public Date getLastUpdate() {
		return this.lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public String getUserAddress() {
		return this.userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public Long getUserAltMobile() {
		return this.userAltMobile;
	}

	public void setUserAltMobile(Long long1) {
		this.userAltMobile = long1;
	}

	public int getUserDetailsVersion() {
		return this.userDetailsVersion;
	}

	public void setUserDetailsVersion(int userDetailsVersion) {
		this.userDetailsVersion = userDetailsVersion;
	}

	public Date getUserDob() {
		return this.userDob;
	}

	public void setUserDob(Date userDob) {
		this.userDob = userDob;
	}

	public String getUserFirstName() {
		return this.userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return this.userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getUserMailId() {
		return this.userMailId;
	}

	public void setUserMailId(String userMailId) {
		this.userMailId = userMailId;
	}

	public long getUserMobile() {
		return this.userMobile;
	}

	public void setUserMobile(Long long1) {
		this.userMobile = long1;
	}

	public String getUserPassword() {
		return this.userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserWorkLocation() {
		return this.userWorkLocation;
	}

	public void setUserWorkLocation(String userWorkLocation) {
		this.userWorkLocation = userWorkLocation;
	}

	public Gender getGender() {
		return this.gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public UserAccountStatus getUserAccountStatusBean() {
		return this.userAccountStatusBean;
	}

	public void setUserAccountStatusBean(UserAccountStatus userAccountStatusBean) {
		this.userAccountStatusBean = userAccountStatusBean;
	}

	public UserLoginStatus getUserLoginStatusBean() {
		return this.userLoginStatusBean;
	}

	public void setUserLoginStatusBean(UserLoginStatus userLoginStatusBean) {
		this.userLoginStatusBean = userLoginStatusBean;
	}

	public Designation getDesignation() {
		return this.designation;
	}

	public void setDesignation(Designation designation) {
		this.designation = designation;
	}
	
	/*@PrePersist
	void createdAt() {
		 this.lastUpdate = new Date();
	}

	@PreUpdate
	void updatedAt() {
		this.lastUpdate = new Date();
	}*/

}