package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the category database table.
 * 
 */
@Entity
@Table(name="acceptable_make")
@NamedQuery(name="AcceptableMake.findAll", query="SELECT c FROM AcceptableMake c")
public class AcceptableMake implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private int id;

	@Column(name="ACCEPTABLE_MAKE_ID")
	private int acceptableMakeid;

	

	@Column(name="ACCEPTABLE_MAKE_DESC")
	private String acceptableMakeDesc;
	
	@Column(name="LAST_UPDATE")
	private Date lastUpdate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setAcceptableMakeid(int acceptableMakeid) {
		this.acceptableMakeid = acceptableMakeid;
	}

	public void setacceptableMakeDesc(String acceptableMakeDesc) {
		this.acceptableMakeDesc = acceptableMakeDesc;
	}

	public int getAcceptableMakeid() {
		return acceptableMakeid;
	}

	public String getacceptableMakeDesc() {
		return acceptableMakeDesc;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	
}