package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.UserLoginStatus;


public interface UserLoginStatusRepository extends JpaRepository<UserLoginStatus,Long> {
	
	UserLoginStatus findByUserLoginStatusId(int id);
	

}



