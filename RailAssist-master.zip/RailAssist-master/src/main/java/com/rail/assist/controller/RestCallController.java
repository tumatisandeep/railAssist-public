package com.rail.assist.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rail.assist.config.CurrentUser;
import com.rail.assist.constants.AssistConstants;
import com.rail.assist.constants.AssistConstantsParameters;
import com.rail.assist.dto.AllDataDto;
import com.rail.assist.dto.ChallanTableDto;
import com.rail.assist.dto.IndentDataDto;
import com.rail.assist.dto.IndentDataInfoDto;
import com.rail.assist.dto.IndentTableDto;
import com.rail.assist.dto.ItemsDataDto;
import com.rail.assist.dto.ItemsDto;
import com.rail.assist.dto.ItemsGroupWiseData;
import com.rail.assist.dto.ItemsIssuedDataDto;
import com.rail.assist.dto.ItemsIssuedDtoHome;
import com.rail.assist.dto.ItemsReceivedDtoHome;
import com.rail.assist.dto.ItemsSubCategory;
import com.rail.assist.dto.ItemsWithPoDto;
import com.rail.assist.dto.PoDtoHome;
import com.rail.assist.dto.PoTableDto;
import com.rail.assist.entities.Category;
import com.rail.assist.entities.GroupDetails;
import com.rail.assist.entities.IndentDetail;
import com.rail.assist.entities.IndentPoRelation;
import com.rail.assist.entities.IndentSerialNumber;
import com.rail.assist.entities.ItemsData;
import com.rail.assist.entities.MaterialIssueData;
import com.rail.assist.entities.MaterialsIssueRelation;
import com.rail.assist.entities.MaterialsReceivedData;
import com.rail.assist.entities.PurchaseOrderDetail;
import com.rail.assist.entities.StockAvailable;
import com.rail.assist.entities.UserDetail;
import com.rail.assist.entities.VendorsData;
import com.rail.assist.repository.CategoryRepository;
import com.rail.assist.repository.GroupDetailRepository;
import com.rail.assist.repository.IndentDetailRepository;
import com.rail.assist.repository.IndentPoRepository;
import com.rail.assist.repository.IndentSerialNumberRepository;
import com.rail.assist.repository.ItemsDataRepository;
import com.rail.assist.repository.MaterialsIssueDataRepository;
import com.rail.assist.repository.MaterialsIssueRelationRepository;
import com.rail.assist.repository.MaterialsReceivedDataRepository;
import com.rail.assist.repository.PoDetailRepository;
import com.rail.assist.repository.StockAvailableRepository;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.repository.VendorsDataRepository;
import com.rail.assist.service.AllDataService;
import com.rail.assist.service.HomeService;
import com.rail.assist.service.ItemsService;

@RestController
public class RestCallController {

	@Autowired
	ItemsDataRepository itemsDataRepository;

	@Autowired
	IndentDetailRepository indentDetailRepository;

	@Autowired
	PoDetailRepository poDetailRepository;

	@Autowired
	StockAvailableRepository stockAvailableRepository;

	@Autowired
	IndentPoRepository indentPoRepository;

	@Autowired
	VendorsDataRepository vendorsDataRepository;

	@Autowired
	CurrentUser currentUser;

	@Autowired
	MaterialsIssueDataRepository materialsIssueDataRepository;

	@Autowired
	MaterialsReceivedDataRepository materialsReceivedDataRepository;

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	MaterialsIssueRelationRepository materialsIssueRelationRepository;

	@Autowired
	ItemsService itemsService;

	@Autowired
	GroupDetailRepository groupDetailRepository;

	@Autowired
	AssistConstants assistConstants;

	@Autowired
	UserDetailsRepository userDetailsRepository;

	@Autowired
	private HomeService homeService;

	@Autowired
	private AllDataService allDataService;

	@Autowired
	private IndentSerialNumberRepository indentSerialNumberRepository;
	
	@RequestMapping("/getItemsData")
	public List<ItemsDto> getItemsData(@RequestParam(value = "catId") Integer catId,
			@RequestParam(value = "indentType") Integer indentType) {

		List<ItemsData> itemsData = new ArrayList<>();
		//System.out.println(indentType + "    " + catId);
		if (indentType == 2)
			itemsData = itemsDataRepository.findByGroupId(catId);
		else if (indentType == 1) {
			//System.out.println("Get Data for RC indent");
			itemsData = itemsDataRepository.findByGroupId(catId);

		}
		// get data for RC indent

		List<ItemsDto> itemsDto = new ArrayList<>();
		for (ItemsData itemsData2 : itemsData) {

			ItemsDto itemsDtoObj = new ItemsDto();

			itemsDtoObj.setDescription(itemsData2.getDescription());
			itemsDtoObj.setId(itemsData2.getId());
			itemsDtoObj.setItemId(itemsData2.getItemId());
			itemsDtoObj.setPartNumber(itemsData2.getPartNumber());

			itemsDto.add(itemsDtoObj);
		}
		
		itemsDto=	itemsDto.parallelStream().sorted(Comparator.comparing(ItemsDto::getItemId)).collect(Collectors.toList());

		return itemsDto;

	}

	
	@RequestMapping("/getAutogeneratedIndentNumber")
	public String getAutogeneratedIndentNumber(@RequestParam(value = "financialYear") String financialYear,
			@RequestParam(value = "itemId") Long itemId) {

	//		String indentNumber = new String();
		// IndentDetail recentIndentForType=indentDetailRepository.

		IndentSerialNumber serialNumber = indentSerialNumberRepository.findByFinancialYearAndItemType(financialYear,
				Long.valueOf(String.valueOf(itemId).substring(0, 1)));

		if (serialNumber == null) {

			
			IndentSerialNumber i = new IndentSerialNumber();
			i.setItemType(Integer.valueOf(String.valueOf(itemId).substring(0, 1)));
			i.setFinancialYear(financialYear);
			i.setSerialNumber(1); // as this is first entry

			return financialYear.substring(2, 4) + String.valueOf(itemId).substring(0, 2) + "01";
		}

		//serialNumber.setSerialNumber(serialNumber.getSerialNumber()+1);
		
		//indentSerialNumberRepository.save(serialNumber);
			
		String serialString=String.valueOf(serialNumber.getSerialNumber()+1);
		
		
		if(serialString.length()>=2)
		return financialYear.substring(2,4)+String.valueOf(itemId).substring(0, 2)+serialString;
		else
			return financialYear.substring(2,4)+String.valueOf(itemId).substring(0, 2)+"0"+serialString;

	}

	
	@RequestMapping("/getIndentData/{indentId}")
	public ItemsDataDto getIndentData(@PathVariable long indentId) {
		IndentDetail indentData = indentDetailRepository.findByIndentId(indentId);
		//System.out.println(indentData);

		if (indentData == null) {
			//System.out.println("11111");
			// PoDataDto poDto = new PoDataDto();
			ItemsDataDto itemDataDto = new ItemsDataDto();

			itemDataDto.setNull(true);
		//	System.out.println(itemDataDto.isNull());
			return itemDataDto;

		}

		if (indentData.getQuantityReq() == indentData.getPoQuantityRcvd()) {
			ItemsDataDto itemDataDto = new ItemsDataDto();

			// PoDataDto poDto = new PoDataDto();
			itemDataDto.setPoReceived(true);
			return itemDataDto;
		} else {

			ItemsData itemData = itemsDataRepository.findByItemId(indentData.getItemId());
			// PoDataDto poDto = new PoDataDto();

			ItemsDataDto itemDataDto = new ItemsDataDto();

			// itemDataDto.setRcNo(111); // to be chnaged
			itemDataDto.setIndentNumber(indentData.getIndentId());
			itemDataDto.setIdNo(itemData.getItemId());
			itemDataDto.setDesc(itemData.getDescription());
			itemDataDto.setPartNumber(itemData.getPartNumber());
			itemDataDto.setQty((int) indentData.getQuantityReq());
			itemDataDto.setCategory(categoryRepository.findByCategoryId(itemData.getCategoryId()).getCategoryDesc());
			itemDataDto.setDateIndented(indentData.getDate());
			// itemDataDto.setFolio(1111); // to be changed
			// itemDataDto.setHsn(11111);// changed
			// poDto.setBasicRate(11111); // to be changed
			// poDto.setGst(18);// to be changed
			// poDto.setAirRate(poDto.getBasicRate() * 0.18 + poDto.getBasicRate());
			// poDto.setAmount(poDto.getQty() * poDto.getAirRate());
			// poDto.setCategory("IMP/OMC"); // to be changed
			itemDataDto.setPoReceived(false);
			itemDataDto.setQtyRcvd((int) indentData.getPoQuantityRcvd());

			return itemDataDto;
		}
	}

	@RequestMapping("/getIndentInfo/{indentId}")
	public IndentDataInfoDto getIndentDataForItemsReceivingInfo(@PathVariable long indentId) {
		IndentDetail indentData = indentDetailRepository.findByIndentId(indentId);
		//System.out.println(indentData);

		if (indentData == null) {
			IndentDataInfoDto indentDto = new IndentDataInfoDto();
			indentDto.setPoReceived(false);
			return indentDto;

		}

		else {

			ItemsData itemData = itemsDataRepository.findByItemId(indentData.getItemId());

			IndentDataInfoDto indentDto = new IndentDataInfoDto();

			indentDto.setIndentId(indentData.getIndentId());

			indentDto.setIndentDate(indentData.getDate());

			indentDto.setDescription(itemData.getDescription());

			indentDto.setPartNo(itemData.getPartNumber());

			if (indentData.getQuantityReq() > indentData.getPoQuantityRcvd()) {
				indentDto.setPoReceived(false);
			} else if (indentData.getQuantityReq() == indentData.getPoQuantityRcvd()) {
				indentDto.setPoReceived(true);

			}

			indentDto.setQuantity(indentData.getQuantityReq());

			return indentDto;

		}
	}

	@RequestMapping("/checkIfPoPreasent/{poNumber}")
	public boolean checkIfPoPreasent(@PathVariable String poNumber) {
		
		poNumber=poNumber.replace("$", "/");

		
		PurchaseOrderDetail poDetail = poDetailRepository.findByPoNumber(poNumber);

		if (poDetail != null)
			return true;
		else
			return false;

	}

	@RequestMapping("/getItemsDataWithItemId")
	public ItemsData getItemsDataWithItemId(@RequestParam(value = "itemId") Integer itemId,
			@RequestParam(value = "indentType") Integer indentType) throws Exception {

		//System.out.println(itemId + "---" + indentType);

		ItemsData itemsData = itemsDataRepository.findById(itemId);
		if (indentType == AssistConstantsParameters.INDENT_TYPE_RC) {
			itemsData.setLastPurchaseDetailsFound(true);
			itemsData.setLastPurchaseDetails(
					assistConstants.getParameterValue(AssistConstantsParameters.LIKELY_SUPPLIER_RC_INDENT));
			//System.out.println("Add in Suppliers Data table");
			itemsData.setLastPurchaseDetailsId(10); // should be changed

		}

		else if (indentType == AssistConstantsParameters.INDENT_TYPE_NORMAL) {

			Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "createdOn"));
			Pageable pageable = new PageRequest(0, 1, sort);

			List<IndentPoRelation> recentPo = indentPoRepository.findByItemId(itemsData.getItemId(), pageable)
					.getContent();

			if (recentPo.size() > 0) {

				itemsData.setLastPurchaseDetailsFound(true);

				PurchaseOrderDetail poData = poDetailRepository.findByPoNumber(recentPo.get(0).getPoNumber());

				itemsData.setLastPurchaseDetails("As per " + recentPo.get(0).getPoNumber() + " Dt "
						+ poData.getCreatedOn().toString().substring(0, 10));
			}

			else {

				itemsData.setLastPurchaseDetails("NA");

				List<VendorsData> vendors = vendorsDataRepository.findAll();

				Map<String, Integer> vendorsList = new HashMap<>();

				for (VendorsData vendorsData : vendors) {

					vendorsList.put(vendorsData.getSupplierDesc() + "," + vendorsData.getCity(),
							(int) vendorsData.getId());

				}

				Map<String, Integer> result = vendorsList.entrySet().stream().sorted(Map.Entry.comparingByKey())
						.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
								(oldValue, newValue) -> oldValue, LinkedHashMap::new));

				itemsData.setVendorsDataList(result);

				itemsData.setLastPurchaseDetailsFound(false);

			}
		}
	//	System.out.println(itemsData);
		return itemsData;

	}

	@RequestMapping("/getItemsDataWithId/{itemId}")
	public ItemsData getItemsDataWithId(@PathVariable long itemId) {

		ItemsData itemsData = itemsDataRepository.findByItemId(itemId);

		if (itemsData == null) {

			ItemsData itemsData1 = new ItemsData();
			itemsData1.setItemPresent(false); // this is to declare item is not present in itemsData

			return itemsData1;
		}

		else {
			itemsData.setItemPresent(true); // this is to declare item is present in itemsData

			StockAvailable stockInfo = stockAvailableRepository.findByItemId(itemId); // to get stock of he item
																						// available to show in front
			if (stockInfo != null) // end
				itemsData.setStockAvailable(stockInfo.getQuantityAvailable());
			else
				itemsData.setStockAvailable(0);

			List<IndentPoRelation> poPresentForItem = indentPoRepository.findByItemsLeft(itemId);

			if (!poPresentForItem.isEmpty()) {
				Map<String, Integer> poDataWithItems = new HashMap<>();

				for (IndentPoRelation indentPoRelation : poPresentForItem) {

					//System.out.println(indentPoRelation.getPoNumber());

					poDataWithItems.put("PO : "+indentPoRelation.getPoNumber()+" with  indent "+indentPoRelation.getId().getIndentId(),
							indentPoRelation.getQtyReceived() - indentPoRelation.getQtyIssued());
				}

				itemsData.setIsItemsAvailableToIssueForChallan(true);
				itemsData.setPoDataOfItem(poDataWithItems);
				return itemsData;
			} else {

				itemsData.setIsItemsAvailableToIssueForChallan(false);
				return itemsData;

			}
		}
	}

	@RequestMapping("/getItemsDataWithIdPoNumber/{itemId}")
	public ItemsWithPoDto getItemsDataWithIdPoNumber(@PathVariable int itemId) {

		ItemsData itemsData = itemsDataRepository.findByItemId(itemId);

		if (itemsData == null) {

			ItemsWithPoDto itemsData1 = new ItemsWithPoDto();
			itemsData1.setItemPresent(false); // this is to declare item is not present in itemsData

			return itemsData1;
		}

		else {

			List<IndentPoRelation> poPresentForItem = indentPoRepository.poReceivedForAllItemsInIndent(itemId);
			if (!poPresentForItem.isEmpty()) {
				ItemsWithPoDto itemsDataObj = new ItemsWithPoDto();

				itemsDataObj.setItemPresent(true); // this is to declare item is present in itemsData

				StockAvailable stockInfo = stockAvailableRepository.findByItemId(itemId); // to get stock of he item
																							// available to show in
																							// front
																							// end
				if (stockInfo == null )
					itemsDataObj.setStockAvailable(0);
				else
					itemsDataObj.setStockAvailable(stockInfo.getQuantityAvailable());

				itemsDataObj.setPartNumber(itemsData.getPartNumber());

				itemsDataObj.setDescription(itemsData.getDescription());

				itemsDataObj.setItemId(itemsData.getItemId());

				Map<String, Integer> poNumbers = new HashMap<>();
				for (IndentPoRelation indentPoRelation : poPresentForItem) {
					if (indentPoRelation.getPoReceivedQuantity() - indentPoRelation.getQtyReceived() > 0)
						poNumbers.put("PO : "+indentPoRelation.getPoNumber()+" for indent "+indentPoRelation.getId().getIndentId(),
								indentPoRelation.getPoReceivedQuantity() - indentPoRelation.getQtyReceived()); // pending
																												// count
																												// that
																												// to be
					// recived

				}

				if (poNumbers.size() > 0) {
					itemsDataObj.setOutStandingPoExists(true);

				} else {
					itemsDataObj.setOutStandingPoExists(false);

				}

				itemsDataObj.setPoNumbersWithItemsNotReceived(poNumbers);

				return itemsDataObj;
			}

			else {
				ItemsWithPoDto itemsDataObj = new ItemsWithPoDto();

				itemsDataObj.setOutStandingPoExists(false);

				itemsDataObj.setItemPresent(true); // this is to declare item is present in itemsData

				StockAvailable stockInfo = stockAvailableRepository.findByItemId(itemId); // to get stock of he item
																							// available to show in
																							// front
																							// end
				if (stockInfo == null)
					itemsDataObj.setStockAvailable(0);
				else
					itemsDataObj.setStockAvailable(stockInfo.getQuantityAvailable());

				itemsDataObj.setPartNumber(itemsData.getPartNumber());

				itemsDataObj.setDescription(itemsData.getDescription());

				itemsDataObj.setItemId(itemsData.getItemId());

				return itemsDataObj;

			}

		}

	}

	@RequestMapping("/getQuantityLeft/{itemId}")
	public StockAvailable getQuantityLeft(@PathVariable int itemId) {

		StockAvailable itemsData = stockAvailableRepository.findByItemId(itemId);

		if (itemsData == null) {

			StockAvailable stockAvailable = new StockAvailable();

			stockAvailable.setDataPresent(false);

			return stockAvailable;

		}

		else {

			itemsData.setDataPresent(true);

			return itemsData;

		}

		// System.out.println(itemsData);

	}

	@RequestMapping("/getPoData")
	public List<PoDtoHome> getPoData() {
		List<PoDtoHome> poDtoHome = new ArrayList<>();
		
		Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "createdOn"));
		Pageable pageable = new PageRequest(0, 10, sort);
		
		List<PurchaseOrderDetail> purchaseOrderdetails = poDetailRepository.findAll(pageable).getContent();

		for (PurchaseOrderDetail purchaseOrderDetail : purchaseOrderdetails) {
			PoDtoHome pdh = new PoDtoHome();
			pdh.setNumberOfIndents(purchaseOrderDetail.getNumberOfIndents());
			pdh.setPoNo(purchaseOrderDetail.getPoNumber());
			pdh.setDate(purchaseOrderDetail.getCreatedOn());
			pdh.setSerialNo(purchaseOrderDetail.getSerialNumber());
			pdh.setDesc("Purchase order is given by "
					+ vendorsDataRepository.findById(purchaseOrderDetail.getSuppliedBy()).getSupplierDesc() + " with "
					+ purchaseOrderDetail.getNumberOfIndents() + " indents.");
			pdh.setTitle("Purchase order Id is " + purchaseOrderDetail.getPoNumber());
			UserDetail user = userDetailsRepository.findByUserId(purchaseOrderDetail.getCreatedBy());
			pdh.setCreatedBy(user.getUserFirstName() + " " + user.getUserLastName());
			poDtoHome.add(pdh);

		}

		poDtoHome=poDtoHome.stream().sorted(Comparator.comparing(PoDtoHome::getDate).reversed()).collect(Collectors.toList());
		
		/*
		 * poDtoHome.sort((po2, po1) -> { return (int) (po2.getDate().getTime() -
		 * po1.getDate().getTime()); });
		 */

	//	poDtoHome.stream().forEach(p->System.out.println(p.getDate().getTime()+" "+p.getPoNo()));
		
		
		return poDtoHome;

	}

	@RequestMapping("/getAllItemsData/{uniqueNumber}")
	public List<ItemsIssuedDataDto> getAllItemsData(@PathVariable long uniqueNumber) {

		List<MaterialsIssueRelation> allItemsInChallan = materialsIssueRelationRepository
				.findByUniqueRelationId(uniqueNumber);

		List<ItemsIssuedDataDto> allItemsData = new ArrayList<>();

		for (MaterialsIssueRelation materialsIssueRelation : allItemsInChallan) {
			ItemsIssuedDataDto dto = new ItemsIssuedDataDto();

			dto.setItemId(materialsIssueRelation.getItemId());
			dto.setPoNumber(materialsIssueRelation.getPoNumber());
			dto.setQty(materialsIssueRelation.getQtyIssued());

			allItemsData.add(dto);
		}

		return allItemsData;

	}

	@RequestMapping("/itemsIssuedData")
	public List<ItemsIssuedDtoHome> itemsIssuedData() throws NumberFormatException, Exception {

		List<ItemsIssuedDtoHome> listData = new ArrayList<>();

		Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "createdOn"));
		Pageable pageable = new PageRequest(0, 10, sort);
		
		List<MaterialIssueData> materialsIssuedDataList = materialsIssueDataRepository.findAll(pageable).getContent();

		for (MaterialIssueData materialIssueData : materialsIssuedDataList) {

			ItemsIssuedDtoHome dto = new ItemsIssuedDtoHome();
			dto.setId(materialIssueData.getMaterialIssueId());
			dto.setChallanNumber(materialIssueData.getChallanNumber());
			dto.setDate(materialIssueData.getDateIssue());

			if (materialIssueData.getMaterialIssuedBy() == Integer
					.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_I_RYP)))
				dto.setIssuedFrom(
						assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_I_RYP_DESC));
			else
				dto.setIssuedFrom(
						assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_II_RYP_DESC));

			dto.setIssuedTo(materialIssueData.getMaterialIssueTo());
			UserDetail user = userDetailsRepository.findByUserId(materialIssueData.getCreatedBy());

			dto.setLoggedBy(user.getUserFirstName() + " " + user.getUserLastName());
			dto.setTitle("Challan " + materialIssueData.getChallanNumber() + " generated for "
					+ materialIssueData.getTotalNoOfItemsIssued() + " items.");
			dto.setDesc(materialIssueData.getTotalNoOfItemsIssued() + "  item is issued in this challan for "
					+ materialIssueData.getMaterialIssueTo() + ". "); // materials
			// issued to
			// should be
			// changed

			listData.add(dto);

		}

		listData=listData.stream().sorted(Comparator.comparing(ItemsIssuedDtoHome::getDate).reversed()).collect(Collectors.toList());

		
		/*
		 * listData.sort((issuedData2, issuedData1) -> { return (int)
		 * (issuedData2.getId() - issuedData2.getId()); });
		 */

		return listData;

	}

	@RequestMapping("/itemsReceivedData")
	public List<ItemsReceivedDtoHome> itemsReceivedData() {

		List<ItemsReceivedDtoHome> itemsReceivedDto = new ArrayList<>();
		
		Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "createdOn"));
		Pageable pageable = new PageRequest(0, 10, sort);
		

		List<MaterialsReceivedData> receivedDataList = materialsReceivedDataRepository.findAll(pageable).getContent();
		for (MaterialsReceivedData materialsReceivedData : receivedDataList) {

			ItemsReceivedDtoHome dto = new ItemsReceivedDtoHome();
			dto.setId(materialsReceivedData.getId());
			dto.setItemId(materialsReceivedData.getItemId());
			dto.setNumberOfItemsReceived(materialsReceivedData.getNumberOfItemsReceived());
			UserDetail user = userDetailsRepository.findByUserId(materialsReceivedData.getCreatedBy());
			dto.setLoggedBy(user.getUserFirstName() + " " + user.getUserLastName());

			if (materialsReceivedData.getPoNumber() != null)
				dto.setPoNumber(materialsReceivedData.getPoNumber());

			dto.setTitle(materialsReceivedData.getItemId() + "  is received.");
			dto.setDesc("These items were received against purchase order " + materialsReceivedData.getPoNumber());

			dto.setReceivedOn(materialsReceivedData.getCreatedon());
			itemsReceivedDto.add(dto);

		}

		
		itemsReceivedDto=itemsReceivedDto.stream().sorted(Comparator.comparing(ItemsReceivedDtoHome::getReceivedOn).reversed()).collect(Collectors.toList());

		/*
		 * itemsReceivedDto.sort((receivedData2, receivedData1) -> { return (int)
		 * (receivedData2.getReceivedOn().getTime() -
		 * receivedData1.getReceivedOn().getTime()); });
		 */
		return itemsReceivedDto;

	}

	@RequestMapping("/getIndentsData/{serialNo}")
	public List<IndentDataInfoDto> getIndentsData(@PathVariable long serialNo) {

		//System.out.println(".,.,.,.,.," + serialNo);
		PurchaseOrderDetail poDetails = poDetailRepository.findBySerialNumber(serialNo);

		List<IndentPoRelation> indentDataList = indentPoRepository
				.findByIdPoIndentNumber((poDetails.getIndentPoReqId()));

		List<IndentDataInfoDto> allIndentsInPo = new ArrayList<>();
	//	System.out.println(poDetails.getIndentPoReqId() + "  " + indentDataList.size());

		for (IndentPoRelation indentDataInfoDto : indentDataList) {

			IndentDataInfoDto indentData = new IndentDataInfoDto();

			indentData.setIndentId(Long.valueOf(indentDataInfoDto.getId().getIndentId()));
			indentData.setIndentDate(
					indentDetailRepository.findByIndentId(indentDataInfoDto.getId().getIndentId()).getCreatedOn());
			indentData.setItemId(indentDataInfoDto.getItemId());

			indentData.setQuantity(indentPoRepository
					.findByIdIndentIdAndPoNumber(indentDataInfoDto.getId().getIndentId(), poDetails.getPoNumber())
					.getPoReceivedQuantity());
			indentData.setItemType(indentDataInfoDto.getItemCategory());

			indentData.setPrice(indentDataInfoDto.getRatePurchased()+(indentDataInfoDto.getRatePurchased()*indentDataInfoDto.getGst()/100));
			
			if (indentDataInfoDto.getItemCategory().equals("IMP"))
				indentData.setDueDate(new Date());
			else if (indentDataInfoDto.getItemCategory().equals("IND"))
				indentData.setDueDate(new Date());
			if (indentDataInfoDto.getItemCategory().equals("OMC"))
				indentData.setDueDate(new Date());
			allIndentsInPo.add(indentData);

		}

		return allIndentsInPo;
	}

	@RequestMapping("/getAllItemsSubCat/{catId}")
	public List<ItemsSubCategory> getSubCat(@PathVariable int catId) {

		List<ItemsSubCategory> subCat = new ArrayList<>();

		List<Category> subCatgegoryList = categoryRepository.findByGroupId(catId);

		for (Category category : subCatgegoryList) {

			ItemsSubCategory itemSubcat = new ItemsSubCategory();

			itemSubcat.setCatId(category.getCategoryId());
			itemSubcat.setDesc(category.getCategoryDesc());
			itemSubcat.setGroupId(category.getGroupId());

			subCat.add(itemSubcat);
		}

		return subCat;
	}

	@RequestMapping("/getItemWithSubCat/{subCatId}")
	public ItemsData getItemWithSubCat(@PathVariable int subCatId) {

		List<ItemsData> itemsData = itemsDataRepository.findByCategoryId(subCatId);

		//itemsData.sort((item2, item1) -> {
		//	return (int) (item1.getItemId() - item2.getItemId());
		//});

			itemsData.parallelStream().sorted(Comparator.comparing(ItemsData::getItemId).reversed());
		
		itemsData.get(0).setItemId(itemsData.get(0).getItemId() + 1);

		return itemsData.get(0);

	}

	@RequestMapping("/getPoDetails/{poNumber}")
	public PoDtoHome getPoDetails(@PathVariable String poNumber) {

		PoDtoHome poDataObj = new PoDtoHome();

		try {
			
			poNumber=poNumber.replace("$", "/");
			
			//System.out.println("index of for is"+poNumber.indexOf("for")+"       "+poNumber);
			String updatedPoNumber = poNumber.substring(poNumber.indexOf(":")+1, poNumber.indexOf("for")).trim();
//System.out.println(updatedPoNumber.length()+updatedPoNumber);
			PurchaseOrderDetail poData = poDetailRepository.findByPoNumber(updatedPoNumber.trim());

			//System.out.println("poNumber " + poNumber + " updatedPoNumber " + updatedPoNumber+"  poData is"+poData);

			if (poData != null) {

				poDataObj.setPoNo(updatedPoNumber);

				// poData.setTotalQtyToBeReceived(poData.get);

				poDataObj.setDate(poData.getCreatedOn());

				poDataObj.setTenderType(poData.getTenderType());

				poDataObj.setSerialNo(poData.getSerialNumber());

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return poDataObj;

	}

	@RequestMapping("/getAllElementsInCat/{catId}")
	public List<List<ItemsData>> getAllElementsInCat(@PathVariable int catId) throws Exception {

		// Pageable topTen = new PageRequest(0, 10, Direction.ASC, "itemId");

		// Sort sort = new Sort(new Sort.Order(Sort.Direction.ASC, "itemId"));
		// Pageable pageable = new PageRequest(1, 10, sort);

		List<List<ItemsData>> fullList = new ArrayList<>();

		List<ItemsData> itemsCategoryName = new ArrayList<>();

		ItemsData dto = new ItemsData();

		dto.setCategoryString(groupDetailRepository.findBygroupId(catId).getGroupDesc());

		itemsCategoryName.add(dto);
		// itemsCategoryName.add(0).setCategoryString(
		// groupDetailRepository.findBygroupId(catId).getGroupDesc() );

		List<ItemsData> itemsData = itemsService.getAllItems(catId);

		fullList.add(itemsCategoryName);

		fullList.add(itemsData);

		
		return fullList;

	}

	@RequestMapping("/getDataOfItemForDialog/{itemId}")
	public ItemsData getDataOfItemForDialog(@PathVariable long itemId) {

		ItemsData itemsData = itemsDataRepository.findByItemId(itemId);
		
		itemsData.setCategoryString(categoryRepository.findByCategoryId(itemsData.getCategoryId()).getCategoryDesc());

		StockAvailable stock = stockAvailableRepository.findByItemId(itemId);

		itemsData.setStockAvailable((stock != null) ? stock.getQuantityAvailable() : 0);

		if(itemsData.getPartNumber().equals("")) {
			itemsData.setPartNumber("Not Available");
		}
		
		return itemsData;
	}

	@RequestMapping("/recentChallans/{itemId}")
	public List<ChallanTableDto> recentChallans(@PathVariable long itemId) {

		Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "dateIssue"));
		Pageable pageable = new PageRequest(0, 10, sort);

		Page<MaterialsIssueRelation> recentChallans = materialsIssueRelationRepository.findByItemId(itemId, pageable);

		List<MaterialsIssueRelation> recentChallansList = recentChallans.getContent();

		List<ChallanTableDto> challanList = new ArrayList<>();

		for (MaterialsIssueRelation materialsIssueRelation : recentChallansList) {

			ChallanTableDto challanDto = new ChallanTableDto();

			MaterialIssueData issueData = materialsIssueDataRepository
					.findByUniqueRelationNo(materialsIssueRelation.getUniqueRelationId());

			challanDto.setChallanNo(issueData.getChallanNumber());
			challanDto.setDate(materialsIssueRelation.getDateIssue());
			challanDto.setIssuedTo(issueData.getMaterialIssueTo());
			challanDto.setNumberOfItems(issueData.getTotalNoOfItemsIssued());

			challanList.add(challanDto);

		}

		return challanList;

	}

	@RequestMapping("/recentIndents/{itemId}")
	public List<IndentTableDto> recentIndents(@PathVariable long itemId) {
		//System.out.println("inside" + itemId);

		Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "date"));
		Pageable pageable = new PageRequest(0, 10, sort);

		Page<IndentDetail> indentData = indentDetailRepository.findByItemId(itemId, pageable);

		List<IndentDetail> indentDataList = indentData.getContent();

		List<IndentTableDto> listDto = new ArrayList<>();
		for (IndentDetail indentDetail : indentDataList) {

			IndentTableDto dto = new IndentTableDto();

			dto.setDate(indentDetail.getDate());
			dto.setIndentId(indentDetail.getIndentId());
			dto.setItemId(indentDetail.getItemId());
			dto.setNumberOfItems((int) indentDetail.getQuantityReq());
			dto.setPrice(indentDetail.getRate());

			listDto.add(dto);

		}

		return listDto;

	}

	@RequestMapping("/recentPo/{itemId}")
	public List<PoTableDto> recentPo(@PathVariable long itemId) {

		Sort sort = new Sort(new Sort.Order(Sort.Direction.DESC, "createdOn"));
		Pageable pageable = new PageRequest(0, 10, sort);

		Page<IndentPoRelation> poData = indentPoRepository.findByItemId(itemId, pageable);

		List<IndentPoRelation> poDataList = poData.getContent();

		List<PoTableDto> recentPoData = new ArrayList<>();

		for (IndentPoRelation poDataObj : poDataList) {

			PoTableDto dto = new PoTableDto();

			PurchaseOrderDetail po = poDetailRepository.findByIndentPoReqId(poDataObj.getId().getPoIndentNumber());

			dto.setPoNumber(poDataObj.getPoNumber());

			dto.setDate(po.getCreatedOn());

			dto.setCategory(poDataObj.getItemCategory());

			dto.setPrice(poDataObj.getRatePurchased());

			dto.setSuppliedBy(vendorsDataRepository.findById(po.getSuppliedBy()).getSupplierDesc());

			recentPoData.add(dto);

		}
		return recentPoData;

	}

	@RequestMapping("/outStandingIndents/{itemId}")
	public List<IndentDataDto> outStandingIndents(@PathVariable long itemId) {

		return null;

	}

	@RequestMapping("/recentOperations/{itemId}")
	public List<ItemsData> recentOperations(@PathVariable long itemId) {

		return null;

	}

	@RequestMapping("/outStandingPo/{itemId}")
	public List<PoDtoHome> outStandingPo(@PathVariable long itemId) {

		return null;

	}

	@RequestMapping("/tabsData")
	public List<ItemsData> tabsData() {

		List<ItemsData> itemsCategoryName = new ArrayList<>();

		List<GroupDetails> groupDataList = groupDetailRepository.findAll();

		Map<String, ItemsGroupWiseData> map = new HashMap<>();

		for (GroupDetails groupDetails : groupDataList) {

			ItemsGroupWiseData itemGrpWise = new ItemsGroupWiseData();

			itemGrpWise.setGroupId(groupDetails.getGroupId());
			itemGrpWise.setTotalCount(itemsDataRepository.countByGroupId(groupDetails.getGroupId()));
			
			//List<StockAvailable> stockInfo=stockAvailableRepository.findByItemGroupId(groupDetails.getGroupId());
			
			//stockInfo=stockInfo.stream().filter(p->p.getQuantityAvailable()>0).collect(Collectors.toList());
			itemGrpWise.setAvailableStock(stockAvailableRepository.findByItemGroupId(groupDetails.getGroupId()));

			map.put(groupDetails.getGroupDesc(), itemGrpWise);

		}
		
	map=map.entrySet().stream().sorted(Map.Entry.comparingByValue()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                (oldValue, newValue) -> oldValue, LinkedHashMap::new));
		ItemsData dto = new ItemsData();

		dto.setCategoryString("Classification of all items");
		dto.setCategoriesData(map);
		dto.setCategoryId(0);
		//dto.setTotalCount(itemsDataRepository.findBy);
		itemsCategoryName.add(dto);
		

	//	System.out.println(itemsCategoryName);

		return itemsCategoryName;

	}

	@RequestMapping("/addTab/{catId}")
	public List<ItemsData> addTab(@PathVariable int catId) throws Exception {

		try {
			//List<ItemsData> itemsCategoryName = new ArrayList<>();

			//ItemsData dto = new ItemsData();

			//dto.setCategoryString(groupDetailRepository.findBygroupId(catId).getGroupDesc());

			//itemsCategoryName.add(dto);

			List<ItemsData> itemsData = itemsService.getAllItems(catId);

			itemsData.get(0).setTotalNumberOfItems(itemsDataRepository.countByGroupId(catId));

			itemsData.get(0).setCategoryString(groupDetailRepository.findBygroupId(catId).getGroupDesc());
			itemsData.get(0).setGroupId(catId);

			return itemsData;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}

	}

	@RequestMapping("/getPoDataOfIndent/{indentNo}")
	public List<PoTableDto> getPoDataOfIndent(@PathVariable int indentNo) throws Exception {

		try {
			List<IndentPoRelation> poData = indentPoRepository.findByIdIndentId(indentNo);

			List<PoTableDto> list = new ArrayList<>();
			for (IndentPoRelation indentPoRelation : poData) {

				PoTableDto poDataObj = new PoTableDto();

				poDataObj.setPoNumber(indentPoRelation.getPoNumber());
				poDataObj.setPrice(indentPoRelation.getRatePurchased());
				//System.out.println(indentPoRelation.getPoNumber().trim());
				PurchaseOrderDetail po = poDetailRepository.findByPoNumber(indentPoRelation.getPoNumber().trim());
				//System.out.println(po);
				VendorsData vendor = vendorsDataRepository.findById(po.getSuppliedBy());
				poDataObj.setSuppliedBy(vendor.getSupplierDesc() + "-" + vendor.getCity());
				poDataObj.setQuantity(indentPoRelation.getPoReceivedQuantity());
				poDataObj.setDate(po.getOpenedOnDate());
				if (indentPoRelation.getItemCategory().equals(
						assistConstants.getParameterValue(AssistConstantsParameters.INDENT_ITEM_CATEGORY_IMP_DESC))) {
					poDataObj.setDueDate(po.getImpDueDate());
					poDataObj.setItemType(
							assistConstants.getParameterValue(AssistConstantsParameters.INDENT_ITEM_CATEGORY_IMP_DESC));
				} else if (indentPoRelation.getItemCategory().equals(
						assistConstants.getParameterValue(AssistConstantsParameters.INDENT_ITEM_CATEGORY_IND_DESC))) {
					poDataObj.setDueDate(po.getIndDueDate());
					poDataObj.setItemType(
							assistConstants.getParameterValue(AssistConstantsParameters.INDENT_ITEM_CATEGORY_IND_DESC));

				} else if (indentPoRelation.getItemCategory().equals(
						assistConstants.getParameterValue(AssistConstantsParameters.INDENT_ITEM_CATEGORY_OMC_DESC))) {
					poDataObj.setDueDate(po.getOmcDueDate());

					poDataObj.setItemType(
							assistConstants.getParameterValue(AssistConstantsParameters.INDENT_ITEM_CATEGORY_OMC_DESC));

				}

				list.add(poDataObj);

			}
			return list;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			throw e;
		}

	}

	@RequestMapping("/getChartsData")
	public Map<String, List<Long>> getChartsData() {

		String[] monthName = { "January", "February", "March", "April", "May", "June", "July", "August", "September",
				"October", "November", "December" };

		Calendar cal = Calendar.getInstance();

		int month1 = cal.get(Calendar.MONTH);
		String month1Name = monthName[month1];
		int year1 = Calendar.getInstance().get(Calendar.YEAR);

		Map<Integer, Integer> monthYears = new LinkedHashMap<>(); // key is month and value is year

		monthYears = getMonthsAndyears(year1, month1);

		List<Integer> list = new ArrayList<Integer>(monthYears.keySet());

		int year2 = monthYears.get(list.get(1));
		int month2 = list.get(1);
		String month2Name = monthName[month2];

		int year3 = monthYears.get(list.get(2));
		int month3 = list.get(2);
		String month3Name = monthName[month3];

		int year4 = monthYears.get(list.get(3));
		int month4 = list.get(3);
		String month4Name = monthName[month4];

		/*
		 * System.out.println("Month1::: " + month1 + "---Month2:::: " + month2 +
		 * "--- Month3::: " + month3 + "--- Month4:::" + month4); System.out.println(
		 * "Year1::: " + year1 + "---Year2:::: " + year2 + "--- Year3::: " + year3 +
		 * "--- Year4:::" + year4); System.out.println("Month1::: " + monthName[month1]
		 * + "---Month2:::: " + monthName[month2] + "--- Month3::: " + monthName[month3]
		 * + "--- Month4:::" + monthName[month4]);
		 */

		// building start and end dates for fetching data

		Date[] month1StartEndDate = getStartDateAndEndDateOfMonth(year1, month1);

		Date[] month2StartEndDate = getStartDateAndEndDateOfMonth(year2, month2);

		Date[] month3StartEndDate = getStartDateAndEndDateOfMonth(year3, month3);

		Date[] month4StartEndDate = getStartDateAndEndDateOfMonth(year4, month4);

		Date startDateMonth1 = month1StartEndDate[0];
		Date endDateMonth1 = new Date();

		Date startDateMonth2 = month2StartEndDate[0];
		Date endDateMonth2 = month2StartEndDate[1];

		Date startDateMonth3 = month3StartEndDate[0];
		Date endDateMonth3 = month3StartEndDate[1];

		Date startDateMonth4 = month4StartEndDate[0];
		Date endDateMonth4 = month4StartEndDate[1];

		long month1IndentCount = indentDetailRepository
				.countByCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(startDateMonth1, endDateMonth1);

		long month2IndentCount = indentDetailRepository
				.countByCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(startDateMonth2, endDateMonth2);

		long month3IndentCount = indentDetailRepository
				.countByCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(startDateMonth3, endDateMonth3);

		long month4IndentCount = indentDetailRepository
				.countByCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(startDateMonth4, endDateMonth4);

		List<Long> indentDetails = new ArrayList<>();

		indentDetails.add(month1IndentCount);
		indentDetails.add(month2IndentCount);
		indentDetails.add(month3IndentCount);
		indentDetails.add(month4IndentCount);

		long month1PoCount = poDetailRepository.countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(startDateMonth1,
				endDateMonth1);
		long month2PoCount = poDetailRepository.countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(startDateMonth2,
				endDateMonth2);

		long month3PoCount = poDetailRepository.countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(startDateMonth3,
				endDateMonth3);
		long month4PoCount = poDetailRepository.countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(startDateMonth4,
				endDateMonth4);

		List<Long> poDetail = new ArrayList<>();

		poDetail.add(month1PoCount);
		poDetail.add(month2PoCount);
		poDetail.add(month3PoCount);
		poDetail.add(month4PoCount);

		long month1ItemsReceivedCount = materialsReceivedDataRepository
				.countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(startDateMonth1, endDateMonth1);
		long month2ItemsReceivedCount = materialsReceivedDataRepository
				.countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(startDateMonth2, endDateMonth2);
		long month3ItemsReceivedCount = materialsReceivedDataRepository
				.countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(startDateMonth3, endDateMonth3);
		long month4ItemsReceivedCount = materialsReceivedDataRepository
				.countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(startDateMonth4, endDateMonth4);

		List<Long> receivedData = new ArrayList<>();

		receivedData.add(month1ItemsReceivedCount);
		receivedData.add(month2ItemsReceivedCount);
		receivedData.add(month3ItemsReceivedCount);
		receivedData.add(month4ItemsReceivedCount);

		long month1ItemsChallanCount = materialsIssueDataRepository
				.countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(startDateMonth1, endDateMonth1);
		long month2ItemsChallanCount = materialsIssueDataRepository
				.countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(startDateMonth2, endDateMonth2);
		long month3ItemsChallanCount = materialsIssueDataRepository
				.countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(startDateMonth3, endDateMonth3);
		long month4ItemsChallanCount = materialsIssueDataRepository
				.countByCreatedOnGreaterThanEqualAndCreatedOnLessThan(startDateMonth4, endDateMonth4);

		List<Long> challanData = new ArrayList<>();

		challanData.add(month1ItemsChallanCount);
		challanData.add(month2ItemsChallanCount);
		challanData.add(month3ItemsChallanCount);
		challanData.add(month4ItemsChallanCount);

		Map<String, List<Long>> totalData = new LinkedHashMap<>(); // four keys will be months and list will be data

		totalData.put(month1Name, indentDetails);
		totalData.put(month2Name, poDetail);
		totalData.put(month3Name, receivedData);
		totalData.put(month4Name, challanData);

		return totalData;

	}

	private Date[] getStartDateAndEndDateOfMonth(int year, int month) {
		Calendar cal = Calendar.getInstance();

		cal.set(year, month, 1, 0, 0, 0);

		Date[] array = new Date[2];

		array[0] = cal.getTime();

		cal.add(Calendar.DATE, new GregorianCalendar(year, month, 1).getActualMaximum(Calendar.DAY_OF_MONTH) - 1);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.HOUR_OF_DAY, 23);

		array[1] = cal.getTime();

		return array;
	}

	private Map<Integer, Integer> getMonthsAndyears(int year, int month) {

		Map<Integer, Integer> monthYear = new LinkedHashMap<>();
		monthYear.put(month, year);

		for (int i = 0; i < 4; i++) {
			List<Integer> list = new ArrayList<Integer>(monthYear.keySet());

			if (list.get(i) == 0) {
				monthYear.put(11, monthYear.get(i) - 1);
			} else {
				monthYear.put(list.get(i) - 1, monthYear.get(list.get(i)));
			}

		}

		// System.out.println(monthYear);
		return monthYear;

	}

	@RequestMapping(value = "/allDataRestCall")
	public @ResponseBody List<AllDataDto> getAllData(@RequestParam(required = false) int pageCnt,
			@RequestParam(required = false) int selectedCategory, RedirectAttributes redirectAttributes)
			throws Exception {

		//System.out.println(pageCnt + " +++++++ " + selectedCategory);

		// UserDetail user = currentUser.getCurrentUser();
		List<AllDataDto> listOfAllData = new ArrayList<>();
		try {

			listOfAllData = allDataService.getAllDataWithCategory(selectedCategory, pageCnt);

			//System.out.println(listOfAllData.size() + " list size");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return listOfAllData;

	}

	@RequestMapping("/getDataAfterFilter/filter")
	public List<AllDataDto> getAllIssuesRestCall(@RequestParam(required = false) int categorySelected,
			@RequestParam(required = false) boolean logged, @RequestParam(required = false) String fromDate,
			@RequestParam(required = false) String toDate) throws Exception {

		List<AllDataDto> allData = new ArrayList<>();
		try {
			Date dateT = null;
			Date dateF = null;

			boolean searchOnDate = false;
			if (!fromDate.equals("0") && !toDate.equals("0")) {
				String fDate = fromDate.substring(0, 28) + "+" + fromDate.substring(29, fromDate.length());
				String tDate = toDate.substring(0, 28) + "+" + toDate.substring(29, toDate.length());

				DateFormat inputFormat = new SimpleDateFormat("E MMM dd yyyy HH:mm:ss 'GMT'z", Locale.ENGLISH);
				dateF = inputFormat.parse(fDate);
				dateT = inputFormat.parse(tDate);
				dateT = DateUtils.addDays(dateT, 1);
				searchOnDate = true;

			}
			UserDetail principal = currentUser.getCurrentUser();

			if (categorySelected == 1) {

				List<IndentDetail> list = new ArrayList<>();
				// indent
				if (logged && searchOnDate) {
					list = indentDetailRepository
							.findByIndentLoggedByAndCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(
									principal.getUserId(), dateF, dateT);

				}

				if (logged && !searchOnDate) {
					list = indentDetailRepository.findByIndentLoggedBy(principal.getUserId());

				}

				if (!logged && searchOnDate) {
					list = indentDetailRepository.findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(dateF, dateT);

				}

				if (!logged && !searchOnDate) {

					list = indentDetailRepository.findAll();
				}

				for (IndentDetail indentDetail : list) {

					AllDataDto indentDto = new AllDataDto();
					indentDto.setId("Indent id: " + String.valueOf(indentDetail.getIndentId()));
					indentDto.setId1("Item id: " + String.valueOf(indentDetail.getItemId()));
					indentDto.setId2("Quantity: " + String.valueOf(indentDetail.getQuantityReq()));
					indentDto.setLoggedDate(indentDetail.getCreatedOn());
					UserDetail userLogged = userDetailsRepository.findByUserId(indentDetail.getIndentLoggedBy());
					indentDto.setLoggedBy(
							"Logged by: " + userLogged.getUserFirstName() + " " + userLogged.getUserLastName());
					indentDto.setUniqueId(indentDetail.getId());
					indentDto.setTotalCount(indentDetailRepository.count());

					indentDto.setTitle("Indent " + indentDetail.getIndentId() + " is generated for the item "
							+ indentDetail.getItemId());
					indentDto.setDesc("Indent is generated for the value of " + indentDetail.getValue()
							+ ", and the quantity required is " + indentDetail.getQuantityReq()
							+ " for the financial year " + indentDetail.getFinancialYear());
					indentDto.setCategory(categorySelected);

					allData.add(indentDto);

				}

			}

			else if (categorySelected == 2) {

				List<PurchaseOrderDetail> list = new ArrayList<>();
				// indent
				if (logged && searchOnDate) {
					list = poDetailRepository.findByCreatedByAndCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(
							(int) principal.getUserId(), dateF, dateT);

				}

				if (logged && !searchOnDate) {
					list = poDetailRepository.findByCreatedBy((int) principal.getUserId());

				}

				if (!logged && searchOnDate) {
					list = poDetailRepository.findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(dateF, dateT);

				}

				if (!logged && !searchOnDate) {

					list = poDetailRepository.findAll();
				}

				for (PurchaseOrderDetail poData : list) {

					AllDataDto poDto = new AllDataDto();
					poDto.setId("PO no: " + poData.getPoNumber());
					poDto.setId1("Serial no:" + String.valueOf(poData.getSerialNumber()));
					poDto.setId2("Indents: " + String.valueOf(poData.getNumberOfIndents()));
					poDto.setLoggedDate(poData.getCreatedOn());
					UserDetail userLogged = userDetailsRepository.findByUserId(poData.getCreatedBy());
					poDto.setLoggedBy(
							"Logged by: " + userLogged.getUserFirstName() + " " + userLogged.getUserLastName());
					poDto.setUniqueId(poData.getSerialNumber());
					poDto.setTotalCount(poDetailRepository.count());

					poDto.setDesc("Purchase order is given by "
							+ vendorsDataRepository.findById(poData.getSuppliedBy()).getSupplierDesc() + " with "
							+ poData.getNumberOfIndents() + " indents.");
					poDto.setTitle("Purchase order Id is " + poData.getPoNumber());
					poDto.setCategory(categorySelected);

					allData.add(poDto);

				}

			}

			else if (categorySelected == 3) {

				List<MaterialsReceivedData> list = new ArrayList<>();
				// indent
				if (logged && searchOnDate) {
					list = materialsReceivedDataRepository
							.findByCreatedByAndCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(principal.getUserId(),
									dateF, dateT);

				}

				if (logged && !searchOnDate) {
					list = materialsReceivedDataRepository.findByCreatedBy(principal.getUserId());

				}

				if (!logged && searchOnDate) {
					list = materialsReceivedDataRepository.findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(dateF,
							dateT);

				}

				if (!logged && !searchOnDate) {

					list = materialsReceivedDataRepository.findAll();
				}

				for (MaterialsReceivedData receivedData : list) {

					AllDataDto receivedDto = new AllDataDto();
					receivedDto.setId("Item id: " + String.valueOf(receivedData.getItemId()));
					receivedDto.setId1("PO number" + String.valueOf(receivedData.getPoNumber()));
					receivedDto.setId2("Quantity" + String.valueOf(receivedData.getNumberOfItemsReceived()));
					receivedDto.setLoggedDate(receivedData.getCreatedon());
					UserDetail userLogged = userDetailsRepository.findByUserId(receivedData.getCreatedBy());
					receivedDto.setLoggedBy(
							"Logged by: " + userLogged.getUserFirstName() + " " + userLogged.getUserLastName());
					receivedDto.setUniqueId(receivedData.getId());
					receivedDto.setTitle(receivedData.getItemId() + "  is received.");
					receivedDto
							.setDesc("These items were received against purchase order " + receivedData.getPoNumber());

					receivedDto.setTotalCount(materialsReceivedDataRepository.count());
					receivedDto.setCategory(categorySelected);

					allData.add(receivedDto);

				}

			}

			else if (categorySelected == 4) {

				List<MaterialIssueData> list = new ArrayList<>();
				// indent
				if (logged && searchOnDate) {
					list = materialsIssueDataRepository
							.findByCreatedByAndCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(principal.getUserId(),
									dateF, dateT);

				}

				if (logged && !searchOnDate) {
					list = materialsIssueDataRepository.findByCreatedBy(principal.getUserId());

				}

				if (!logged && searchOnDate) {
					list = materialsIssueDataRepository.findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(dateF,
							dateT);

				}

				if (!logged && !searchOnDate) {

					list = materialsIssueDataRepository.findAll();
				}

				for (MaterialIssueData challanData : list) {

					AllDataDto issuedDto = new AllDataDto();
					issuedDto.setId("Challan no: " + challanData.getChallanNumber());

					if (challanData.getMaterialIssuedBy() == Integer.valueOf(
							assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_I_RYP)))
						issuedDto.setId1("Issued from: " + assistConstants
								.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_I_RYP_DESC));
					else
						issuedDto.setId1("Issued from: " + assistConstants
								.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_II_RYP_DESC));

					issuedDto.setId2("Issued to: " + challanData.getMaterialIssueTo());
					issuedDto.setLoggedDate(challanData.getCreatedOn());
					UserDetail userLogged = userDetailsRepository.findByUserId(challanData.getCreatedBy());
					issuedDto.setLoggedBy(
							"Logged by: " + userLogged.getUserFirstName() + " " + userLogged.getUserLastName());
					issuedDto.setUniqueId(challanData.getMaterialIssueId());
					issuedDto.setTotalCount(materialsIssueDataRepository.count());
					issuedDto.setTitle("Challan " + challanData.getChallanNumber() + " generated for "
							+ challanData.getTotalNoOfItemsIssued() + " items.");
					issuedDto.setDesc(challanData.getTotalNoOfItemsIssued() + "  item is issued in this challan for "
							+ challanData.getMaterialIssueTo() + ". "); // materials
					issuedDto.setCategory(categorySelected);

					allData.add(issuedDto);

				}

			}

			allData.sort((emp1, emp2) -> {
				return (int) (emp2.getLoggedDate().getTime() - emp1.getLoggedDate().getTime());
			});

		} catch (Exception e) {
			e.printStackTrace();
		}

		return allData;
	}

}