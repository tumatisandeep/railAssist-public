package com.rail.assist.service;

import java.text.ParseException;

import org.json.JSONArray;
import org.json.JSONException;

import com.google.gson.JsonArray;
import com.rail.assist.dto.PoDtoHome;
import com.rail.assist.entities.PurchaseOrderDetail;

public interface PoService {

	PoDtoHome showPo(long serialNo) throws Exception;

	PoDtoHome showPo(String uniqueId) throws Exception;


	/**
	 * @param poFormData
	 * @return
	 * @throws JSONException 
	 * @throws ParseException 
	 */
	boolean addPo(JSONArray poFormData) throws JSONException, ParseException;
	

}
