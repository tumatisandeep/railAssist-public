package com.rail.assist.constants;

public class AssistConstantsParameters {

	public static final int USER_ACCOUNT_ACTIVE = 1;

	public static final int USER_ACCOUNT_DEACTIVE = 2;

	public static final int USER_LOGGED_IN_CURRENTLY = 1;

	public static final int USER_CURRENTLY_LOGGED_OUT = 2;

	public static final int PO_NOT_RECEIVED_FOR_INDENT = 1;

	public static final int PO_RECEIVED_FOR_INDENT = 2;

	public static final int PO_PARTIALLY_RECEIVED_FOR_INDENT = 3;

	public static final int INDENT_TYPE_RC = 1;

	public static final int INDENT_TYPE_NORMAL = 2;

	public static final int ITEM_RECEIVED_AGAINST_INDENT = 2;

	public static final int ITEM_RECEIVED_AGAINST_PO = 1;

	public static final int CRITICALITY_CRITICAL = 1;

	public static final int CRITICALITY_NON_CRITICAL = 2;

	public static final int PROPRIETERY_ARTICLE_ENCLOSED = 1;

	public static final int PROPRIETERY_ARTICLE_NOT_ENCLOSED = 2;
	

	public static final int TOTAL_QUANTITY_RECEIVED_FOR_INDNET_IN_PO = 1;

	public static final int PARTIAL_QUANTITY_RECEIVED_FOR_INDNET_IN_PO = 2;

	public static final int INDENT_ITEM_CATEGORY_OMC = 1;

	public static final int INDENT_ITEM_CATEGORY_IND = 2;

	public static final int INDENT_ITEM_CATEGORY_IMP = 3;

	public static final int NO_ITEMS_RECEIVED = 0;

	public static final int NO_ITEMS_ISSUED = 0;
	
	public static final String CONTROLLING_OFFICER_ADEN = "CONTROLLING_OFFICER_ADEN";

	public static final String CONTROLLING_OFFICER_XEN = "CONTROLLING_OFFICER_XEN";

	public static final String ISSUED_BY_SSE_W_I_RYP = "ISSUED_BY_SSE_W_I_RYP";
	
	public static final String ISSUED_BY_SSE_W_II_RYP = "ISSUED_BY_SSE_W_II_RYP";

	public static final String CONSIGNEE = "CONSIGNEE";

	public static final String MATERIALS_REQUIRED_AT = "MATERIALS_REQUIRED_AT";

	public static final String INDENTOR = "INDENTOR";

	public static final String STOCK_AVAILABLE_LESS_THAN = "STOCK_AVAILABLE_LESS_THAN";

	public static final String LIKELY_SUPPLIER_RC_INDENT = "LIKELY_SUPPLIER_RC_INDENT";

	public static final String INDENTING_OFFICER = "INDENTING_OFFICER";

	public static final String APPROVING_OFFICER = "APPROVING_OFFICER";

	public static final String LAST_PURCHASE_DATA_RC_INDENT = "LAST_PURCHASE_DATA_RC_INDENT";
	
	public static final String CONTROLLING_OFFICER_ADEN_DESC = "CONTROLLING_OFFICER_ADEN_DESC";

	public static final String CONTROLLING_OFFICER_XEN_DESC = "CONTROLLING_OFFICER_XEN_DESC";
	
	public static final String ALLOCATION_FOR_INDENT = "ALLOCATION_FOR_INDENT";

	public static final String ISSUED_BY_SSE_W_I_RYP_DESC = "ISSUED_BY_SSE_W_I_RYP_DESC";

	public static final String ISSUED_BY_SSE_W_II_RYP_DESC = "ISSUED_BY_SSE_W_II_RYP_DESC"; //SSE_W_II_RYP
	
	public static final String LICENSE_FILE_LOCATION="LICENSE_FILE_LOCATION";
	
	public static final String MAIL_FILE_LOCATION="MAIL_FILE_LOCATION";

	public static final String ACCESS_DENIED_FILE_LOCATION="ACCESS_DENIED_FILE_LOCATION";
	
	
	public static final String RECEIVER_MAIL_ADDRESS="RECEIVER_MAIL_ADDRESS";
	
	public static final String SENDER_MAIL_ADDRESS="SENDER_MAIL_ADDRESS";
	
	

	public static final String DEPOT="DEPOT";

	public static final String ACCEPTABLE_MAKE="ACCEPTABLE_MAKE";
	
	public static final String LIKELY_SUPPLIER_NOT_FOUND="LIKELY_SUPPLIER_NOT_FOUND";
	
	public static final String INDENT_ITEM_CATEGORY_OMC_DESC = "INDENT_ITEM_CATEGORY_OMC_DESC";

	public static final String INDENT_ITEM_CATEGORY_IND_DESC = "INDENT_ITEM_CATEGORY_IND_DESC";

	public static final String INDENT_ITEM_CATEGORY_IMP_DESC = "INDENT_ITEM_CATEGORY_IMP_DESC";
	
	public static final String MAXIMUM_USERS_ALLOWED = "MAXIMUM_USERS_ALLOWED";

	public static final String USER_TYPE_NORMAL= "USER_TYPE_NORMAL";
	
	public static final String USER_TYPE_ADMIN="USER_TYPE_ADMIN";
	
	public static final int USER_GENDER_MALE=1;
	
	public static final int USER_GENDER_FEMALE=2;

	public static final long NO_ITEMS_AVAILABLE = 0;
	
	
	public static final String INDENT_REPORT_IMAGE_PATH="INDENT_REPORT_IMAGE_PATH";

	public static final String CHALLAN_REPORT_IMAGE_PATH = "CHALLAN_REPORT_IMAGE_PATH";

	public static final String MAIL_SCHEDULED_TIME_HOUR = "MAIL_SCHEDULED_TIME_HOUR";

	public static final int MAIL_SENT = 1;
	
	public static final int MAIL_NOT_SENT=2;

	public static final String MAIL_SENT_SUCCESSFULLY = "MAIL SENT SUCCESSFULLY";

}
