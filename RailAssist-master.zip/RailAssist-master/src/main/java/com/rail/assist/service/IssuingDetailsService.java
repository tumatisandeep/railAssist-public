package com.rail.assist.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;

public interface IssuingDetailsService {

	List<Map<String, String>> printChallan(long challanId) throws Exception;

	/**
	 * @param itemsIssued
	 * @return
	 * @throws Exception 
	 */
	String addChallanDetails(JSONArray itemsIssued) throws Exception;

	
}
