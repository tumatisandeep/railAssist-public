package com.rail.assist.special;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.rail.assist.entities.AssistConstantsDef;
import com.rail.assist.repository.AssistConstantsDefRepository;

@Component
public class StartUp implements ApplicationListener<ApplicationReadyEvent> {

	
	
	
	@Autowired
	AssistConstantsDefRepository assistConstantsDefRepository;
	
	@Override
	public void onApplicationEvent(final ApplicationReadyEvent event) {/*

		System.out.println("before stsrt up");
		System.out.println("before stsrt up");

		System.out.println("before stsrt up");

		System.out.println("before stsrt up");

		System.out.println("before stsrt up");

		System.out.println("before stsrt up");

		System.out.println("before stsrt up");
try {
		File file = new File("/Users/mahideeptumati/constants.txt");
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String line;
		int i = 2;
		while ((line = br.readLine()) != null) {
			
		AssistConstantsDef data= new AssistConstantsDef();
	
		String a[] =line.split("=");
			data.setId(i);
		data.setConstantKey(a[0]);
		data.setCreatedBy(12345);
		data.setCreatedOn(new Date());
		data.setLastUpdate(new Date());
		
		assistConstantsDefRepository.save(data);
			System.out.println("insserted with int "+i);
			i++;
		}

	br.close();
		
	}
	catch(Exception e) {
		e.printStackTrace();
	}
*/}
}