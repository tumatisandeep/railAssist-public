package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.Depot;
import com.rail.assist.entities.GroupDetails;


public interface GroupDetailRepository extends JpaRepository<GroupDetails,Integer> {
	
	
	GroupDetails findBygroupId(int id);
	
}



