package com.rail.assist.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;

import com.rail.assist.entities.IndentDetail;
import com.rail.assist.entities.MaterialIssueData;
import com.rail.assist.entities.MaterialsReceivedData;
import com.rail.assist.entities.PurchaseOrderDetail;

public interface HomeService {

	/**
	 * @param pageable
	 * @return
	 */
	List<IndentDetail>getAllIndents(Pageable pageable);

	/**
	 * @return
	 */
	long getTotalCountOfIndents();

	/**
	 * @param pageable
	 * @return
	 */
	List<PurchaseOrderDetail> getAllPos(Pageable pageable);

	/**
	 * @param pageable
	 * @return
	 */
	List<MaterialsReceivedData> getAllItemsReceivedData(Pageable pageable);

	/**
	 * @param pageable
	 * @return
	 */
	List<MaterialIssueData> getAllItemsChallanData(Pageable pageable);
	
	
	
}
