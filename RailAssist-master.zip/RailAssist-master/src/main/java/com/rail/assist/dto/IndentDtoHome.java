/**
 * 
 */
package com.rail.assist.dto;

import java.util.Date;

/**
 * @author Mahideep Tumati
 *
 * Created on Jul 10, 2018
 */
public class IndentDtoHome {
	
	private long id;
	
	private long indentId;
	
	private long itemId;
	
	private Date date;
	
	private String indentLoggedBy;
	
	private long quantityReq;	
	
	private long value;
	
	private String materialsRequiredAt;
	
	private String controllingOfifcer;
	
	private String title;
	
	private String description;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getIndentId() {
		return indentId;
	}

	public void setIndentId(long indentId) {
		this.indentId = indentId;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getIndentLoggedBy() {
		return indentLoggedBy;
	}

	public void setIndentLoggedBy(String indentLoggedBy) {
		this.indentLoggedBy = indentLoggedBy;
	}

	public long getQuantityReq() {
		return quantityReq;
	}

	public void setQuantityReq(long quantityReq) {
		this.quantityReq = quantityReq;
	}

	public long getValue() {
		return value;
	}

	public void setValue(long value) {
		this.value = value;
	}

	public String getMaterialsRequiredAt() {
		return materialsRequiredAt;
	}

	public void setMaterialsRequiredAt(String materialsRequiredAt) {
		this.materialsRequiredAt = materialsRequiredAt;
	}

	public String getControllingOfifcer() {
		return controllingOfifcer;
	}

	public void setControllingOfifcer(String controllingOfifcer) {
		this.controllingOfifcer = controllingOfifcer;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	

}
