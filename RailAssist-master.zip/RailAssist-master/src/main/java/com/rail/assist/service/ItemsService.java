package com.rail.assist.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;

import com.rail.assist.entities.ItemsData;
import com.rail.assist.entities.StockAvailable;

public interface ItemsService {

	List<ItemsData> getAllItems(int catId) throws Exception;
	
	//boolean addItems();

	boolean addItem(StockAvailable stockAvailable, ItemsData itemsData);


	
	
}
