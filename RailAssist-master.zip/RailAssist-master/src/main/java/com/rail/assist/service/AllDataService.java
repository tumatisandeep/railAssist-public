package com.rail.assist.service;

import java.util.Date;
import java.util.List;

import com.rail.assist.dto.AllDataDto;

public interface AllDataService {

	/**
	 * @param dateF
	 * @param dateT
	 * @param logged
	 * @return
	 */
	List<AllDataDto> getDataByDateAndloggedBy(Date dateF, Date dateT, boolean logged) throws Exception;

	/**
	 * @param selectedCategory
	 * @param pageCnt
	 * @return
	 * @throws Exception 
	 */
	List<AllDataDto> getAllDataWithCategory(int selectedCategory, int pageCnt) throws Exception;
	
	
	
}
