package com.rail.assist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rail.assist.entities.StockAvailable;


public interface StockAvailableRepository extends JpaRepository<StockAvailable,Long> {
	
	
	StockAvailable findByItemId(long id);
	
	StockAvailable findByItemIdAndQuantityAvailableGreaterThan(Long id,long noItemsAvailable);
	
	
	StockAvailable findByItemIdAndQuantityAvailableGreaterThanEqualAndQuantityAvailableLessThanEqual(long itemmId, Long long1,Long long2);
	
	List<StockAvailable> findByQuantityAvailableLessThanEqual(long stockAvailableLessThan);


	@Query("select count(*) from StockAvailable where itemId in(select itemId from ItemsData where groupId =?1 ) and quantityAvailable > 0  ")
	int findByItemGroupId(int groupId);
}



