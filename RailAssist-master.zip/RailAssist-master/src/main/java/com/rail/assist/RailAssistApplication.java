package com.rail.assist;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.ErrorMvcAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


@ImportResource({"classpath:jasper/META-INF/jasper.xml", "classpath:META-INF/spring-aop.xml"})
@SpringBootApplication(exclude = {ErrorMvcAutoConfiguration.class})
@EnableJpaRepositories
@PropertySource({"classpath:application.properties"})
public class RailAssistApplication extends SpringBootServletInitializer {


	private static final String key = "AsW47KW6ej5fb4d1"; // 128 bit key
	private static final String initVector = "RandomInitVector"; // 16 bytes IV

	private static final IvParameterSpec iv = new IvParameterSpec(initVector.getBytes(StandardCharsets.UTF_8));
	private static final SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");

	
	
	public static void main(String[] args) throws Exception {
		
		

	//read text file and get decrypted text
		
		String license=readLicenseFile();	
	    
		boolean isLicenseavailable=false;

	    // get ip and mac from this string by decrypting it
	    if(!license.equals("String not found"))
	    {
	    	
	   
		String decryptedText = decrypt(license);
		
		
			if (!decryptedText.equals("failed")) {

				String[] ipMacArray = getIpMacArray(decryptedText);

				// compare if system ip and system mac is correct as per license file
				isLicenseavailable = checkIfLicenseAvailable(ipMacArray);
			}
	    }
		//if(isLicenseavailable) {
			if(true) {
			
		SpringApplication.run(RailAssistApplication.class, args);
		}
		 
		else{
			accessDenied("E:/RailAssistApplication/LicenseFile/AccessDenied.txt");						
		}
	}
	
	private static void accessDenied(String string) throws IOException {

		File file = new File(string);
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String line;
		//System.out.println("Access denied");
		while((line=br.readLine())!=null )
		{
			System.out.println(line);
		}
		br.close();
		fr.close();
		
		
	}

	private static boolean checkIfLicenseAvailable(String[] ipMacArray) throws SocketException, UnknownHostException {
		InetAddress inetAddress = InetAddress.getLocalHost();
		//String ipAddr=inetAddress.getHostAddress();
		
		String ipAddr="192.168.1.4";
       // System.out.println("System's IP Address:- " + ipAddr);
        
        NetworkInterface network = NetworkInterface.getByInetAddress(inetAddress);
		
		byte[] mac = network.getHardwareAddress();
			
		
		StringBuilder sb = new StringBuilder();
		/*
		 * for (int i = 0; i < mac.length; i++) { sb.append(String.format("%02X%s",
		 * mac[i], (i < mac.length - 1) ? "-" : "")); }
		 */
	//	String macAddr=sb.toString();
		
		String macAddr=System.getProperty("user.name")+"-"+"B2-D0-6E-46-43-E7";
		
		//System.out.println("System's Mac address  is : "+macAddr);
		//System.out.println(ipMacArray[0]+"-----------"+ipMacArray[1]);
		if(ipAddr.equals(ipMacArray[0])&&macAddr.equals(ipMacArray[1]))
		return true;
		else
			return false;
		
	}

	private static String readLicenseFile() throws Exception {
		try{
		File file = new File("E:/RailAssistApplication/LicenseFile/License.lic");
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String line;
		int i = 0;
		String encryptedText = new String();
		while ((line = br.readLine()) != null) {
			if (i == 0)
				encryptedText = line;
		}
		br.close();
		fr.close();
		return encryptedText;
		
		}
		catch(Exception e)
		{
			
			return "String not found";
		}
	}

	private static String[] getIpMacArray(String decryptedText) {

		String[] ipMacArray = decryptedText.split("&&");

		//System.out.println(Arrays.toString(ipMacArray));

		String[] macAddr = ipMacArray[0].split("%%");
		String[] ipAddr = ipMacArray[1].split("%%");

		//System.out.println(Arrays.toString(macAddr) + "****" + Arrays.toString(ipAddr));

		String finalMac = new String();
		String finalIp = new String();
		for (int i = 0; i < ipAddr.length; i++) {
			if (i == 0)
				finalIp = ipAddr[i];

			else
				finalIp = finalIp + "." + ipAddr[i];

		}

		for (int i = 0; i < macAddr.length; i++) {
			if (i == 0)
				finalMac = macAddr[i];

			else
				finalMac = finalMac + "-" + macAddr[i];

		}

		//System.out.println(finalIp + "  " + finalMac);
		String finalIpMacArray[] = new String[2];
		finalIpMacArray[0] = finalIp;
		finalIpMacArray[1] = finalMac;

		return finalIpMacArray;
	}

	private static String decrypt(String encryptedText) throws Exception {

		try {
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);

			byte[] decodedEncryTxt = Base64.getDecoder().decode(encryptedText);

			byte[] original = cipher.doFinal(decodedEncryTxt);

			return new String(original, StandardCharsets.UTF_8);

		} catch (Exception ex) {
			
			return "failed";
		}

	}
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		
		return builder.sources(RailAssistApplication.class);
	}
	
}
