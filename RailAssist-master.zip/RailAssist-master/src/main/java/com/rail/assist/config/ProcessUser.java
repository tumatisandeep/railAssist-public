package com.rail.assist.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.rail.assist.entities.UserDetail;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.repository.UserLoginStatusRepository;
import com.rail.assist.service.UserService;

@Component
public class ProcessUser {

	@Autowired
	private UserService userService;

	@Autowired
	UserDetailsRepository userDetailsRepository;

	@Autowired
	UserLoginStatusRepository userLoginStatusRepository;

	

	public UsernamePasswordAuthenticationToken processUserLogin(String userName, String passWord)
			throws Exception {
		//System.out.println("userName :"+userName +passWord);
		

		UserDetail userDetailInfo1 = userDetailsRepository.findByUserMailIdAndUserPassword(userName, passWord);
		if (userDetailInfo1 == null) {
			throw new BadCredentialsException("User  not exists.");

		}

		/*if (userDetailInfo1.getUserLoginStatus().getUserLoginStatusId() != (long) AssistConstantsParameters.USER_LOGGED_IN_CURRENTLY) {
			UserLoginStatus userLoginStatus = userLoginStatusRepository
					.findOne((long) AssistConstantsParameters.USER_LOGGED_IN_CURRENTLY);

			userDetailInfo1.setUserLoginStatus(userLoginStatus);
			userDetailInfo1 = userDetailsRepository.save(userDetailInfo1);

		}
		*/
		
		

		List<GrantedAuthority> userRoles = userService.findAllRoles(userDetailInfo1);
		//System.out.println("userRoles :"+userRoles.toString());
		return new UsernamePasswordAuthenticationToken(userDetailInfo1, passWord, userRoles);

	}

	@Autowired
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	/*public void processUserLogout(UserDetail userAccInfo) {

		UserSessionHist userSession = new UserSessionHist();
		userSession.setLoginOrLogout((int) AssistConstantsParameters.USER_CURRENTLY_LOGGED_OUT);
		userSession.setCreatedBy(userAccInfo);
		userSession.setUserId(userAccInfo);

		userSession.setGroupId((int) userAccInfo.getGroupDetail().getGroupDetailsId());
		;
		userSessionHistRepository.save(userSession);

		UserLoginStatus userLoginStatus = userLoginStatusRepository.findOne((long) AssistConstantsParameters.USER_CURRENTLY_LOGGED_OUT);
		// userLoginStatus.setUserLoginStatusId(AssistConstantsParameters.USER_CURRENTLY_LOGGED_OUT);
		// System.out.println(userLoginStatus.getUserLoginStatusId()+"
		// "+userLoginStatus.getUserLoginStatusDesc());
		userAccInfo.setUserLoginStatus(userLoginStatus);
		userDetailsRepository.save(userAccInfo);
		// System.out.println("***********"+userAccInfo.getFirstName()+"LOGGED
		// OUT**********");

	}*/

}
