package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.UserType;


public interface UserTypeRepository extends JpaRepository<UserType,Long> {

	UserType findByUserTypeId(Integer valueOf);
	

}



