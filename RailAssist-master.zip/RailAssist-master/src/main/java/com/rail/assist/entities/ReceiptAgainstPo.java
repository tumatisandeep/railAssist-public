package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the receipt_against_po database table.
 * 
 */
@Entity
@Table(name="receipt_against_po")
@NamedQuery(name="ReceiptAgainstPo.findAll", query="SELECT r FROM ReceiptAgainstPo r")
public class ReceiptAgainstPo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="RECEIPT_AGAINST_PO_ID")
	private int receiptAgainstPoId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CHALLAN_DATE")
	private Date challanDate;

	@Column(name="CHALLAN_NUMBER")
	private String challanNumber;

	private String comments;

	private String description;

	@Column(name="IF_TRANSPORT_AVAILABLE")
	private int ifTransportAvailable;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INVOICE_DATE")
	private Date invoiceDate;

	@Column(name="INVOICE_NUMBER")
	private String invoiceNumber;

	@Column(name="IS_BILL_PASSED")
	private int isBillPassed;

	@Column(name="ITEM_NAME")
	private int itemName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_UPDATE")
	private Date lastUpdate;

	@Column(name="MATERIALS_TYPE")
	private int materialsType;

	private int quantity;

	@Column(name="RECEIPT_AGAINST_PO_FROM")
	private int receiptAgainstPoFrom;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="S_ORDER_DATE")
	private Date sOrderDate;

	@Column(name="S_ORDER_NUMBER")
	private String sOrderNumber;

	@Column(name="UPDATED_BY")
	private int updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="VCH_DATE")
	private Date vchDate;

	@Column(name="VCH_NUMBER")
	private int vchNumber;

	private int version;

	public ReceiptAgainstPo() {
	}

	public int getReceiptAgainstPoId() {
		return this.receiptAgainstPoId;
	}

	public void setReceiptAgainstPoId(int receiptAgainstPoId) {
		this.receiptAgainstPoId = receiptAgainstPoId;
	}

	public Date getChallanDate() {
		return this.challanDate;
	}

	public void setChallanDate(Date challanDate) {
		this.challanDate = challanDate;
	}

	public String getChallanNumber() {
		return this.challanNumber;
	}

	public void setChallanNumber(String challanNumber) {
		this.challanNumber = challanNumber;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getIfTransportAvailable() {
		return this.ifTransportAvailable;
	}

	public void setIfTransportAvailable(int ifTransportAvailable) {
		this.ifTransportAvailable = ifTransportAvailable;
	}

	public Date getInvoiceDate() {
		return this.invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceNumber() {
		return this.invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public int getIsBillPassed() {
		return this.isBillPassed;
	}

	public void setIsBillPassed(int isBillPassed) {
		this.isBillPassed = isBillPassed;
	}

	public int getItemName() {
		return this.itemName;
	}

	public void setItemName(int itemName) {
		this.itemName = itemName;
	}

	public Date getLastUpdate() {
		return this.lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public int getMaterialsType() {
		return this.materialsType;
	}

	public void setMaterialsType(int materialsType) {
		this.materialsType = materialsType;
	}

	public int getQuantity() {
		return this.quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getReceiptAgainstPoFrom() {
		return this.receiptAgainstPoFrom;
	}

	public void setReceiptAgainstPoFrom(int receiptAgainstPoFrom) {
		this.receiptAgainstPoFrom = receiptAgainstPoFrom;
	}

	public Date getSOrderDate() {
		return this.sOrderDate;
	}

	public void setSOrderDate(Date sOrderDate) {
		this.sOrderDate = sOrderDate;
	}

	public String getSOrderNumber() {
		return this.sOrderNumber;
	}

	public void setSOrderNumber(String sOrderNumber) {
		this.sOrderNumber = sOrderNumber;
	}

	public int getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getVchDate() {
		return this.vchDate;
	}

	public void setVchDate(Date vchDate) {
		this.vchDate = vchDate;
	}

	public int getVchNumber() {
		return this.vchNumber;
	}

	public void setVchNumber(int vchNumber) {
		this.vchNumber = vchNumber;
	}

	public int getVersion() {
		return this.version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

}