package com.rail.assist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.Category;

public interface CategoryRepository extends JpaRepository<Category, Integer>{
	
	List<Category> findByGroupId(int gId);

	Category findByCategoryId(int id);
	
}
