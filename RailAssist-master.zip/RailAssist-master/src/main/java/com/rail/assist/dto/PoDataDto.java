package com.rail.assist.dto;

public class PoDataDto {

	int rcNo;

	long indentNumber;

	long idNo;

	String desc;

	String partNumber;

	int folio;

	int Qty;

	int hsn;

	double basicRate;

	int gst;

	double airRate;

	double amount;

	String category;
	
	boolean poReceived;
	
	boolean isNull;

	long qtyRcvd;
	
	
	
	public long getQtyRcvd() {
		return qtyRcvd;
	}

	public void setQtyRcvd(long l) {
		this.qtyRcvd = l;
	}

	public boolean isNull() {
		return isNull;
	}

	public void setNull(boolean isNull) {
		this.isNull = isNull;
	}

	public boolean isPoReceived() {
		return poReceived;
	}

	public void setPoReceived(boolean poReceived) {
		this.poReceived = poReceived;
	}

	public int getRcNo() {
		return rcNo;
	}

	public long getIndentNumber() {
		return indentNumber;
	}

	public long getIdNo() {
		return idNo;
	}

	public String getDesc() {
		return desc;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public int getFolio() {
		return folio;
	}

	public int getQty() {
		return Qty;
	}

	public int getHsn() {
		return hsn;
	}

	public double getBasicRate() {
		return basicRate;
	}

	public int getGst() {
		return gst;
	}

	public double getAirRate() {
		return airRate;
	}

	public double getAmount() {
		return amount;
	}

	public String getCategory() {
		return category;
	}

	public void setRcNo(int rcNo) {
		this.rcNo = rcNo;
	}

	public void setIndentNumber(long indentNumber) {
		this.indentNumber = indentNumber;
	}

	public void setIdNo(long idNo) {
		this.idNo = idNo;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public void setFolio(int folio) {
		this.folio = folio;
	}

	public void setQty(int qty) {
		Qty = qty;
	}

	public void setHsn(int hsn) {
		this.hsn = hsn;
	}

	public void setBasicRate(double basicRate) {
		this.basicRate = basicRate;
	}

	public void setGst(int gst) {
		this.gst = gst;
	}

	public void setAirRate(double airRate) {
		this.airRate = airRate;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public void setCategory(String category) {
		this.category = category;
	}


	
	

}
