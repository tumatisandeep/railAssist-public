package com.rail.assist.scheduler;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.rail.assist.constants.AssistConstants;
import com.rail.assist.constants.AssistConstantsParameters;
import com.rail.assist.entities.IndentDetail;
import com.rail.assist.entities.ItemsData;
import com.rail.assist.entities.MailSentData;
import com.rail.assist.entities.MaterialIssueData;
import com.rail.assist.entities.MaterialsReceivedData;
import com.rail.assist.entities.PurchaseOrderDetail;
import com.rail.assist.entities.StockAvailable;
import com.rail.assist.fileGenerator.Block;
import com.rail.assist.fileGenerator.Board;
import com.rail.assist.fileGenerator.Table;
import com.rail.assist.repository.CategoryRepository;
import com.rail.assist.repository.GroupDetailRepository;
import com.rail.assist.repository.IndentDetailRepository;
import com.rail.assist.repository.ItemsDataRepository;
import com.rail.assist.repository.MailSentDataRepository;
import com.rail.assist.repository.MaterialsIssueDataRepository;
import com.rail.assist.repository.MaterialsReceivedDataRepository;
import com.rail.assist.repository.PoDetailRepository;
import com.rail.assist.repository.StockAvailableRepository;
import com.rail.assist.repository.VendorsDataRepository;

@Component
@EnableScheduling
public class Scheduler {

	@Autowired
	StockAvailableRepository stockAvailableRepository;

	@Autowired
	ItemsDataRepository itemsDataRepository;

	@Autowired
	IndentDetailRepository indentDetailRepository;

	@Autowired
	PoDetailRepository poDetailRepository;

	@Autowired
	VendorsDataRepository vendorsDataRepository;

	@Autowired
	MaterialsReceivedDataRepository materialsReceivedDataRepository;

	@Autowired
	MaterialsIssueDataRepository materialsIssuedDataRepository;

	@Autowired
	GroupDetailRepository groupDetailRepository;

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	private JavaMailSender sender;

	@Autowired
	private AssistConstants assistConstants;
	
	@Autowired
	private MailSentDataRepository mailSentDataRepository;

	@Scheduled(fixedDelay = (4 * 60 * 1000))
	public void checkForStockUpdates() throws Exception {

		LocalTime time = LocalTime.now();
		int hour = time.getHour();
		
		
		
		DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		
		String dateString = formatter.format(new Date());

		
		MailSentData mailData=mailSentDataRepository.findByisMailSentAndDate(AssistConstantsParameters.MAIL_SENT, dateString);


		if (mailData==null&&hour>Integer.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.MAIL_SCHEDULED_TIME_HOUR))) {

			// stock of all items whose qty is <5

			System.out.println("**************** Scheduler is running***************");

			List<StockAvailable> stockAvailableData = stockAvailableRepository.findAll();

			Long[] itemIds = new Long[stockAvailableData.size()];
			int i = 0;
			for (StockAvailable itemsData2 : stockAvailableData) {

				itemIds[i++] = itemsData2.getItemId();
			}

			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

			Date todayDate = new Date();

			List<String> indentDataTableHeader = Arrays.asList("INDENT ID", "ITEM ID", "PRICE", "CONTROLLING OFFICER",
					"QUANTITY", "DATE");

			List<String> poDataTableHeader = Arrays.asList("PO NUMBER", "NUMBER OF INDENTS", "PO ISSUED BY", "PO DATE",
					"IMP DUE DATE", "IND DUE DATE", "OMC DUE DATE");

			List<String> itemsRcvdTableHeader = Arrays.asList("ITEM ID", "PO NUMBER", "QUANTITY", "DATE");

			List<String> itemsIssuedTableHeader = Arrays.asList("CHALLAN NUMBER", "NUMBER OF ITEMS", "ISSUED BY ",
					"ISSUED TO");

			List<String> stockLessThanTableHeader = Arrays.asList("ITEM ID", "STOCK AVAILABLE");

			List<String> itemsNotPresenTableHeader = Arrays.asList("ITEM ID", "PART NUMBER", "DESCRIPTION", "GROUP",
					"SUB CATEGORY");

			//System.out.println("------------------------" + todayDate + "++++++++++++++++++++++++++");

			Calendar now = Calendar.getInstance();
			now.set(Calendar.MINUTE, 0);
			now.set(Calendar.SECOND, 0);
			now.set(Calendar.HOUR_OF_DAY, 0);

			Date todayDateObj = now.getTime();
			//System.out.println("========================" + todayDateObj + "=======================");

			now.add(Calendar.DATE, 1);

			Date nextDayDateObj = now.getTime();

			List<IndentDetail> indentDataForToday = indentDetailRepository
					.findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(todayDateObj,nextDayDateObj);

			

			List<List<String>> list1 = new ArrayList<>();

			if (indentDataForToday.isEmpty()) {

				List<String> strlist = new ArrayList<>();

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				list1.add(strlist);

			}

			else {

				for (IndentDetail data : indentDataForToday) {

					List<String> strList = new ArrayList<>();

					strList.add(String.valueOf(data.getIndentId()));

					strList.add(String.valueOf(data.getItemId()));

					strList.add(String.format("%.2f",data.getValue()) );

			/*		if (data.getControllingOfficer() == Integer.valueOf(
							assistConstants.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_ADEN)))
						strList.add(assistConstants
								.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_ADEN_DESC));

					else 
						strList.add(assistConstants
								.getParameterValue(AssistConstantsParameters.CONTROLLING_OFFICER_XEN_DESC));
			 */
					strList.add(String.valueOf(data.getControllingOfficer()));
					strList.add(String.valueOf(data.getQuantityReq()));

					strList.add(String.valueOf(dateFormat.format(data.getDate())));

					list1.add(strList);

				}
			}

			List<List<String>> list2 = new ArrayList<>();

			List<PurchaseOrderDetail> poDataForToday = poDetailRepository
					.findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(todayDateObj,nextDayDateObj);
			if (poDataForToday.isEmpty()) {

				List<String> strlist = new ArrayList<>();

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				list2.add(strlist);

			}

			else {

				for (PurchaseOrderDetail data : poDataForToday) {

					List<String> strList = new ArrayList<>();

					strList.add(data.getPoNumber());

					strList.add(String.valueOf(data.getNumberOfIndents()));

					strList.add(vendorsDataRepository.findById(data.getSuppliedBy()).getSupplierDesc());

					strList.add(dateFormat.format(data.getOpenedOnDate()));

					strList.add(dateFormat.format(data.getImpDueDate()));

					strList.add(dateFormat.format(data.getIndDueDate()));

					strList.add(dateFormat.format(data.getOmcDueDate()));

					list2.add(strList);

				}

			}

			List<List<String>> list3 = new ArrayList<>();

			List<MaterialsReceivedData> receivedDataForToday = materialsReceivedDataRepository
					.findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(todayDateObj,nextDayDateObj);

			if (receivedDataForToday.isEmpty()) {

				List<String> strlist = new ArrayList<>();

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				list3.add(strlist);

			}

			else {

				for (MaterialsReceivedData data : receivedDataForToday) {

					List<String> strList = new ArrayList<>();

					strList.add(String.valueOf(data.getItemId()));

					strList.add(data.getPoNumber());

					strList.add(String.valueOf(data.getNumberOfItemsReceived()));

					strList.add(dateFormat.format(data.getCreatedon()));

					list3.add(strList);

				}

			}

			List<List<String>> list4 = new ArrayList<>();

			List<MaterialIssueData> issuedDataForToday = materialsIssuedDataRepository
					.findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(todayDateObj,nextDayDateObj);

			if (issuedDataForToday.isEmpty()) {

				List<String> strlist = new ArrayList<>();

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");

				list4.add(strlist);

			}

			else {

				for (MaterialIssueData data : issuedDataForToday) {

					List<String> strList = new ArrayList<>();

					strList.add(data.getChallanNumber());

					strList.add(String.valueOf(data.getTotalNoOfItemsIssued()));

					strList.add(data.getMaterialIssueTo());

					if (data.getMaterialIssuedBy() == Integer.valueOf(
							assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_I_RYP)))
						strList.add("Ward I");
					else
						strList.add("WARD II");

					list4.add(strList);

				}

			}

			List<List<String>> list5 = new ArrayList<>();

			List<StockAvailable> itemsStockLess = stockAvailableRepository.findByQuantityAvailableLessThanEqual(Long
					.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.STOCK_AVAILABLE_LESS_THAN)));

			if (itemsStockLess.isEmpty()) {

				List<String> strlist = new ArrayList<>();

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");
				list5.add(strlist);
			}

			else {
				for (StockAvailable data : itemsStockLess) {

					List<String> strlist = new ArrayList<>();

					strlist.add(String.valueOf(data.getItemId()));

					strlist.add(String.valueOf(data.getQuantityAvailable()));

					list5.add(strlist);

				}

			}

			List<List<String>> list6 = new ArrayList<>();
			List<ItemsData> itemsData = itemsDataRepository.findByItemIdNotIn(itemIds);

			if (itemsData.isEmpty()) {

				List<String> strlist = new ArrayList<>();

				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");
				strlist.add("NOT AVAILABLE");

				strlist.add("NOT AVAILABLE");
				strlist.add("NOT AVAILABLE");

				list6.add(strlist);

			} else {
				for (ItemsData data : itemsData) {

					List<String> strlist = new ArrayList<>();

					strlist.add(String.valueOf(data.getItemId()));
					strlist.add(data.getPartNumber());
					strlist.add(data.getDescription());
					strlist.add(groupDetailRepository.findBygroupId(data.getGroupId()).getGroupDesc());
					// System.out.println(data.getCategory_id());

					strlist.add(categoryRepository.findByCategoryId(data.getCategory_id()).getCategoryDesc());// got
																												// error

				}

			}

			// table 1 indent data

			Board board = new Board(200);
			Table table = new Table(board, 200, indentDataTableHeader, list1);
			table.setGridMode(Table.GRID_COLUMN);
			// setting width and data-align of columns
			List<Integer> colWidthsList = Arrays.asList(18, 14, 17, 24, 19, 19);
			List<Integer> colAlignList = Arrays.asList(Block.DATA_CENTER, Block.DATA_CENTER, Block.DATA_CENTER,
					Block.DATA_CENTER, Block.DATA_CENTER, Block.DATA_CENTER);
			table.setColWidthsList(colWidthsList);
			table.setColAlignsList(colAlignList);

			Block tableBlock = table.tableToBlocks();
			board.setInitialBlock(tableBlock);
			board.build();
			String tableString = board.getPreview();
		//	System.out.println(tableString);

			// Table 2 po data

			Board board1 = new Board(200);
			Table table1 = new Table(board1, 200, poDataTableHeader, list2);
			table1.setGridMode(Table.GRID_COLUMN);
			// setting width and data-align of columns
			List<Integer> colWidthsList1 = Arrays.asList(20, 12, 14, 14, 14, 18, 18);
			List<Integer> colAlignList1 = Arrays.asList(Block.DATA_CENTER, Block.DATA_CENTER, Block.DATA_CENTER,
					Block.DATA_CENTER, Block.DATA_CENTER, Block.DATA_CENTER, Block.DATA_CENTER);
			table1.setColWidthsList(colWidthsList1);
			table1.setColAlignsList(colAlignList1);

			Block tableBlock1 = table1.tableToBlocks();
			board1.setInitialBlock(tableBlock1);
			board1.build();
			String tableString1 = board1.getPreview();
			//System.out.println(tableString1);

			// Table 3 items received data

			Board board2 = new Board(150);

			Table table2 = new Table(board2, 90, itemsRcvdTableHeader, list3);
			table2.setGridMode(Table.GRID_COLUMN);
			// setting width and data-align of columns
			List<Integer> colWidthsList2 = Arrays.asList(25, 15, 25, 13);
			List<Integer> colAlignList2 = Arrays.asList(Block.DATA_CENTER, Block.DATA_CENTER, Block.DATA_CENTER,
					Block.DATA_CENTER);
			table2.setColWidthsList(colWidthsList2);
			table2.setColAlignsList(colAlignList2);

			Block tableBlock2 = table2.tableToBlocks();
			board2.setInitialBlock(tableBlock2);
			board2.build();
			String tableString2 = board2.getPreview();
//			System.out.println(tableString2);

			// Table 4 items issued data

			Board board3 = new Board(120);

			Table table3 = new Table(board3, 90, itemsIssuedTableHeader, list4);
			table3.setGridMode(Table.GRID_COLUMN);
			// setting width and data-align of columns
			List<Integer> colWidthsList3 = Arrays.asList(25, 15, 25, 13);
			List<Integer> colAlignList3 = Arrays.asList(Block.DATA_CENTER, Block.DATA_CENTER, Block.DATA_CENTER,
					Block.DATA_CENTER);
			table3.setColWidthsList(colWidthsList3);
			table3.setColAlignsList(colAlignList3);

			Block tableBlock3 = table3.tableToBlocks();
			board3.setInitialBlock(tableBlock3);
			board3.build();
			String tableString3 = board3.getPreview();
			//System.out.println(tableString3);

			// Table 5 Stock less than 5 data

			Board board4 = new Board(120);

			Table table4 = new Table(board4, 90, stockLessThanTableHeader, list5);
			table4.setGridMode(Table.GRID_COLUMN);
			// setting width and data-align of columns
			List<Integer> colWidthsList4 = Arrays.asList(25, 15);
			List<Integer> colAlignList4 = Arrays.asList(Block.DATA_CENTER, Block.DATA_CENTER);
			table4.setColWidthsList(colWidthsList4);
			table4.setColAlignsList(colAlignList4);

			Block tableBlock4 = table4.tableToBlocks();
			board4.setInitialBlock(tableBlock4);
			board4.build();
			String tableString4 = board4.getPreview();
			//System.out.println(tableString4);

			String indentData = "INDENT DETAILS:";
			String poData = "PURCHASE ORDER DETAILS:";
			String itemsRcvdData = "ITEMS RECEIVED DETAILS:";

			String itemsIssuedData = "ITEMS ISSUED DETAILS:";

			String stockData = "ITEMS WITH STOCK LESS THAN 5 DETAILS:";

			String heading = "UPDATE OF ALL DETAILS ON DATE" + " :: " + dateFormat.format(new Date());

			FileWriter out = new FileWriter(
					assistConstants.getParameterValue(AssistConstantsParameters.MAIL_FILE_LOCATION));

			BufferedWriter bw = new BufferedWriter(out);

			bw.newLine();
			bw.write("\t\t\t\t\t\t\t\t");
			bw.write(heading);
			bw.newLine();
			bw.newLine();

			bw.newLine();

			bw.write(indentData);
			bw.newLine();
			bw.write(tableString);
			// second table
			bw.newLine();
			bw.write(poData);
			bw.newLine();
			bw.write(tableString1);
			// third table
			bw.newLine();
			bw.write(itemsRcvdData);
			bw.newLine();
			bw.write(tableString2);

			// fourth table
			bw.newLine();
			bw.write(itemsIssuedData);
			bw.newLine();
			bw.write(tableString3);

			// fifth table
			bw.newLine();
			bw.write(stockData);
			bw.newLine();
			bw.write(tableString4);

			bw.close();
			out.close();

			MimeMessage message = sender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			try {

				//System.out.println("inside try block");
				String[] mailIds=assistConstants.getParameterValue(AssistConstantsParameters.RECEIVER_MAIL_ADDRESS).split(",");
				helper.setTo(mailIds);
			
				helper.setText("PFA of the updates of " + dateFormat.format(todayDate) + ".");
				helper.setSubject("Updates of " + dateFormat.format(todayDate) + ".");
				// ClassPathResource file = new
				// ClassPathResource("/Users/mahideeptumati/Desktop/RailAssist.zip");

				FileSystemResource file = new FileSystemResource(
						assistConstants.getParameterValue(AssistConstantsParameters.MAIL_FILE_LOCATION)); // location
																											// where
																											// we
																											// write
																											// into
																											// file

				helper.addAttachment(file.getFilename(), file);

				
			
			sender.send(message);

			MailSentData setMailData=new MailSentData();
			
			setMailData.setIsMailSent(AssistConstantsParameters.MAIL_SENT);
			setMailData.setDate(dateString);
			setMailData.setSentTime(new Date());
			setMailData.setSuccessMessage(AssistConstantsParameters.MAIL_SENT_SUCCESSFULLY);
			
			mailSentDataRepository.save(setMailData);
			
			System.out.println("Mail sent. Check for the mail box of "+assistConstants.getParameterValue(AssistConstantsParameters.RECEIVER_MAIL_ADDRESS) );

			}
			catch(Exception e) {
				MailSentData setMailData=new MailSentData();
				
				setMailData.setIsMailSent(AssistConstantsParameters.MAIL_NOT_SENT);
				setMailData.setDate(dateString);
				setMailData.setSentTime(new Date());
				
				setMailData.setSuccessMessage(e.getClass().getCanonicalName());
				
				mailSentDataRepository.save(setMailData);
				e.printStackTrace();
				throw e;
			}
		}
		else {
			System.out.println("Mail already sent or its not time to send !!");
		}

	}
}