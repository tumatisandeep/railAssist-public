package com.rail.assist.dto;

import java.util.Date;

public class IndentPreviewDto {
	
	
	private long itemId;
	
	private long indentId;
	
	private Date date;
	
	private int serialNumber;
	
	private String indentor;
	
	private String consignee;
	
	private long consigneeCode;
	
	private String matReqAt;
	
	private String depot;
	
	private int qtyIndented;
	
	private String units;
	
	private String alocation;
	
	private String desc;
	
	private String purpose;
	
	
	private Double rate;
	
	private long value;
	
	private String lastpurchaseDetails;
	
	private int oaIndents;
	
	private int oaPo;
	
	private int qtyAvailable;
	
	private int consumptionYear1;
	
	private int consumptionYear2;

	private int consumptionYear3;
	
	private String oSindentsData1;
	
	private String oSindentsData2;

	private String oSindentsData3;
	
	private String oSindentsData4;

	private String oSPoData1;
	
	private String oSPoData2;

	private String oSPoData3;
	
	private String oSPoData4;
	
	private String oSPoData1Date;
	
	private String oSPoData2Date;

	private String oSPoData3Date;
	
	private String oSPoData4Date;
	
	private int likelySupplier;
	
	private boolean articleEnclosed;
	
	private String financialYear;
	
	private String indentingOfficer;
	
	private String controllingOfficer;
	
	private String approvingOfficer;

	private int indentType;
	
	
	private String likelySupplierDesc;

	public int getIndentType() {
		return indentType;
	}

	public void setIndentType(int indentType) {
		this.indentType = indentType;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public long getIndentId() {
		return indentId;
	}

	public void setIndentId(long l) {
		this.indentId = l;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getIndentor() {
		return indentor;
	}

	public void setIndentor(String indentor) {
		this.indentor = indentor;
	}

	public String getConsignee() {
		return consignee;
	}

	public void setConsignee(String consignee) {
		this.consignee = consignee;
	}

	public long getConsigneeCode() {
		return consigneeCode;
	}

	public void setConsigneeCode(long consigneeCode) {
		this.consigneeCode = consigneeCode;
	}

	public String getMatReqAt() {
		return matReqAt;
	}

	public void setMatReqAt(String matReqAt) {
		this.matReqAt = matReqAt;
	}

	public String getDepot() {
		return depot;
	}

	public void setDepot(String depot) {
		this.depot = depot;
	}

	public int getQtyIndented() {
		return qtyIndented;
	}

	public void setQtyIndented(int qtyIndented) {
		this.qtyIndented = qtyIndented;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getAlocation() {
		return alocation;
	}

	public void setAlocation(String alocation) {
		this.alocation = alocation;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getLastpurchaseDetails() {
		return lastpurchaseDetails;
	}

	public void setLastpurchaseDetails(String lastpurchaseDetails) {
		this.lastpurchaseDetails = lastpurchaseDetails;
	}

	public int getOaIndents() {
		return oaIndents;
	}

	public void setOaIndents(int oaIndents) {
		this.oaIndents = oaIndents;
	}

	public int getOaPo() {
		return oaPo;
	}

	public void setOaPo(int oaPo) {
		this.oaPo = oaPo;
	}

	public int getQtyAvailable() {
		return qtyAvailable;
	}

	public void setQtyAvailable(int qtyAvailable) {
		this.qtyAvailable = qtyAvailable;
	}

	public int getConsumptionYear1() {
		return consumptionYear1;
	}

	public void setConsumptionYear1(int consumptionYear1) {
		this.consumptionYear1 = consumptionYear1;
	}

	public int getConsumptionYear2() {
		return consumptionYear2;
	}

	public void setConsumptionYear2(int consumptionYear2) {
		this.consumptionYear2 = consumptionYear2;
	}

	public int getConsumptionYear3() {
		return consumptionYear3;
	}

	public void setConsumptionYear3(int consumptionYear3) {
		this.consumptionYear3 = consumptionYear3;
	}

	public String getoSindentsData1() {
		return oSindentsData1;
	}

	public void setoSindentsData1(String oSindentsData1) {
		this.oSindentsData1 = oSindentsData1;
	}

	public String getoSindentsData2() {
		return oSindentsData2;
	}

	public void setoSindentsData2(String oSindentsData2) {
		this.oSindentsData2 = oSindentsData2;
	}

	public String getoSindentsData3() {
		return oSindentsData3;
	}

	public void setoSindentsData3(String oSindentsData3) {
		this.oSindentsData3 = oSindentsData3;
	}

	public String getoSindentsData4() {
		return oSindentsData4;
	}

	public void setoSindentsData4(String oSindentsData4) {
		this.oSindentsData4 = oSindentsData4;
	}

	public String getoSPoData1() {
		return oSPoData1;
	}

	public void setoSPoData1(String oSPoData1) {
		this.oSPoData1 = oSPoData1;
	}

	public String getoSPoData2() {
		return oSPoData2;
	}

	public void setoSPoData2(String oSPoData2) {
		this.oSPoData2 = oSPoData2;
	}

	public String getoSPoData3() {
		return oSPoData3;
	}

	public void setoSPoData3(String oSPoData3) {
		this.oSPoData3 = oSPoData3;
	}

	public String getoSPoData4() {
		return oSPoData4;
	}

	public void setoSPoData4(String oSPoData4) {
		this.oSPoData4 = oSPoData4;
	}

	public int getLikelySupplier() {
		return likelySupplier;
	}

	public void setLikelySupplier(int likelySupplier2) {
		this.likelySupplier = likelySupplier2;
	}

	public boolean isArticleEnclosed() {
		return articleEnclosed;
	}

	public void setArticleEnclosed(boolean b) {
		this.articleEnclosed = b;
	}

	public String getFinancialYear() {
		return financialYear;
	}

	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}

	public String getIndentingOfficer() {
		return indentingOfficer;
	}

	public void setIndentingOfficer(String indentingOfficer) {
		this.indentingOfficer = indentingOfficer;
	}

	public String getControllingOfficer() {
		return controllingOfficer;
	}

	public void setControllingOfficer(String controllingOfficer2) {
		this.controllingOfficer = controllingOfficer2;
	}

	public String getApprovingOfficer() {
		return approvingOfficer;
	}

	public void setApprovingOfficer(String approvingOfficer) {
		this.approvingOfficer = approvingOfficer;
	}
	

	public double getRate() {
		return rate;
	}

	public long getValue() {
		return value;
	}

	public void setRate(Double double1) {
		this.rate = double1;
	}

	public void setValue(long value) {
		this.value = value;
	}
	
	

	public String getoSPoData1Date() {
		return oSPoData1Date;
	}

	public String getoSPoData2Date() {
		return oSPoData2Date;
	}

	public String getoSPoData3Date() {
		return oSPoData3Date;
	}

	public String getoSPoData4Date() {
		return oSPoData4Date;
	}

	public void setoSPoData1Date(String oSPoData1Date) {
		this.oSPoData1Date = oSPoData1Date;
	}

	public void setoSPoData2Date(String oSPoData2Date) {
		this.oSPoData2Date = oSPoData2Date;
	}

	public void setoSPoData3Date(String oSPoData3Date) {
		this.oSPoData3Date = oSPoData3Date;
	}

	public void setoSPoData4Date(String oSPoData4Date) {
		this.oSPoData4Date = oSPoData4Date;
	}

	public String getLikelySupplierDesc() {
		return likelySupplierDesc;
	}

	public void setLikelySupplierDesc(String likelySupplierDesc) {
		this.likelySupplierDesc = likelySupplierDesc;
	}

	@Override
	public String toString() {
		return "IndentPreviewDto [itemId=" + itemId + ", indentId=" + indentId + ", date=" + date + ", serialNumber="
				+ serialNumber + ", indentor=" + indentor + ", consignee=" + consignee + ", consigneeCode="
				+ consigneeCode + ", matReqAt=" + matReqAt + ", depot=" + depot + ", qtyIndented=" + qtyIndented
				+ ", units=" + units + ", alocation=" + alocation + ", desc=" + desc + ", purpose=" + purpose
				+ ", lastpurchaseDetails=" + lastpurchaseDetails + ", oaIndents=" + oaIndents + ", oaPo=" + oaPo
				+ ", qtyAvailable=" + qtyAvailable + ", consumptionYear1=" + consumptionYear1 + ", consumptionYear2="
				+ consumptionYear2 + ", consumptionYear3=" + consumptionYear3 + ", oSindentsData1=" + oSindentsData1
				+ ", oSindentsData2=" + oSindentsData2 + ", oSindentsData3=" + oSindentsData3 + ", oSindentsData4="
				+ oSindentsData4 + ", oSPoData1=" + oSPoData1 + ", oSPoData2=" + oSPoData2 + ", oSPoData3=" + oSPoData3
				+ ", oSPoData4=" + oSPoData4 + ", likelySupplier=" + likelySupplier + ", articleEnclosed="
				+ articleEnclosed + ", financialYear=" + financialYear + ", indentingOfficer=" + indentingOfficer
				+ ", controllingOfficer=" + controllingOfficer + ", approvingOfficer=" + approvingOfficer + "]";
	}

	
	
	
	
	
}
