package com.rail.assist.dto;

import java.util.Date;

public class IndentDto {

	private int id;
	
	private long indentId;

	private long consignee;

	private long indentor;

	private Date date;

	private int materialsRequiredAt;

	private int depot;

	private long quantityReq;

	private String units;

	private int acceptablemake;

	private String allocation;

	private long rate;

	private String value;

	private String purpose;

	private String indentLoggedBy;
	
	private Date indentDate;
	
	private boolean isPoReceived;
	
	
	public String getIndentLoggedBy() {
		return indentLoggedBy;
	}

	public void setIndentLoggedBy(String string) {
		this.indentLoggedBy = string;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getIndentId() {
		return indentId;
	}

	public void setIndentId(long indentId) {
		this.indentId = indentId;
	}

	public long getConsignee() {
		return consignee;
	}

	public void setConsignee(long consignee) {
		this.consignee = consignee;
	}

	public long getIndentor() {
		return indentor;
	}

	public void setIndentor(long indentor) {
		this.indentor = indentor;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getMaterialsRequiredAt() {
		return materialsRequiredAt;
	}

	public void setMaterialsRequiredAt(int materialsRequiredAt) {
		this.materialsRequiredAt = materialsRequiredAt;
	}

	public int getDepot() {
		return depot;
	}

	public void setDepot(int depot) {
		this.depot = depot;
	}

	public long getQuantityReq() {
		return quantityReq;
	}

	public void setQuantityReq(long quantityReq) {
		this.quantityReq = quantityReq;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public int getAcceptablemake() {
		return acceptablemake;
	}

	public void setAcceptablemake(int acceptablemake) {
		this.acceptablemake = acceptablemake;
	}

	public String getAllocation() {
		return allocation;
	}

	public void setAllocation(String allocation) {
		this.allocation = allocation;
	}

	public long getRate() {
		return rate;
	}

	public void setRate(long rate) {
		this.rate = rate;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	
	
	
	public Date getindentDate() {
		return indentDate;
	}

	public boolean isPoReceived() {
		return isPoReceived;
	}

	public void setIndentDate(Date indentData) {
		this.indentDate = indentData;
	}

	public void setPoReceived(boolean isPoReceived) {
		this.isPoReceived = isPoReceived;
	}

	@Override
	public String toString() {
		return "IndentDto [indentId=" + indentId + ", consignee=" + consignee + ", indentor=" + indentor + ", date="
				+ date + ", materialsRequiredAt=" + materialsRequiredAt + ", depot=" + depot + ", quantityReq="
				+ quantityReq + ", units=" + units + ", acceptablemake=" + acceptablemake + ", allocation=" + allocation
				+ ", rate=" + rate + ", value=" + value + ", purpose=" + purpose + "]";
	}

}