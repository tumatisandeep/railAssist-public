package com.rail.assist.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.rail.assist.dto.IndentDataDto;
import com.rail.assist.dto.ItemsReceivedDtoHome;
import com.rail.assist.entities.MaterialsReceivedData;

public interface ItemsReceivedService {

	MaterialsReceivedData getItemReceivedDetails(long id);

	/**
	 * @param itemId
	 * @param quantityReceived
	 * @param dateReceived
	 * @param poNumber
	 * @return
	 * @throws Exception 
	 */
	boolean addItemsReceivedData(long itemId, int quantityReceived, Date dateReceived, String poIndentNumber) throws Exception;
	
	
	
}
