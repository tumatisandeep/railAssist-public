package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The persistent class for the indent_details database table.
 * 
 */
@Entity
@Table(name = "STOCK_AVAILABLE")
@NamedQuery(name = "StockAvailable.findAll", query = "SELECT i FROM ItemsData i")
public class StockAvailable implements Serializable {
	private static final long serialVersionUID = 1L;

	

	@Id
	@Column(name = "ITEM_ID")
	private long itemId;

	@Column(name = "QUANTITY_AVAILABLE")
	private long quantityAvailable;

	

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_UPDATE")
	private Date lastUpdate;



	
	@Temporal(TemporalType.DATE)
	@Column(name = "CREATED_ON")
	private Date createdOn;
	
	
	@Transient
	@JsonProperty("dataPresent")
	private boolean dataPresent;
	
	
	
	
	public boolean isDataPresent() {
		return dataPresent;
	}



	public void setDataPresent(boolean dataPresent) {
		this.dataPresent = dataPresent;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	public long getItemId() {
		return itemId;
	}



	public long getQuantityAvailable() {
		return quantityAvailable;
	}



	public Date getLastUpdate() {
		return lastUpdate;
	}



	public void setItemId(long itemId) {
		this.itemId = itemId;
	}



	public void setQuantityAvailable(long quantityAvailable) {
		this.quantityAvailable = quantityAvailable;
	}



	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}



	public Date getCreatedOn() {
		return createdOn;
	}



	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	
	

	


}