package com.rail.assist.dto;

import org.apache.poi.ss.formula.functions.T;

public class ItemsGroupWiseData implements Comparable<ItemsGroupWiseData> {
	
	
	private int groupId;
	
	private long totalCount;
	
	private long availableStock;

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(long l) {
		this.totalCount = l;
	}

	public long getAvailableStock() {
		return availableStock;
	}

	public void setAvailableStock(int availableStock) {
		this.availableStock = availableStock;
	}

	
	

	@Override
	public int compareTo(ItemsGroupWiseData item) {
		return this.getGroupId()-item.getGroupId();
	}
	
	

}
