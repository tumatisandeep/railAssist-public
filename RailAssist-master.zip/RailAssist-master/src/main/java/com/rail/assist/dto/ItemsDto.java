package com.rail.assist.dto;

public class ItemsDto {

	
	
	private int id;
	private long itemId;
	private String description;
	private String partNumber;
	public int getId() {
		return id;
	}
	public long getItemId() {
		return itemId;
	}
	public String getDescription() {
		return description;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setItemId(long itemId) {
		this.itemId = itemId;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	
	
	
}
