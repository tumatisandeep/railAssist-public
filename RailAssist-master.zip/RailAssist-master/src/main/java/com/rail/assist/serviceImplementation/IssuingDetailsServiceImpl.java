package com.rail.assist.serviceImplementation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rail.assist.config.CurrentUser;
import com.rail.assist.constants.AssistConstants;
import com.rail.assist.constants.AssistConstantsParameters;
import com.rail.assist.entities.IndentPoRelation;
import com.rail.assist.entities.ItemsData;
import com.rail.assist.entities.MaterialIssueData;
import com.rail.assist.entities.MaterialsIssueRelation;
import com.rail.assist.entities.StockAvailable;
import com.rail.assist.repository.GenderRepository;
import com.rail.assist.repository.IndentPoRepository;
import com.rail.assist.repository.ItemsDataRepository;
import com.rail.assist.repository.MaterialsIssueDataRepository;
import com.rail.assist.repository.MaterialsIssueRelationRepository;
import com.rail.assist.repository.StockAvailableRepository;
import com.rail.assist.repository.UserAccountStatusRepository;
import com.rail.assist.repository.UserDesignationRepository;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.repository.UserLoginStatusRepository;
import com.rail.assist.service.IssuingDetailsService;

@Service
public class IssuingDetailsServiceImpl implements IssuingDetailsService {

	@Autowired
	UserDesignationRepository userDesignationRepository;

	@Autowired
	GenderRepository genderRepository;

	@Autowired
	UserLoginStatusRepository userLoginStatusRepository;

	@Autowired
	UserAccountStatusRepository userAccountStatusRepository;

	@Autowired
	UserDetailsRepository userDetailsRepository;

	@Autowired
	MaterialsIssueDataRepository materialsIssueDataRepository;

	@Autowired
	ItemsDataRepository itemsDataRepository;

	@Autowired
	MaterialsIssueRelationRepository materialsIssueRelationRepository;

	@Autowired
	private AssistConstants assistConstants;

	@Autowired
	private StockAvailableRepository stockAvailableRepository;

	@Autowired
	private IndentPoRepository indentPoRepository;
	
	@Autowired
	private CurrentUser currentUser;

	public List<Map<String, String>> printChallan(long challanId) throws Exception{

		try {
			MaterialIssueData materialsIssueData = materialsIssueDataRepository.findByMaterialIssueId(challanId);

			//System.out.println(materialsIssueData.toString());

			List<MaterialsIssueRelation> materialsissuedData = materialsIssueRelationRepository
					.findByUniqueRelationId(materialsIssueData.getUniqueRelationNo());

			List<Map<String, String>> materialsIssueList = new ArrayList<>();

			HashMap<String, List<Map<String, String>>> materialsIssueListHashMap = new HashMap<>();

			for (MaterialsIssueRelation data : materialsissuedData) {
				Map<String, String> transMap = new HashMap<>();
				
				//System.out.println(data.getItemId()+" item id");

				ItemsData itemsData = itemsDataRepository.findByItemId(data.getItemId());

				if (materialsIssueList.isEmpty()) {
					//System.out.println("inside list empty loop");
					
					transMap.put("partNumber", itemsData.getPartNumber());

					transMap.put("itemId", String.valueOf(itemsData.getItemId()));

					transMap.put("quantity", String.valueOf(data.getQtyIssued()));

					transMap.put("description", itemsData.getDescription());

					materialsIssueList.add(transMap);
				} else {
					//System.out.println("list is not empty");
					
					boolean found = false;
					for (Map<String, String> map : materialsIssueList) {
						if (map.get("itemId").equals(String.valueOf(itemsData.getItemId()))) {
							//System.out.println("same item found");
							
							int prev = Integer.valueOf(map.get("quantity"));
							map.put("quantity", String.valueOf(prev + data.getQtyIssued()));
							found = true;
							break;
						}

					}
					if (!found) {

					//	System.out.println("same item not found");
						
						transMap.put("partNumber", itemsData.getPartNumber());

						transMap.put("itemId", String.valueOf(itemsData.getItemId()));

						transMap.put("quantity", String.valueOf(data.getQtyIssued()));

						transMap.put("description", itemsData.getDescription());

						materialsIssueList.add(transMap);

					}
				}
			}

			//System.out.println(materialsIssueList);
			
			//materialsIssueListHashMap.put(materialsIssueData.getChallanNumber(), materialsIssueList);

			return materialsIssueList;
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}
	}

	
	
	
	
	@Override
	//@Transactional(rollbackFor=Throwable.class)
	public String addChallanDetails(JSONArray itemsIssued) throws Exception {
		try {

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX");
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("yyMMddhhmmssMs");
			String materialIssueRelationId = ft.format(dNow);

			MaterialIssueData materialData = new MaterialIssueData();
			
			// materialData_old = new MaterialIssueData();
			//System.out.println(itemsIssued.getString(0));
			 MaterialIssueData	materialData_old=materialsIssueDataRepository.findByChallanNumber(itemsIssued.getString(0));
				//System.out.println(materialData_old);

			if(materialData_old==null) {

			materialData.setChallanNumber(itemsIssued.getString(0));

			if (itemsIssued.getInt(1) == Integer
					.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_I_RYP)))
				materialData.setMaterialIssuedBy(1); // SSE/W-I-RYP
			else if (itemsIssued.getInt(1) == Integer
					.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.ISSUED_BY_SSE_W_II_RYP)))
				materialData.setMaterialIssuedBy(2);

			Date date1 = dateFormat.parse(itemsIssued.getString(2));

			materialData.setDateIssue(date1);
			materialData.setCreatedBy(currentUser.getCurrentUser().getUserId());
			materialData.setMaterialIssueTo(itemsIssued.getString(3)); // items
																		// issued
																		// Data
			materialData.setMaterialIssueToPerson(itemsIssued.getString(5));
			materialData.setTotalNoOfItemsIssued(itemsIssued.getJSONArray(4).length());
			materialData.setUniqueRelationNo(Long.valueOf(materialIssueRelationId));
			materialsIssueDataRepository.save(materialData);
			
			for (int i = 0; i < itemsIssued.getJSONArray(4).length(); i++) {

				MaterialsIssueRelation materialRelation = new MaterialsIssueRelation();

				String poIndentNo=itemsIssued.getJSONArray(4).getJSONObject(i).getString("poNumber");
				
				String poNumber=poIndentNo.substring(poIndentNo.indexOf(":")+1,poIndentNo.indexOf("with")).trim();
				
				int itemId=itemsIssued.getJSONArray(4).getJSONObject(i).getInt("itemId");
				
				Long indentId=Long.valueOf(poIndentNo.substring(poIndentNo.indexOf("indent")+"indent".length()).trim());
				
				materialRelation.setId(Long.valueOf(materialIssueRelationId) + i);
				materialRelation.setDateIssue(date1);
				materialRelation.setUniqueRelationId(Long.valueOf(materialIssueRelationId));
				materialRelation.setQtyIssued(itemsIssued.getJSONArray(4).getJSONObject(i).getInt("quantity"));
				materialRelation.setItemId(itemId);
				
				
				materialRelation.setPoNumber(poNumber);
				materialRelation.setIndentId(indentId);

				materialsIssueRelationRepository.save(materialRelation);

				StockAvailable stockavailable = stockAvailableRepository
						.findByItemId(itemId);

				if (stockavailable != null)
					stockavailable.setQuantityAvailable(stockavailable.getQuantityAvailable()
							- itemsIssued.getJSONArray(4).getJSONObject(i).getInt("quantity"));

				stockAvailableRepository.save(stockavailable);

				// data updated in indentPO relation when item is issued

				IndentPoRelation indentPo = indentPoRepository
						.findByPoNumberAndItemIdAndIdIndentId(poNumber, itemId, indentId);

				if(indentPo.getQtyReceived()>indentPo.getQtyIssued())
				indentPo.setQtyIssued(
						indentPo.getQtyIssued() + itemsIssued.getJSONArray(4).getJSONObject(i).getInt("quantity"));

				indentPoRepository.save(indentPo);
			}
			}
			else {
				
				return "Duplicate";
				
			}
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
			//return false;
		}
		

	}

}
