package com.rail.assist.controller;

import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.web.WebAttributes;
import org.springframework.security.web.savedrequest.SavedRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.rail.assist.constants.AssistConstants;
import com.rail.assist.constants.AssistConstantsParameters;
import com.rail.assist.dto.UserDto;
import com.rail.assist.entities.UserDetail;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.service.UserService;

@Controller
@RequestMapping
public class UserController {

	@Autowired
	UserService userService;
	
	@Autowired
	UserDetailsRepository userDetailsRepository;
	
	@Autowired
	AssistConstants assistConstants;
	
	@RequestMapping(value="/userLogin", method = RequestMethod.GET)
	public String loginController(HttpServletRequest request, Model model, HttpSession session)
	{
		
		  //String referrer = request.getHeader("Referer");
		  String redirectUrl=null;
		 // System.out.println( request.toString());
			  SavedRequest savedRequest = (SavedRequest) session.getAttribute("SPRING_SECURITY_SAVED_REQUEST");
			  if (savedRequest != null) {
				  redirectUrl= savedRequest.getRedirectUrl();
				 // System.out.println("Saved url in cache "+savedRequest.getRedirectUrl());
		        }

		  //System.out.println("prior login url is "+referrer);
		    request.getSession().setAttribute("url_prior_login",redirectUrl );
		return "login";
	}
	
	
	@RequestMapping(value="/registerUser" ,method=RequestMethod.GET)
	public String registerUser(Model model) throws Exception
    {
		

        UserDto userDto = new UserDto();

        model.addAttribute("userDto",userDto);

        return "register";

    }
	
	
	
	 @RequestMapping(value="/registerUser", method= RequestMethod.POST)
	public String processUser(@ModelAttribute("userDto") UserDto userDto, Model model) throws Exception {

		// BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		// String hashedPassword = passwordEncoder.encode(userDto.getPassword());

		try {
			List<UserDetail> numberOfusers = userDetailsRepository.findAll();
			if (numberOfusers.size() < Integer
					.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.MAXIMUM_USERS_ALLOWED))) {

				UserDetail userData = userDetailsRepository.findByUserMailIdAndUserPassword(userDto.getMailId(),
						userDto.getPassword());

				if (userData == null) {

					String hashedPassword = Base64.getEncoder().encodeToString(userDto.getPassword().getBytes());
					userService.insertUser(userDto, hashedPassword);
					model.addAttribute("userInserted", true);

				}

				else {

					model.addAttribute("userMailID", userDto.getMailId());
					model.addAttribute("userAlreadyExists", true);

				}
			}

			else {

				model.addAttribute("maximumUsersLimitReached", true);
				model.addAttribute("maximumUsers",
						assistConstants.getParameterValue(AssistConstantsParameters.MAXIMUM_USERS_ALLOWED));

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return "login";
	}
	
	
	 @RequestMapping(value = "/loginerror", method = RequestMethod.GET)
		public String tokenError(HttpServletRequest request, Model model) {


			Object obj = request.getSession().getAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);
			if(obj==null)
			{

				System.out.println(" There is no user session !!");



			}
			model.addAttribute("loginError", true);

			return "login";
		}



}
