package com.rail.assist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.ItemsData;

public interface ItemsDataRepository extends JpaRepository<ItemsData, Integer> {
	
	List<ItemsData> findByGroupId(int id);

	ItemsData findById(int id);
	
	ItemsData findByItemId(long id);
	
	List<ItemsData> findTop12ByGroupId(int id);

	
	List<ItemsData> findByGroupIdAndDescription(int id,String desc);
	
	List<ItemsData> findByGroupIdAndPartNumber(int id,String partNo);
	
	
	List<ItemsData> findByGroupIdAndItemId(int id,long partNo);

	
	
	List<ItemsData> findByCategoryId(int id);
	
	long countByGroupId(int id);
	
	List<ItemsData> findByItemIdNotIn(Long[] itemIds);
	
	
	
}
