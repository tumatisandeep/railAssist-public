package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the material_issue database table.
 * 
 */
@Entity
@Table(name = "MAT_ISSUED_MAT_RELATION_DATA")
@NamedQuery(name = "MaterialsIssueRelation.findAll", query = "SELECT m FROM MaterialsIssueRelation m")
public class MaterialsIssueRelation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
	private long id;

	@Column(name = "UNIQUE_RELATION_ID")
	private long uniqueRelationId;

	@Column(name = "ITEM_ID")
	private long itemId;

	@Column(name = "QUANTITY_ISSUED")
	private int qtyIssued;

	@Column(name = "PO_NUMBER")
	private String poNumber;

	@Column(name = "INDENT_ID")
	private long indentId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DATE")
	private Date dateIssue;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_UPDATE")
	private Date lastUpdate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_ON")
	private Date createdOn;

	public MaterialsIssueRelation() {
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public long getItemId() {
		return itemId;
	}

	public int getQtyIssued() {
		return qtyIssued;
	}

	public Date getDateIssue() {
		return dateIssue;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public void setQtyIssued(int qtyIssued) {
		this.qtyIssued = qtyIssued;
	}

	public void setDateIssue(Date dateIssue) {
		this.dateIssue = dateIssue;
	}

	public long getUniqueRelationId() {
		return uniqueRelationId;
	}

	public void setUniqueRelationId(long uniqueRelationId) {
		this.uniqueRelationId = uniqueRelationId;
	}

	public long getId() {
		return id;
	}

	public void setId(long l) {
		this.id = l;
	}

	public long getIndentId() {
		return indentId;
	}

	public void setIndentId(long indentId) {
		this.indentId = indentId;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	@PrePersist
	void createdAt() {
		this.lastUpdate = this.createdOn = new Date();

	}

	@PreUpdate
	void updatedAt() {
		this.lastUpdate = new Date();
	}

	@Override
	public String toString() {
		return "MaterialsIssueRelation [id=" + id + ", uniqueRelationId=" + uniqueRelationId + ", itemId=" + itemId
				+ ", qtyIssued=" + qtyIssued + ", poNumber=" + poNumber + ", dateIssue=" + dateIssue + "]";
	}

}