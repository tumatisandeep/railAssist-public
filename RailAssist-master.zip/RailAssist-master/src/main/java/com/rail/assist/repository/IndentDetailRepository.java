package com.rail.assist.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rail.assist.entities.IndentDetail;


public interface IndentDetailRepository extends JpaRepository<IndentDetail,Integer> {
	
	IndentDetail findByIndentId(long id);
	
	IndentDetail findByItemId(long id);

	
	//List<IndentDetail> findByPoReceived(long id);
	
	@Query("select indent from IndentDetail indent where  indent.itemId=?1 and indent.quantityReq>indent.poQuantityRcvd")
	List<IndentDetail> outStandingIndents(long indentId);
	

	@Query("select indent from IndentDetail indent where  indent.itemId=?1 and indent.quantityReq>indent.poQuantityRcvd")
	List<IndentDetail> outStandingIndentsData(long itemId, Pageable pageable);

	Page<IndentDetail> findByItemId(long itemId, Pageable pageable);

	//List<IndentDetail> findByItemIdAndPoReceived(long itemId, long poNotReceivedForIndent, Pageable pageable);
	
	
	/*@Query("select indent from IndentDetail indent where  indent.itemId=?1 and indent.poReceived=?2 and indent.quantityReq>indent.quantityReceived  ")
	List<IndentDetail> findByItemIdAndPoReceivedPo(long itemId, long poNotReceivedForIndent, Pageable pageable);*/

	
	@Query("select i from IndentDetail i where trunc(i.createdOn)=TO_DATE(?1,'yyyy-MM-dd')")
	List<IndentDetail> findByCreatedOnFunction(String date);

	
	
	List<IndentDetail> findByCreatedOnGreaterThanEqualAndCreatedOnLessThan(Date date,Date date2);

	
	long countByCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(Date date,Date date2);
	
	List<IndentDetail> findByIndentLoggedByAndCreatedOnGreaterThanEqualAndCreatedOnLessThanEqual(long id,Date date,Date date2);

	/**
	 * @param userId
	 * @return
	 */
	List<IndentDetail> findByIndentLoggedBy(long userId);
	
}



