package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the sub_group database table.
 * 
 */
@Entity
@Table(name="sub_group")
@NamedQuery(name="SubGroup.findAll", query="SELECT s FROM SubGroup s")
public class SubGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SUB_GROUP_ID")
	private int subGroupId;

	@Column(name="IS_PRIMARY_GROUP")
	private int isPrimaryGroup;

	@Column(name="SUB_GROUP_DESC")
	private String subGroupDesc;

	@Column(name="SUB_GROUP_UNDER")
	private int subGroupUnder;

	@Column(name="SUB_GROUP_VERSION")
	private int subGroupVersion;

	public SubGroup() {
	}

	public int getSubGroupId() {
		return this.subGroupId;
	}

	public void setSubGroupId(int subGroupId) {
		this.subGroupId = subGroupId;
	}

	public int getIsPrimaryGroup() {
		return this.isPrimaryGroup;
	}

	public void setIsPrimaryGroup(int isPrimaryGroup) {
		this.isPrimaryGroup = isPrimaryGroup;
	}

	public String getSubGroupDesc() {
		return this.subGroupDesc;
	}

	public void setSubGroupDesc(String subGroupDesc) {
		this.subGroupDesc = subGroupDesc;
	}

	public int getSubGroupUnder() {
		return this.subGroupUnder;
	}

	public void setSubGroupUnder(int subGroupUnder) {
		this.subGroupUnder = subGroupUnder;
	}

	public int getSubGroupVersion() {
		return this.subGroupVersion;
	}

	public void setSubGroupVersion(int subGroupVersion) {
		this.subGroupVersion = subGroupVersion;
	}

}