package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the material_issue database table.
 * 
 */
@Entity
@Table(name="material_issue")
@NamedQuery(name="MaterialIssue.findAll", query="SELECT m FROM MaterialIssue m")
public class MaterialIssue implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private MaterialIssuePK id;

	private String comments;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATE_ISSUE")
	private Date dateIssue;

	private String description;

	@Column(name="ITEM_ISSUED")
	private int itemIssued;

	@Column(name="MATERIAL_ISSUE_TO")
	private int materialIssueTo;

	@Column(name="MATERIAL_ISSUED_BY")
	private int materialIssuedBy;

	@Column(name="MATERIAL_TYPE")
	private int materialType;

	@Column(name="PURCHASE_RATE")
	private int purchaseRate;

	@Column(name="QUANTITY_DEMANDED")
	private int quantityDemanded;

	@Column(name="QUANTITY_ISSUED")
	private int quantityIssued;

	public MaterialIssue() {
	}

	public MaterialIssuePK getId() {
		return this.id;
	}

	public void setId(MaterialIssuePK id) {
		this.id = id;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getDateIssue() {
		return this.dateIssue;
	}

	public void setDateIssue(Date dateIssue) {
		this.dateIssue = dateIssue;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getItemIssued() {
		return this.itemIssued;
	}

	public void setItemIssued(int itemIssued) {
		this.itemIssued = itemIssued;
	}

	public int getMaterialIssueTo() {
		return this.materialIssueTo;
	}

	public void setMaterialIssueTo(int materialIssueTo) {
		this.materialIssueTo = materialIssueTo;
	}

	public int getMaterialIssuedBy() {
		return this.materialIssuedBy;
	}

	public void setMaterialIssuedBy(int materialIssuedBy) {
		this.materialIssuedBy = materialIssuedBy;
	}

	public int getMaterialType() {
		return this.materialType;
	}

	public void setMaterialType(int materialType) {
		this.materialType = materialType;
	}

	public int getPurchaseRate() {
		return this.purchaseRate;
	}

	public void setPurchaseRate(int purchaseRate) {
		this.purchaseRate = purchaseRate;
	}

	public int getQuantityDemanded() {
		return this.quantityDemanded;
	}

	public void setQuantityDemanded(int quantityDemanded) {
		this.quantityDemanded = quantityDemanded;
	}

	public int getQuantityIssued() {
		return this.quantityIssued;
	}

	public void setQuantityIssued(int quantityIssued) {
		this.quantityIssued = quantityIssued;
	}

}