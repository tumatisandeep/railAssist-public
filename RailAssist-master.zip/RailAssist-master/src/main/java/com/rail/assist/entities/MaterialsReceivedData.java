package com.rail.assist.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

/**
 * The persistent class for the material_issue database table.
 * 
 */
@Entity
@Table(name = "ITEMS_RECEIVED_DATA")
@NamedQuery(name = "MaterialsReceivedData.findAll", query = "SELECT m FROM MaterialsReceivedData m")
public class MaterialsReceivedData implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
	private long id;

	@Column(name = "ITEM_ID")
	private long itemId;

	@Column(name = "PO_NUMBER")
	private String poNumber;

	@Column(name = "NUMBER_OF_ITEMS_RECEIVED")
	private int numberOfItemsReceived;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DATE_RECEIVED")
	private Date dateReceived;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_ON")
	private Date createdOn;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_UPDATE")
	private Date lastUpdate;

	@Column(name = "CREATED_BY")
	private long createdBy;

	@Column(name = "INDENT_ID")
	private long indentId;
	
	@Version
	@Column(name = "VERSION")
	private int version;

	public MaterialsReceivedData() {
	}

	public Date getCreatedon() {
		return createdOn;
	}

	public void setCreatedOn(Date createdon) {
		this.createdOn = createdon;
	}

	public long getItemId() {
		return itemId;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public int getNumberOfItemsReceived() {
		return numberOfItemsReceived;
	}

	public Date getDateReceived() {
		return dateReceived;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public long getId() {
		return id;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public int getVersion() {
		return version;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public void setNumberOfItemsReceived(int numberOfItemsReceived) {
		this.numberOfItemsReceived = numberOfItemsReceived;
	}

	public void setDateReceived(Date dateReceived) {
		this.dateReceived = dateReceived;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public long getIndentId() {
		return indentId;
	}

	public void setIndentId(long indentId) {
		this.indentId = indentId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	@PrePersist
	void createdAt() {
		this.createdOn = new Date();
		this.lastUpdate = new Date();

	}

	@PreUpdate
	void updatedAt() {
		this.lastUpdate = new Date();
	}

}