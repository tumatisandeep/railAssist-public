package com.rail.assist.repository;

import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.VendorsData;

public interface VendorsDataRepository extends JpaRepository<VendorsData, Integer> {

	VendorsData findById(long l);

	
}


