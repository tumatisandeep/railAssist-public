package com.rail.assist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rail.assist.entities.MailSentData;

public interface MailSentDataRepository extends JpaRepository<MailSentData, Integer>{
	

	MailSentData findByisMailSentAndDate(int isMailSent,String date);
	
}
