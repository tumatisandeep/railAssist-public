package com.rail.assist.controller;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.rail.assist.constants.AssistConstants;
import com.rail.assist.entities.Category;
import com.rail.assist.entities.IndentDetail;
import com.rail.assist.entities.ItemsData;
import com.rail.assist.entities.VendorsData;
import com.rail.assist.repository.CategoryRepository;
import com.rail.assist.repository.IndentDetailRepository;
import com.rail.assist.repository.ItemsDataRepository;
import com.rail.assist.repository.VendorsDataRepository;

@Controller
public class DemoController {
	@Autowired
	ItemsDataRepository itemsDataRepository;

	@Autowired
	VendorsDataRepository vendorsDataRepository;

	@Autowired
	CategoryRepository categoryRepository;
	
	
	@Autowired
	IndentDetailRepository indentDetailRepository;
	
	@Autowired
	AssistConstants assistConstants;

	// *********************************************************//
	// used to insert items data in to raildb.ITEMS_DATA table*//
	// *********************************************************//
	
	
	@RequestMapping(value="/insertNewItems",method=RequestMethod.GET)
	public String insertNewItems() {
		

		try {
			
			final String path =assistConstants.getParameterValue("ITEMS_NEWDATA_PATH");
			
			
			
			//final String path = "/Users/mahideeptumati/Desktop/newItems08072019.xlsx";
			
			
			Workbook workbook = WorkbookFactory.create(new File(path));

			System.out.println("Retrieving Sheets using for-each loop");
			for (org.apache.poi.ss.usermodel.Sheet sheet : workbook) {
				System.out.println("=> " + sheet.getSheetName());
			}

			// Getting the Sheet at index zero
			org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheetAt(0);

			// Create a DataFormatter to format and get each cell's value as String
			DataFormatter dataFormatter = new DataFormatter();

			System.out.println("\n\nIterating over Rows and Columns using for-each loop\n");
			int j = 0;
			int id = Integer.parseInt(assistConstants.getParameterValue("ITEMS_MAX_COUNT"))+1;
			for (Row row : sheet) {
				
				

				ItemsData items = new ItemsData();

				if (j > 0) {

					int i = 0;

					for (Cell cell : row) {
						System.out.println("i value after for looop "+i);

						String cellValue = dataFormatter.formatCellValue(cell).trim();

						items.setId(id);

						if (i == 0) {
							System.out.println("inside i=0 "+i);

							items.setItemId(Integer.parseInt(cellValue));
							items.setCategoryId((Integer.parseInt(cellValue.substring(0, 3))));

							items.setGroupId(Integer.parseInt(cellValue.substring(0, 1)));
							items.setLfNumber("NA");
							items.setUnits("NA");

							items.setPrice(0.00);

						}

						if (i == 1) {

							items.setDescription((cellValue));

						}

						if (i == 2) {

							items.setPartNumber((cellValue));

						}

						if (i == 3) {

							items.setType(cellValue);

						}

						
						i++;
						
						if (i == 4) {
							System.out.println("inside i is 4 loop");
							System.out.println(items.toString());
							try {
							itemsDataRepository.save(items);
							id++;
							}
							catch(DataIntegrityViolationException e)
							{
								System.out.println("Duplicate item found ::: "+items.getItemId());
							}

						}
					}
					
					System.out.println(items.toString());

					System.out.println("i value :: "+i);

				}
				System.out.println("before j+++");
				j++;
			}

		} catch (Exception e) {
			
			
			e.printStackTrace();
		}

	return "newHome";
		
		
		
	}
	
	@RequestMapping(value = "/insertItemsData", method = RequestMethod.GET)
	void generateIndentForm1() {
		try {   
			final String path = assistConstants.getParameterValue("ITEMS_DATA_FILE");
			Workbook workbook = WorkbookFactory.create(new File(path));

			System.out.println("Retrieving Sheets using for-each loop");
			for (org.apache.poi.ss.usermodel.Sheet sheet : workbook) {
				System.out.println("=> " + sheet.getSheetName());
			}

			// Getting the Sheet at index zero
			org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheetAt(0);

			// Create a DataFormatter to format and get each cell's value as String
			DataFormatter dataFormatter = new DataFormatter();

			System.out.println("\n\nIterating over Rows and Columns using for-each loop\n");
			int j = 0;
			int id = 1;
			for (Row row : sheet) {
				

				ItemsData items = new ItemsData();

				if (j > 0) {

					int i = 0;

					for (Cell cell : row) {

						String cellValue = dataFormatter.formatCellValue(cell).trim();

						items.setId(id);

						if (i == 0) {
							// System.out.println(cellValue);
							items.setItemId(Integer.parseInt(cellValue));

						}

						if (i == 1) {
							// System.out.println(cellValue);

							items.setCategoryId((Integer.parseInt(cellValue)));

						}

						if (i == 2) {
							// System.out.println(cellValue);

							items.setDescription((cellValue));

						}

						if (i == 3) {
							System.out.println(cellValue);

							items.setPartNumber((cellValue));

						}
						if (i == 4 && !cellValue.replaceAll("\\s","").trim().equals("")) {

							System.out.println(cellValue.trim().length());
							
							items.setLfNumber((cellValue));

						}
						else {
							
							items.setLfNumber("NA");

						}

						if (i == 5) {
							// System.out.println(cellValue);

							items.setUnits((cellValue));

						}

						if (i == 6 && (!(cellValue.trim() == null) && !cellValue.trim().isEmpty())) {
							// System.out.println(cellValue);

							items.setPrice(Float.parseFloat(cellValue));

						}

						if (i == 7) {
							// System.out.println(cellValue);

							items.setGroupId(Integer.parseInt(cellValue));

						}
						if (i == 8) {
							// System.out.println(cellValue);

							items.setType((cellValue));

							// System.out.println("entered");

						}

						if (i == 9) {
							// System.out.println("inside 9");
							System.out.println(items.toString());
							try {
							itemsDataRepository.save(items);
							
							}
							catch(Exception e) {
								System.out.println("Exception while adding item > "+items.getItemId());
							}
							id++;
						}
						i++;
					}
					System.out.println();

				}
				System.out.println("before j+++");
				j++;
			}

		} catch (Exception e) {
			
			
			e.printStackTrace();
		}

	}

	// ************************************************************//
	// used to insert vendor data in to raildb.VENDORS_DATA table*//
	// ************************************************************//

	@RequestMapping("/insertIntoVendorData")
	void insertVendorData() {
		try {

			final String path = "/Users/mahideeptumati/Desktop/vendorsData.xlsx";
			Workbook workbook = WorkbookFactory.create(new File(path));
			// Getting the Sheet at index zero
			org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheetAt(0);

			// Create a DataFormatter to format and get each cell's value as String
			DataFormatter dataFormatter = new DataFormatter();
			int j = 0;

			for (Row row : sheet) {

				VendorsData vendor = new VendorsData();

				if (j > 0) {

					int i = 0;

					for (Cell cell : row) {

						String cellValue = dataFormatter.formatCellValue(cell).trim();

						if (i == 0) {
							// System.out.println(cellValue);
							vendor.setId(Integer.parseInt(cellValue));

						}

						if (i == 1) {
							// System.out.println(cellValue);

							vendor.setSupplierDesc(cellValue);

						}

						if (i == 2) {
							// System.out.println(cellValue);

							vendor.setCity(cellValue);

						}

						if (i == 3) {

						}
						if (i == 4) {

						}

						if (i == 5) {

						}

						if (i == 6) {
							System.out.println(vendor.toString());
							vendorsDataRepository.save(vendor);

						}
						i++;
					}
					System.out.println();

				}
				j++;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ************************************************************//
	// used to insert category data in to raildb.CATEGORY table *//
	// ************************************************************//

	@RequestMapping("/insertIntoCategory")
	void insertCategoryData() {
		try {

			final String path = "/Users/mahideeptumati/Desktop/category.xlsx";
			Workbook workbook = WorkbookFactory.create(new File(path));
			// Getting the Sheet at index zero
			org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheetAt(0);

			// Create a DataFormatter to format and get each cell's value as String
			DataFormatter dataFormatter = new DataFormatter();
			int j = 0;

			for (Row row : sheet) {

				Category category = new Category();

				if (j > 0) {

					int i = 0;

					for (Cell cell : row) {

						String cellValue = dataFormatter.formatCellValue(cell).trim();

						if (i == 0) {
							// System.out.println(cellValue);
							category.setCategoryId(Integer.parseInt(cellValue));

						}

						if (i == 1) {
							// System.out.println(cellValue);

							category.setCategoryDesc(cellValue);

						}

						if (i == 2) {
							category.setGroupId(Integer.parseInt(cellValue));
							System.out.println(category.toString());
							category.setCreatedBy(12345);
							category.setCreatedOn(new Date());
							category.setLastUpdate(new Date());
							categoryRepository.save(category);

						}

						i++;
					}
					System.out.println();

				}
				j++;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	// for inserting data from last 3 years RC indent data from sheet 0
	@RequestMapping("/insertRCIndenetData")
	void insertRCIndenetData() {
		try {

			final String path = "/Users/mahideeptumati/Downloads/RC Indents.xlsx";
			Workbook workbook = WorkbookFactory.create(new File(path));
			// Getting the Sheet at index zero
			org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheetAt(0);

			// Create a DataFormatter to format and get each cell's value as String
			DataFormatter dataFormatter = new DataFormatter();
			int j = 0;
			int id = 1;
			for (Row row : sheet) {
				System.out.println("j value :::: " +j);

				if (j > 1 &&j!=125 &&j!=127 &&j!=302) {

					int i = 0;
					IndentDetail indent = new IndentDetail();

					for (Cell cell : row) {

						String cellValue = dataFormatter.formatCellValue(cell).trim();
						System.out.println(cellValue.trim());
						if (i == 0) {
							indent.setId(Integer.parseInt(cellValue));

						}
						if (i == 1) {
							// System.out.println(cellValue);
							System.out.println("inserting data started");
							indent.setIndentId(Integer.parseInt(cellValue.substring(2, cellValue.length())));

						}

						if (i == 2) {

							DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
							if(cellValue.charAt(0)!='1') {
								
							cellValue="0"+cellValue.substring(0, cellValue.length()-3)+"/20"+cellValue.substring(cellValue.length()-2, cellValue.length());
								
							}
							else {
								
								cellValue= cellValue.substring(0, cellValue.length()-3)+"/20"+cellValue.substring(cellValue.length()-2, cellValue.length());
								
							}
							
							System.out.println(cellValue);
							
							Date d = formatter.parse(cellValue);

							indent.setDate(d);

						}

						if (i == 3) {

							if(cellValue.trim()=="")
								indent.setItemId(0);

							else
							indent.setItemId(Integer.parseInt(cellValue.trim()));
						}

						if (i == 4) {

							indent.setDescription(cellValue.trim());
						}

						if (i == 5) {

						}

						if (i == 6) {

							indent.setQuantityReq(Integer.parseInt(cellValue.trim()));
						}

						if (i == 7) {
							if (cellValue.trim() != "")
								indent.setRate(Double.parseDouble(cellValue.trim()));
							else
								indent.setRate(0);
						}
						if (i == 8) {

							indent.setValue(indent.getQuantityReq()*indent.getRate());
						}

						if (i == 9) {

							indent.setIndentor(1);
							indent.setConsignee(1);
							indent.setMaterialsRequiredAt(1);
							indent.setDepot(1);
							indent.setUnits("N/A");
							indent.setAcceptableMake(1);
							indent.setAllocation("207214-04");
							indent.setPurpose("Required for machine");
							indent.setLastUpdate(new Date());
							indent.setVersion(0);
							indent.setIndentLoggedBy(12345);
							indent.setIndentType(1);
							indent.setSerialNumber(0);
							indent.setLikelySupplier(99999);
							indent.setPoQuantityRcvd(indent.getQuantityReq());
							indent.setArticleEnclosed(1);
							//indent.setControllingOfficer(1);
							indent.setStockAvailable(0);
							indent.setOsaAgnstIndents(0);
							indent.setOsaAgnstPo(0);
							indent.setOsIndentData("Nill%%Nill%%Nill%%Nill");
							indent.setOsPoData("Nill%%NA&&Nill%%NA&&Nill%%NA&&Nill%%NA");

							indent.setCreatedOn(new Date());
							indent.setLastPurchaseParticulars("NA");
							indent.setFinancialYear("2015-2016");
						}
						i++;

					}
					System.out.println("----------------------------------------------");
					indentDetailRepository.save(indent);

				}
				j++;

			}

		}
		
		catch(Exception e) {
			e.printStackTrace();
			
		}
	
	
		}
	
}
