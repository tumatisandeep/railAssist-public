package com.rail.assist.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the gender database table.
 * 
 */
@Entity
@NamedQuery(name="Gender.findAll", query="SELECT g FROM Gender g")
public class Gender implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="GENDER_ID")
	private int genderId;

	@Column(name="GENDER_DESC")
	private String genderDesc;

	@Column(name="GENDER_VERSION")
	private int genderVersion;

	//bi-directional many-to-one association to UserDetail
	@OneToMany(mappedBy="gender")
	private List<UserDetail> userDetails;

	public Gender() {
	}

	public int getGenderId() {
		return this.genderId;
	}

	public void setGenderId(int genderId) {
		this.genderId = genderId;
	}

	public String getGenderDesc() {
		return this.genderDesc;
	}

	public void setGenderDesc(String genderDesc) {
		this.genderDesc = genderDesc;
	}

	public int getGenderVersion() {
		return this.genderVersion;
	}

	public void setGenderVersion(int genderVersion) {
		this.genderVersion = genderVersion;
	}

	public List<UserDetail> getUserDetails() {
		return this.userDetails;
	}

	public void setUserDetails(List<UserDetail> userDetails) {
		this.userDetails = userDetails;
	}

	public UserDetail addUserDetail(UserDetail userDetail) {
		getUserDetails().add(userDetail);
		userDetail.setGender(this);

		return userDetail;
	}

	public UserDetail removeUserDetail(UserDetail userDetail) {
		getUserDetails().remove(userDetail);
		userDetail.setGender(null);

		return userDetail;
	}

}