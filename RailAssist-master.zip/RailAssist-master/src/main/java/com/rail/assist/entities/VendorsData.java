package com.rail.assist.entities;


import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the vendors_data database table.
 * 
 */
@Entity
@Table(name="vendors_data")
@NamedQuery(name="VendorsData.findAll", query="SELECT v FROM VendorsData v")
public class VendorsData implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long id;

	@Column(name="ALT_PHONE_NUM")
	private int altPhoneNum;

	private String city;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_ON")
	private Date createdOn;

	private String email;

	private String fax;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_UPDATE")
	private Date lastUpdate;

	@Column(name="PHONE_NUM")
	private int phoneNum;

	@Column(name="SUPPLIER_DESC")
	private String supplierDesc;

	@Version
	private int version;

	public VendorsData() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getAltPhoneNum() {
		return this.altPhoneNum;
	}

	public void setAltPhoneNum(int altPhoneNum) {
		this.altPhoneNum = altPhoneNum;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return this.createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return this.fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public Date getLastUpdate() {
		return this.lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public int getPhoneNum() {
		return this.phoneNum;
	}

	public void setPhoneNum(int phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getSupplierDesc() {
		return this.supplierDesc;
	}

	public void setSupplierDesc(String supplierDesc) {
		this.supplierDesc = supplierDesc;
	}

	public int getVersion() {
		return this.version;
	}

	public void setVersion(int version) {
		this.version = version;
	}
	
	@PrePersist
	void createdAt() {
		this.createdOn = new Date();
		this.lastUpdate = new Date();

	}

	@PreUpdate
	void updatedAt() {
		this.lastUpdate = new Date();
	}

	@Override
	public String toString() {
		return "VendorsData [id=" + id + ", altPhoneNum=" + altPhoneNum + ", city=" + city + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", email=" + email + ", fax=" + fax + ", lastUpdate=" + lastUpdate
				+ ", phoneNum=" + phoneNum + ", supplierDesc=" + supplierDesc + ", version=" + version + "]";
	}
	
	

}