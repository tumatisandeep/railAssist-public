package com.rail.assist.serviceImplementation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import com.rail.assist.constants.AssistConstants;
import com.rail.assist.constants.AssistConstantsParameters;
import com.rail.assist.dto.UserDto;
import com.rail.assist.entities.Gender;
import com.rail.assist.entities.UserAccountStatus;
import com.rail.assist.entities.UserDetail;
import com.rail.assist.entities.UserLoginStatus;
import com.rail.assist.entities.UserType;
import com.rail.assist.repository.GenderRepository;
import com.rail.assist.repository.UserAccountStatusRepository;
import com.rail.assist.repository.UserDesignationRepository;
import com.rail.assist.repository.UserDetailsRepository;
import com.rail.assist.repository.UserLoginStatusRepository;
import com.rail.assist.repository.UserTypeRepository;
import com.rail.assist.service.UserService;

@Service
public class UserServiceImplementation implements UserService {

	@Autowired
	UserDesignationRepository userDesignationRepository;

	@Autowired
	GenderRepository genderRepository;

	@Autowired
	UserLoginStatusRepository userLoginStatusRepository;

	@Autowired
	UserAccountStatusRepository userAccountStatusRepository;

	@Autowired
	UserDetailsRepository userDetailsRepository;
	
	
	@Autowired
	AssistConstants assistConstants;
	
	@Autowired
	private UserTypeRepository userTypeRepository;

	
	public void insertUser(UserDto userDto, String hashedPassword) throws  Exception {

		try {
			UserDetail userData = new UserDetail();

			userData.setUserFirstName(userDto.getfName());
			userData.setUserLastName(userDto.getlName());
			userData.setUserId(userDto.getUserId());
			userData.setUserAddress(userDto.getAddress());

			userData.setUserMobile(userDto.getMobile());
		//	System.out.println(userDto.getMobile() + "---" + userDto.getAltMobile() + "++++++++");
			userData.setUserAltMobile(userDto.getMobile());
			userData.setUserDob(stringToDate(userDto.getDob()));
			userData.setUserMailId(userDto.getMailId());
			userData.setUserWorkLocation(userDto.getWorkLocation());
			userData.setUserPassword(hashedPassword);

			Gender gender = genderRepository.findByGenderId(userDto.getGender());
			userData.setGender(gender);

			UserLoginStatus loginStatus = userLoginStatusRepository
					.findByUserLoginStatusId(AssistConstantsParameters.USER_LOGGED_IN_CURRENTLY); // logged in curently
			userData.setUserLoginStatusBean(loginStatus);
			
			if(gender.getGenderId()==AssistConstantsParameters.USER_GENDER_MALE)
			userData.setUserPlink(
					"images/profilePic.png");
			else
				userData.setUserPlink(
						"images/profilePicFemale.png");
				

			UserType userType = userTypeRepository.findByUserTypeId(
					Integer.valueOf(assistConstants.getParameterValue(AssistConstantsParameters.USER_TYPE_NORMAL)));

			userData.setUserType(userType.getUserTypeId());
			UserAccountStatus accStatus = userAccountStatusRepository
					.findByUserAccountStatusId(AssistConstantsParameters.USER_ACCOUNT_ACTIVE); // Active
			userData.setUserAccountStatusBean(accStatus);

			userDetailsRepository.save(userData);
		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;
		}

	}

	@Override
	public List<GrantedAuthority> findAllRoles(UserDetail userDetailInfo1) throws Exception {
		try {
		Set<GrantedAuthority> setAuths = new HashSet<>();
		
			String functionId;
			functionId = Long.toString(userDetailInfo1.getUserType());

			setAuths.add(new SimpleGrantedAuthority("ROLE_" + functionId));
			return new ArrayList<>(setAuths);

		} catch (Exception e) {
			      
			e.printStackTrace();
			throw e;

		}


	}

	public static Date stringToDate(String dateInString) throws ParseException {

		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = null;
			
				date = formatter.parse(dateInString);
			 


			return date;
		} catch (Exception e) {
			      
			e.printStackTrace();
			
			throw e;
		}

	}

}
